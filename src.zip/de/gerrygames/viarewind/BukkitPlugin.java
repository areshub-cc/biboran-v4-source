package de.gerrygames.viarewind;

import de.gerrygames.viarewind.api.ViaRewindConfigImpl;
import de.gerrygames.viarewind.api.ViaRewindPlatform;
import java.io.File;
import org.bukkit.plugin.java.JavaPlugin;

public class BukkitPlugin extends JavaPlugin implements ViaRewindPlatform
{
    public void onEnable()
    {
        ViaRewindConfigImpl viarewindconfigimpl = new ViaRewindConfigImpl(new File(this.getDataFolder(), "config.yml"));
        viarewindconfigimpl.reloadConfig();
        this.init(viarewindconfigimpl);
    }
}

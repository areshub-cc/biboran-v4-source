package de.gerrygames.viarewind.utils;

import com.viaversion.viaversion.libs.gson.JsonElement;
import com.viaversion.viaversion.libs.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
import com.viaversion.viaversion.libs.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import com.viaversion.viaversion.protocols.protocol1_13to1_12_2.ChatRewriter;
import de.gerrygames.viarewind.ViaRewind;
import java.util.logging.Level;
import java.util.regex.Pattern;

public class ChatUtil
{
    private static final Pattern UNUSED_COLOR_PATTERN = Pattern.compile("(?>(?>\u00a7[0-fk-or])*(\u00a7r|\\Z))|(?>(?>\u00a7[0-f])*(\u00a7[0-f]))");

    public static String jsonToLegacy(String json)
    {
        if (json != null && !json.equals("null") && !json.isEmpty())
        {
            try
            {
                String s;

                for (s = LegacyComponentSerializer.legacySection().serialize(ChatRewriter.HOVER_GSON_SERIALIZER.deserialize(json)); s.startsWith("\u00a7f"); s = s.substring(2))
                {
                    ;
                }

                return s;
            }
            catch (Exception exception)
            {
                ViaRewind.getPlatform().getLogger().log(Level.WARNING, "Could not convert component to legacy text: " + json, (Throwable)exception);
                return "";
            }
        }
        else
        {
            return "";
        }
    }

    public static String jsonToLegacy(JsonElement component)
    {
        if (!component.isJsonNull() && (!component.isJsonArray() || !component.getAsJsonArray().isEmpty()) && (!component.isJsonObject() || component.getAsJsonObject().size() != 0))
        {
            return component.isJsonPrimitive() ? component.getAsString() : jsonToLegacy(component.toString());
        }
        else
        {
            return "";
        }
    }

    public static String legacyToJson(String legacy)
    {
        return legacy == null ? "" : (String)GsonComponentSerializer.gson().serialize(LegacyComponentSerializer.legacySection().deserialize(legacy));
    }

    public static String removeUnusedColor(String legacy, char last)
    {
        if (legacy == null)
        {
            return null;
        }
        else
        {
            legacy = UNUSED_COLOR_PATTERN.matcher(legacy).replaceAll("$1$2");
            StringBuilder stringbuilder = new StringBuilder();

            for (int i = 0; i < legacy.length(); ++i)
            {
                char c0 = legacy.charAt(i);

                if (c0 == 167 && i != legacy.length() - 1)
                {
                    ++i;
                    c0 = legacy.charAt(i);

                    if (c0 != last)
                    {
                        stringbuilder.append('\u00a7').append(c0);
                        last = c0;
                    }
                }
                else
                {
                    stringbuilder.append(c0);
                }
            }

            return stringbuilder.toString();
        }
    }
}

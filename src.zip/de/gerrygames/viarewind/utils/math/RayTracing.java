package de.gerrygames.viarewind.utils.math;

public class RayTracing
{
    public static Vector3d trace(Ray3d ray, AABB aabb, double distance)
    {
        Vector3d vector3d = new Vector3d(1.0D / ray.dir.x, 1.0D / ray.dir.y, 1.0D / ray.dir.z);
        boolean flag = vector3d.x < 0.0D;
        boolean flag1 = vector3d.y < 0.0D;
        boolean flag2 = vector3d.z < 0.0D;
        Vector3d vector3d1 = flag ? aabb.max : aabb.min;
        double d0 = (vector3d1.x - ray.start.x) * vector3d.x;
        vector3d1 = flag ? aabb.min : aabb.max;
        double d1 = (vector3d1.x - ray.start.x) * vector3d.x;
        vector3d1 = flag1 ? aabb.max : aabb.min;
        double d2 = (vector3d1.y - ray.start.y) * vector3d.y;
        vector3d1 = flag1 ? aabb.min : aabb.max;
        double d3 = (vector3d1.y - ray.start.y) * vector3d.y;

        if (d0 <= d3 && d2 <= d1)
        {
            if (d2 > d0)
            {
                d0 = d2;
            }

            if (d3 < d1)
            {
                d1 = d3;
            }

            vector3d1 = flag2 ? aabb.max : aabb.min;
            double d4 = (vector3d1.z - ray.start.z) * vector3d.z;
            vector3d1 = flag2 ? aabb.min : aabb.max;
            double d5 = (vector3d1.z - ray.start.z) * vector3d.z;

            if (d0 <= d5 && d4 <= d1)
            {
                if (d4 > d0)
                {
                    d0 = d4;
                }

                if (d5 < d1)
                {
                    d1 = d5;
                }

                return d0 <= distance && d1 > 0.0D ? ray.start.clone().add(ray.dir.clone().normalize().multiply(d0)) : null;
            }
            else
            {
                return null;
            }
        }
        else
        {
            return null;
        }
    }
}

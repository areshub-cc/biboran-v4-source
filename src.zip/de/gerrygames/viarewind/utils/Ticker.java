package de.gerrygames.viarewind.utils;

import com.viaversion.viaversion.api.Via;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Ticker
{
    private static boolean init = false;

    public static void init()
    {
        if (!init)
        {
            synchronized (Ticker.class)
            {
                if (init)
                {
                    return;
                }

                init = true;
            }

            Via.getPlatform().runRepeatingSync(() ->
            {
                Via.getManager().getConnectionManager().getConnections().forEach((user) -> {
                    Stream stream = user.getStoredObjects().values().stream();
                    Objects.requireNonNull(Tickable.class);
                    stream = stream.filter(Tickable.class::isInstance);
                    Objects.requireNonNull(Tickable.class);
                    stream.map(Tickable.class::cast).forEach(Tickable::tick);
                });
            }, 1L);
        }
    }
}

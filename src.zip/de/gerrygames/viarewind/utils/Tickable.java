package de.gerrygames.viarewind.utils;

public interface Tickable
{
    void tick();
}

package de.gerrygames.viarewind.protocol.protocol1_8to1_9.entityreplacement;

import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.minecraft.metadata.types.MetaType1_9;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.types.version.Types1_8;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.metadata.MetadataRewriter;
import de.gerrygames.viarewind.replacement.EntityReplacement;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class ShulkerReplacement implements EntityReplacement
{
    private int entityId;
    private List<Metadata> datawatcher = new ArrayList<Metadata>();
    private double locX;
    private double locY;
    private double locZ;
    private UserConnection user;

    public ShulkerReplacement(int entityId, UserConnection user)
    {
        this.entityId = entityId;
        this.user = user;
        this.spawn();
    }

    public void setLocation(double x, double y, double z)
    {
        this.locX = x;
        this.locY = y;
        this.locZ = z;
        this.updateLocation();
    }

    public void relMove(double x, double y, double z)
    {
        this.locX += x;
        this.locY += y;
        this.locZ += z;
        this.updateLocation();
    }

    public void setYawPitch(float yaw, float pitch)
    {
    }

    public void setHeadYaw(float yaw)
    {
    }

    public void updateMetadata(List<Metadata> metadataList)
    {
        for (Metadata metadata : metadataList)
        {
            this.datawatcher.removeIf((m) ->
            {
                return (void)(m.id() == metadata.id());
            });
            this.datawatcher.add(metadata);
        }

        this.updateMetadata();
    }

    public void updateLocation()
    {
        PacketWrapper packetwrapper = PacketWrapper.create(24, (ByteBuf)null, this.user);
        packetwrapper.write(Type.VAR_INT, Integer.valueOf(this.entityId));
        packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locX * 32.0D)));
        packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locY * 32.0D)));
        packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locZ * 32.0D)));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
        packetwrapper.write(Type.BOOLEAN, Boolean.valueOf(true));
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class, true, true);
    }

    public void updateMetadata()
    {
        PacketWrapper packetwrapper = PacketWrapper.create(28, (ByteBuf)null, this.user);
        packetwrapper.write(Type.VAR_INT, Integer.valueOf(this.entityId));
        List<Metadata> list = new ArrayList<Metadata>();

        for (Metadata metadata1 : this.datawatcher)
        {
            if (metadata1.id() != 11 && metadata1.id() != 12 && metadata1.id() != 13)
            {
                list.add(new Metadata(metadata1.id(), metadata1.metaType(), metadata1.getValue()));
            }
        }

        list.add(new Metadata(11, MetaType1_9.VarInt, Integer.valueOf(2)));
        MetadataRewriter.transform(EntityType.MAGMA_CUBE, list);
        packetwrapper.write(Types1_8.METADATA_LIST, list);
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
    }

    public void spawn()
    {
        PacketWrapper packetwrapper = PacketWrapper.create(15, (ByteBuf)null, this.user);
        packetwrapper.write(Type.VAR_INT, Integer.valueOf(this.entityId));
        packetwrapper.write(Type.UNSIGNED_BYTE, Short.valueOf((short)62));
        packetwrapper.write(Type.INT, Integer.valueOf(0));
        packetwrapper.write(Type.INT, Integer.valueOf(0));
        packetwrapper.write(Type.INT, Integer.valueOf(0));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
        packetwrapper.write(Type.SHORT, Short.valueOf((short)0));
        packetwrapper.write(Type.SHORT, Short.valueOf((short)0));
        packetwrapper.write(Type.SHORT, Short.valueOf((short)0));
        List<Metadata> list = new ArrayList<Metadata>();
        list.add(new Metadata(0, MetaType1_9.Byte, 0));
        packetwrapper.write(Types1_8.METADATA_LIST, list);
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class, true, true);
    }

    public void despawn()
    {
        PacketWrapper packetwrapper = PacketWrapper.create(19, (ByteBuf)null, this.user);
        packetwrapper.write(Type.VAR_INT_ARRAY_PRIMITIVE, new int[] {this.entityId});
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class, true, true);
    }

    public int getEntityId()
    {
        return this.entityId;
    }
}

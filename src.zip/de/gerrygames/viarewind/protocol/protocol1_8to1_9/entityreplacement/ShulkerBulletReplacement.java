package de.gerrygames.viarewind.protocol.protocol1_8to1_9.entityreplacement;

import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.replacement.EntityReplacement;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;

public class ShulkerBulletReplacement implements EntityReplacement
{
    private int entityId;
    private List<Metadata> datawatcher = new ArrayList<Metadata>();
    private double locX;
    private double locY;
    private double locZ;
    private float yaw;
    private float pitch;
    private float headYaw;
    private UserConnection user;

    public ShulkerBulletReplacement(int entityId, UserConnection user)
    {
        this.entityId = entityId;
        this.user = user;
        this.spawn();
    }

    public void setLocation(double x, double y, double z)
    {
        if (x != this.locX || y != this.locY || z != this.locZ)
        {
            this.locX = x;
            this.locY = y;
            this.locZ = z;
            this.updateLocation();
        }
    }

    public void relMove(double x, double y, double z)
    {
        if (x != 0.0D || y != 0.0D || z != 0.0D)
        {
            this.locX += x;
            this.locY += y;
            this.locZ += z;
            this.updateLocation();
        }
    }

    public void setYawPitch(float yaw, float pitch)
    {
        if (this.yaw != yaw && this.pitch != pitch)
        {
            this.yaw = yaw;
            this.pitch = pitch;
            this.updateLocation();
        }
    }

    public void setHeadYaw(float yaw)
    {
        this.headYaw = yaw;
    }

    public void updateMetadata(List<Metadata> metadataList)
    {
    }

    public void updateLocation()
    {
        PacketWrapper packetwrapper = PacketWrapper.create(24, (ByteBuf)null, this.user);
        packetwrapper.write(Type.VAR_INT, Integer.valueOf(this.entityId));
        packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locX * 32.0D)));
        packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locY * 32.0D)));
        packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locZ * 32.0D)));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)((int)(this.yaw / 360.0F * 256.0F))));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)((int)(this.pitch / 360.0F * 256.0F))));
        packetwrapper.write(Type.BOOLEAN, Boolean.valueOf(true));
        PacketWrapper packetwrapper1 = PacketWrapper.create(25, (ByteBuf)null, this.user);
        packetwrapper1.write(Type.VAR_INT, Integer.valueOf(this.entityId));
        packetwrapper1.write(Type.BYTE, Byte.valueOf((byte)((int)(this.headYaw / 360.0F * 256.0F))));
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class, true, true);
        PacketUtil.sendPacket(packetwrapper1, Protocol1_8TO1_9.class, true, true);
    }

    public void spawn()
    {
        PacketWrapper packetwrapper = PacketWrapper.create(14, (ByteBuf)null, this.user);
        packetwrapper.write(Type.VAR_INT, Integer.valueOf(this.entityId));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)66));
        packetwrapper.write(Type.INT, Integer.valueOf(0));
        packetwrapper.write(Type.INT, Integer.valueOf(0));
        packetwrapper.write(Type.INT, Integer.valueOf(0));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
        packetwrapper.write(Type.INT, Integer.valueOf(0));
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class, true, true);
    }

    public void despawn()
    {
        PacketWrapper packetwrapper = PacketWrapper.create(19, (ByteBuf)null, this.user);
        packetwrapper.write(Type.VAR_INT_ARRAY_PRIMITIVE, new int[] {this.entityId});
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class, true, true);
    }

    public int getEntityId()
    {
        return this.entityId;
    }
}

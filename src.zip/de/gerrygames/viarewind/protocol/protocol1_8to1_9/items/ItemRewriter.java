package de.gerrygames.viarewind.protocol.protocol1_8to1_9.items;

import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.ByteTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.CompoundTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.ListTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.NumberTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.ShortTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.StringTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.Tag;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.utils.Enchantments;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ItemRewriter
{
    private static Map<String, Integer> ENTTIY_NAME_TO_ID;
    private static Map<Integer, String> ENTTIY_ID_TO_NAME;
    private static Map<String, Integer> POTION_NAME_TO_ID;
    private static Map<Integer, String> POTION_ID_TO_NAME;
    private static Map<String, String> POTION_NAME_INDEX = new HashMap<String, String>();

    public static Item toClient(Item item)
    {
        if (item == null)
        {
            return null;
        }
        else
        {
            CompoundTag compoundtag = item.tag();

            if (compoundtag == null)
            {
                item.setTag(compoundtag = new CompoundTag());
            }

            CompoundTag compoundtag1 = new CompoundTag();
            compoundtag.put("ViaRewind1_8to1_9", compoundtag1);
            compoundtag1.put("id", new ShortTag((short)item.identifier()));
            compoundtag1.put("data", new ShortTag(item.data()));
            CompoundTag compoundtag2 = (CompoundTag)compoundtag.get("display");

            if (compoundtag2 != null && compoundtag2.contains("Name"))
            {
                compoundtag1.put("displayName", new StringTag((String)compoundtag2.get("Name").getValue()));
            }

            if (compoundtag2 != null && compoundtag2.contains("Lore"))
            {
                compoundtag1.put("lore", new ListTag(((ListTag)compoundtag2.get("Lore")).getValue()));
            }

            if (compoundtag.contains("ench") || compoundtag.contains("StoredEnchantments"))
            {
                ListTag listtag = compoundtag.contains("ench") ? (ListTag)compoundtag.get("ench") : (ListTag)compoundtag.get("StoredEnchantments");
                List<Tag> list = new ArrayList<Tag>();
                Iterator attribute = (new ArrayList(listtag.getValue())).iterator();
                label162:

                while (true)
                {
                    Tag tag;
                    short short2;
                    String s;

                    while (true)
                    {
                        if (!attribute.hasNext())
                        {
                            if (!list.isEmpty())
                            {
                                if (compoundtag2 == null)
                                {
                                    compoundtag.put("display", compoundtag2 = new CompoundTag());
                                    compoundtag1.put("noDisplay", new ByteTag());
                                }

                                ListTag listtag3 = (ListTag)compoundtag2.get("Lore");

                                if (listtag3 == null)
                                {
                                    compoundtag2.put("Lore", listtag3 = new ListTag(StringTag.class));
                                }

                                list.addAll(listtag3.getValue());
                                listtag3.setValue(list);
                            }

                            break label162;
                        }

                        tag = (Tag)attribute.next();
                        short short1 = ((NumberTag)((CompoundTag)tag).get("id")).asShort();
                        short2 = ((NumberTag)((CompoundTag)tag).get("lvl")).asShort();

                        if (short1 == 70)
                        {
                            s = "\u00a7r\u00a77Mending ";
                            break;
                        }

                        if (short1 == 9)
                        {
                            s = "\u00a7r\u00a77Frost Walker ";
                            break;
                        }
                    }

                    listtag.remove(tag);
                    s = s + (String)Enchantments.ENCHANTMENTS.getOrDefault(Short.valueOf(short2), "enchantment.level." + short2);
                    list.add(new StringTag(s));
                }
            }

            if (item.data() != 0 && compoundtag.contains("Unbreakable"))
            {
                ByteTag bytetag = (ByteTag)compoundtag.get("Unbreakable");

                if (bytetag.asByte() != 0)
                {
                    compoundtag1.put("Unbreakable", new ByteTag(bytetag.asByte()));
                    compoundtag.remove("Unbreakable");

                    if (compoundtag2 == null)
                    {
                        compoundtag.put("display", compoundtag2 = new CompoundTag());
                        compoundtag1.put("noDisplay", new ByteTag());
                    }

                    ListTag listtag2 = (ListTag)compoundtag2.get("Lore");

                    if (listtag2 == null)
                    {
                        compoundtag2.put("Lore", listtag2 = new ListTag(StringTag.class));
                    }

                    listtag2.add(new StringTag("\u00a79Unbreakable"));
                }
            }

            if (compoundtag.contains("AttributeModifiers"))
            {
                compoundtag1.put("AttributeModifiers", compoundtag.get("AttributeModifiers").clone());
            }

            if (item.identifier() == 383 && item.data() == 0)
            {
                int i = 0;

                if (compoundtag.contains("EntityTag"))
                {
                    CompoundTag compoundtag3 = (CompoundTag)compoundtag.get("EntityTag");

                    if (compoundtag3.contains("id"))
                    {
                        StringTag stringtag1 = (StringTag)compoundtag3.get("id");

                        if (ENTTIY_NAME_TO_ID.containsKey(stringtag1.getValue()))
                        {
                            i = ((Integer)ENTTIY_NAME_TO_ID.get(stringtag1.getValue())).intValue();
                        }
                        else if (compoundtag2 == null)
                        {
                            compoundtag.put("display", compoundtag2 = new CompoundTag());
                            compoundtag1.put("noDisplay", new ByteTag());
                            compoundtag2.put("Name", new StringTag("\u00a7rSpawn " + stringtag1.getValue()));
                        }
                    }
                }

                item.setData((short)i);
            }

            ReplacementRegistry1_8to1_9.replace(item);

            if (item.identifier() == 373 || item.identifier() == 438 || item.identifier() == 441)
            {
                int j = 0;

                if (compoundtag.contains("Potion"))
                {
                    StringTag stringtag = (StringTag)compoundtag.get("Potion");
                    String s1 = stringtag.getValue().replace("minecraft:", "");

                    if (POTION_NAME_TO_ID.containsKey(s1))
                    {
                        j = ((Integer)POTION_NAME_TO_ID.get(s1)).intValue();
                    }

                    if (item.identifier() == 438)
                    {
                        s1 = s1 + "_splash";
                    }
                    else if (item.identifier() == 441)
                    {
                        s1 = s1 + "_lingering";
                    }

                    if ((compoundtag2 == null || !compoundtag2.contains("Name")) && POTION_NAME_INDEX.containsKey(s1))
                    {
                        if (compoundtag2 == null)
                        {
                            compoundtag.put("display", compoundtag2 = new CompoundTag());
                            compoundtag1.put("noDisplay", new ByteTag());
                        }

                        compoundtag2.put("Name", new StringTag(POTION_NAME_INDEX.get(s1)));
                    }
                }

                if (item.identifier() == 438 || item.identifier() == 441)
                {
                    item.setIdentifier(373);
                    j += 8192;
                }

                item.setData((short)j);
            }

            if (compoundtag.contains("AttributeModifiers"))
            {
                ListTag listtag1 = (ListTag)compoundtag.get("AttributeModifiers");

                for (int k = 0; k < listtag1.size(); ++k)
                {
                    CompoundTag compoundtag4 = (CompoundTag)listtag1.get(k);
                    String s2 = (String)compoundtag4.get("AttributeName").getValue();

                    if (!Protocol1_8TO1_9.VALID_ATTRIBUTES.contains(compoundtag4))
                    {
                        listtag1.remove(compoundtag4);
                        --k;
                    }
                }
            }

            if (compoundtag1.size() == 2 && ((Short)compoundtag1.get("id").getValue()).shortValue() == item.identifier() && ((Short)compoundtag1.get("data").getValue()).shortValue() == item.data())
            {
                item.tag().remove("ViaRewind1_8to1_9");

                if (item.tag().isEmpty())
                {
                    item.setTag((CompoundTag)null);
                }
            }

            return item;
        }
    }

    public static Item toServer(Item item)
    {
        if (item == null)
        {
            return null;
        }
        else
        {
            CompoundTag compoundtag = item.tag();

            if (item.identifier() == 383 && item.data() != 0)
            {
                if (compoundtag == null)
                {
                    item.setTag(compoundtag = new CompoundTag());
                }

                if (!compoundtag.contains("EntityTag") && ENTTIY_ID_TO_NAME.containsKey(Integer.valueOf(item.data())))
                {
                    CompoundTag compoundtag1 = new CompoundTag();
                    compoundtag1.put("id", new StringTag(ENTTIY_ID_TO_NAME.get(Integer.valueOf(item.data()))));
                    compoundtag.put("EntityTag", compoundtag1);
                }

                item.setData((short)0);
            }

            if (item.identifier() == 373 && (compoundtag == null || !compoundtag.contains("Potion")))
            {
                if (compoundtag == null)
                {
                    item.setTag(compoundtag = new CompoundTag());
                }

                if (item.data() >= 16384)
                {
                    item.setIdentifier(438);
                    item.setData((short)(item.data() - 8192));
                }

                String s = item.data() == 8192 ? "water" : com.viaversion.viaversion.protocols.protocol1_9to1_8.ItemRewriter.potionNameFromDamage(item.data());
                compoundtag.put("Potion", new StringTag("minecraft:" + s));
                item.setData((short)0);
            }

            if (compoundtag != null && item.tag().contains("ViaRewind1_8to1_9"))
            {
                CompoundTag compoundtag3 = (CompoundTag)compoundtag.remove("ViaRewind1_8to1_9");
                item.setIdentifier(((Short)compoundtag3.get("id").getValue()).shortValue());
                item.setData(((Short)compoundtag3.get("data").getValue()).shortValue());

                if (compoundtag3.contains("noDisplay"))
                {
                    compoundtag.remove("display");
                }

                if (compoundtag3.contains("Unbreakable"))
                {
                    compoundtag.put("Unbreakable", compoundtag3.get("Unbreakable").clone());
                }

                if (compoundtag3.contains("displayName"))
                {
                    CompoundTag compoundtag2 = (CompoundTag)compoundtag.get("display");

                    if (compoundtag2 == null)
                    {
                        compoundtag.put("display", compoundtag2 = new CompoundTag());
                    }

                    StringTag stringtag = (StringTag)compoundtag2.get("Name");

                    if (stringtag == null)
                    {
                        compoundtag2.put("Name", new StringTag((String)compoundtag3.get("displayName").getValue()));
                    }
                    else
                    {
                        stringtag.setValue((String)compoundtag3.get("displayName").getValue());
                    }
                }
                else if (compoundtag.contains("display"))
                {
                    ((CompoundTag)compoundtag.get("display")).remove("Name");
                }

                if (compoundtag3.contains("lore"))
                {
                    CompoundTag compoundtag4 = (CompoundTag)compoundtag.get("display");

                    if (compoundtag4 == null)
                    {
                        compoundtag.put("display", compoundtag4 = new CompoundTag());
                    }

                    ListTag listtag = (ListTag)compoundtag4.get("Lore");

                    if (listtag == null)
                    {
                        compoundtag4.put("Lore", new ListTag((List)compoundtag3.get("lore").getValue()));
                    }
                    else
                    {
                        listtag.setValue((List)compoundtag3.get("lore").getValue());
                    }
                }
                else if (compoundtag.contains("display"))
                {
                    ((CompoundTag)compoundtag.get("display")).remove("Lore");
                }

                compoundtag.remove("AttributeModifiers");

                if (compoundtag3.contains("AttributeModifiers"))
                {
                    compoundtag.put("AttributeModifiers", compoundtag3.get("AttributeModifiers"));
                }

                return item;
            }
            else
            {
                return item;
            }
        }
    }

    static
    {
        for (Field field : ItemRewriter.class.getDeclaredFields())
        {
            try
            {
                Field field1 = com.viaversion.viaversion.protocols.protocol1_9to1_8.ItemRewriter.class.getDeclaredField(field.getName());
                field1.setAccessible(true);
                field.setAccessible(true);
                field.set((Object)null, field1.get((Object)null));
            }
            catch (Exception var5)
            {
                ;
            }
        }

        POTION_NAME_TO_ID.put("luck", Integer.valueOf(8203));
        POTION_NAME_INDEX.put("water", "\u00a7rWater Bottle");
        POTION_NAME_INDEX.put("mundane", "\u00a7rMundane Potion");
        POTION_NAME_INDEX.put("thick", "\u00a7rThick Potion");
        POTION_NAME_INDEX.put("awkward", "\u00a7rAwkward Potion");
        POTION_NAME_INDEX.put("water_splash", "\u00a7rSplash Water Bottle");
        POTION_NAME_INDEX.put("mundane_splash", "\u00a7rMundane Splash Potion");
        POTION_NAME_INDEX.put("thick_splash", "\u00a7rThick Splash Potion");
        POTION_NAME_INDEX.put("awkward_splash", "\u00a7rAwkward Splash Potion");
        POTION_NAME_INDEX.put("water_lingering", "\u00a7rLingering Water Bottle");
        POTION_NAME_INDEX.put("mundane_lingering", "\u00a7rMundane Lingering Potion");
        POTION_NAME_INDEX.put("thick_lingering", "\u00a7rThick Lingering Potion");
        POTION_NAME_INDEX.put("awkward_lingering", "\u00a7rAwkward Lingering Potion");
        POTION_NAME_INDEX.put("night_vision_lingering", "\u00a7rLingering Potion of Night Vision");
        POTION_NAME_INDEX.put("long_night_vision_lingering", "\u00a7rLingering Potion of Night Vision");
        POTION_NAME_INDEX.put("invisibility_lingering", "\u00a7rLingering Potion of Invisibility");
        POTION_NAME_INDEX.put("long_invisibility_lingering", "\u00a7rLingering Potion of Invisibility");
        POTION_NAME_INDEX.put("leaping_lingering", "\u00a7rLingering Potion of Leaping");
        POTION_NAME_INDEX.put("long_leaping_lingering", "\u00a7rLingering Potion of Leaping");
        POTION_NAME_INDEX.put("strong_leaping_lingering", "\u00a7rLingering Potion of Leaping");
        POTION_NAME_INDEX.put("fire_resistance_lingering", "\u00a7rLingering Potion of Fire Resistance");
        POTION_NAME_INDEX.put("long_fire_resistance_lingering", "\u00a7rLingering Potion of Fire Resistance");
        POTION_NAME_INDEX.put("swiftness_lingering", "\u00a7rLingering Potion of Swiftness");
        POTION_NAME_INDEX.put("long_swiftness_lingering", "\u00a7rLingering Potion of Swiftness");
        POTION_NAME_INDEX.put("strong_swiftness_lingering", "\u00a7rLingering Potion of Swiftness");
        POTION_NAME_INDEX.put("slowness_lingering", "\u00a7rLingering Potion of Slowness");
        POTION_NAME_INDEX.put("long_slowness_lingering", "\u00a7rLingering Potion of Slowness");
        POTION_NAME_INDEX.put("water_breathing_lingering", "\u00a7rLingering Potion of Water Breathing");
        POTION_NAME_INDEX.put("long_water_breathing_lingering", "\u00a7rLingering Potion of Water Breathing");
        POTION_NAME_INDEX.put("healing_lingering", "\u00a7rLingering Potion of Healing");
        POTION_NAME_INDEX.put("strong_healing_lingering", "\u00a7rLingering Potion of Healing");
        POTION_NAME_INDEX.put("harming_lingering", "\u00a7rLingering Potion of Harming");
        POTION_NAME_INDEX.put("strong_harming_lingering", "\u00a7rLingering Potion of Harming");
        POTION_NAME_INDEX.put("poison_lingering", "\u00a7rLingering Potion of Poisen");
        POTION_NAME_INDEX.put("long_poison_lingering", "\u00a7rLingering Potion of Poisen");
        POTION_NAME_INDEX.put("strong_poison_lingering", "\u00a7rLingering Potion of Poisen");
        POTION_NAME_INDEX.put("regeneration_lingering", "\u00a7rLingering Potion of Regeneration");
        POTION_NAME_INDEX.put("long_regeneration_lingering", "\u00a7rLingering Potion of Regeneration");
        POTION_NAME_INDEX.put("strong_regeneration_lingering", "\u00a7rLingering Potion of Regeneration");
        POTION_NAME_INDEX.put("strength_lingering", "\u00a7rLingering Potion of Strength");
        POTION_NAME_INDEX.put("long_strength_lingering", "\u00a7rLingering Potion of Strength");
        POTION_NAME_INDEX.put("strong_strength_lingering", "\u00a7rLingering Potion of Strength");
        POTION_NAME_INDEX.put("weakness_lingering", "\u00a7rLingering Potion of Weakness");
        POTION_NAME_INDEX.put("long_weakness_lingering", "\u00a7rLingering Potion of Weakness");
        POTION_NAME_INDEX.put("luck_lingering", "\u00a7rLingering Potion of Luck");
        POTION_NAME_INDEX.put("luck", "\u00a7rPotion of Luck");
        POTION_NAME_INDEX.put("luck_splash", "\u00a7rSplash Potion of Luck");
    }
}

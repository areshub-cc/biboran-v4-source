package de.gerrygames.viarewind.protocol.protocol1_8to1_9.metadata;

import com.viaversion.viaversion.api.minecraft.EulerAngle;
import com.viaversion.viaversion.api.minecraft.Vector;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.minecraft.metadata.types.MetaType1_8;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.metadata.MetaIndex;
import de.gerrygames.viarewind.ViaRewind;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.items.ItemRewriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MetadataRewriter
{
    public static void transform(EntityType type, List<Metadata> list)
    {
        for (Metadata metadata : new ArrayList(list))
        {
            MetaIndex metaindex = MetaIndex1_8to1_9.searchIndex(type, metadata.id());

            try
            {
                if (metaindex == null)
                {
                    throw new Exception("Could not find valid metadata");
                }

                if (metaindex.getOldType() != MetaType1_8.NonExistent && metaindex.getNewType() != null)
                {
                    Object object = metadata.getValue();
                    metadata.setMetaTypeUnsafe(metaindex.getOldType());
                    metadata.setId(metaindex.getIndex());

                    switch (metaindex.getNewType())
                    {
                        case Byte:
                            if (metaindex.getOldType() == MetaType1_8.Byte)
                            {
                                metadata.setValue(object);
                            }

                            if (metaindex.getOldType() == MetaType1_8.Int)
                            {
                                metadata.setValue(Integer.valueOf(((Byte)object).intValue()));
                            }

                            break;

                        case OptUUID:
                            if (metaindex.getOldType() != MetaType1_8.String)
                            {
                                list.remove(metadata);
                            }
                            else
                            {
                                UUID uuid = (UUID)object;

                                if (uuid == null)
                                {
                                    metadata.setValue("");
                                }
                                else
                                {
                                    metadata.setValue(uuid.toString());
                                }
                            }

                            break;

                        case BlockID:
                            list.remove(metadata);
                            list.add(new Metadata(metaindex.getIndex(), MetaType1_8.Short, ((Integer)object).shortValue()));
                            break;

                        case VarInt:
                            if (metaindex.getOldType() == MetaType1_8.Byte)
                            {
                                metadata.setValue(Byte.valueOf(((Integer)object).byteValue()));
                            }

                            if (metaindex.getOldType() == MetaType1_8.Short)
                            {
                                metadata.setValue(Short.valueOf(((Integer)object).shortValue()));
                            }

                            if (metaindex.getOldType() == MetaType1_8.Int)
                            {
                                metadata.setValue(object);
                            }

                            break;

                        case Float:
                            metadata.setValue(object);
                            break;

                        case String:
                            metadata.setValue(object);
                            break;

                        case Boolean:
                            if (metaindex == MetaIndex.AGEABLE_AGE)
                            {
                                metadata.setValue(Byte.valueOf((byte)(((Boolean)object).booleanValue() ? -1 : 0)));
                            }
                            else
                            {
                                metadata.setValue(Byte.valueOf((byte)(((Boolean)object).booleanValue() ? 1 : 0)));
                            }

                            break;

                        case Slot:
                            metadata.setValue(ItemRewriter.toClient((Item)object));
                            break;

                        case Position:
                            Vector vector = (Vector)object;
                            metadata.setValue(vector);
                            break;

                        case Vector3F:
                            EulerAngle eulerangle = (EulerAngle)object;
                            metadata.setValue(eulerangle);
                            break;

                        case Chat:
                            metadata.setValue(object);
                            break;

                        default:
                            ViaRewind.getPlatform().getLogger().warning("[Out] Unhandled MetaDataType: " + metaindex.getNewType());
                            list.remove(metadata);
                    }

                    if (!metaindex.getOldType().type().getOutputClass().isAssignableFrom(metadata.getValue().getClass()))
                    {
                        list.remove(metadata);
                    }
                }
                else
                {
                    list.remove(metadata);
                }
            }
            catch (Exception var9)
            {
                list.remove(metadata);
            }
        }
    }
}

package de.gerrygames.viarewind.protocol.protocol1_8to1_9.metadata;

import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.metadata.MetaIndex;
import com.viaversion.viaversion.util.Pair;
import java.util.HashMap;
import java.util.Optional;

public class MetaIndex1_8to1_9
{
    private static final HashMap<Pair<EntityType, Integer>, MetaIndex> metadataRewrites = new HashMap<Pair<EntityType, Integer>, MetaIndex>();

    private static Optional<MetaIndex> getIndex(EntityType type, int index)
    {
        Pair pair = new Pair(type, index);
        return metadataRewrites.containsKey(pair) ? Optional.of(metadataRewrites.get(pair)) : Optional.empty();
    }

    public static MetaIndex searchIndex(EntityType type, int index)
    {
        EntityType entitytype = type;

        while (true)
        {
            Optional<MetaIndex> optional = getIndex(entitytype, index);

            if (optional.isPresent())
            {
                return optional.get();
            }

            entitytype = entitytype.getParent();

            if (entitytype == null)
            {
                break;
            }
        }

        return null;
    }

    static
    {
        for (MetaIndex metaindex : MetaIndex.values())
        {
            metadataRewrites.put(new Pair(metaindex.getClazz(), metaindex.getNewIndex()), metaindex);
        }
    }
}

package de.gerrygames.viarewind.protocol.protocol1_8to1_9.packets;

import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.protocol.Protocol;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.libs.gson.JsonElement;
import com.viaversion.viaversion.libs.gson.JsonParser;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_8.ServerboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ClientboundPackets1_9;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ServerboundPackets1_9;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.items.ItemRewriter;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.Windows;

public class InventoryPackets
{
    public static void register(Protocol<ClientboundPackets1_9, ClientboundPackets1_8, ServerboundPackets1_9, ServerboundPackets1_8> protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_9.CLOSE_WINDOW, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    ((Windows)packetWrapper.user().get(Windows.class)).remove(short1);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.OPEN_WINDOW, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.STRING);
                this.map(Type.COMPONENT);
                this.map(Type.UNSIGNED_BYTE);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);

                    if (s.equals("EntityHorse"))
                    {
                        packetWrapper.passthrough(Type.INT);
                    }
                });
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    String s = (String)packetWrapper.get(Type.STRING, 0);
                    ((Windows)packetWrapper.user().get(Windows.class)).put(short1, s);
                });
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);

                    if (s.equalsIgnoreCase("minecraft:shulker_box"))
                    {
                        s = "minecraft:container";
                        packetWrapper.set(Type.STRING, 0, "minecraft:container");
                    }

                    String s1 = ((JsonElement)packetWrapper.get(Type.COMPONENT, 0)).toString();

                    if (s1.equalsIgnoreCase("{\"translate\":\"container.shulkerBox\"}"))
                    {
                        packetWrapper.set(Type.COMPONENT, 0, JsonParser.parseString("{\"text\":\"Shulker Box\"}"));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.WINDOW_ITEMS, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    Item[] aitem = (Item[])packetWrapper.read(Type.ITEM_ARRAY);

                    for (int i = 0; i < aitem.length; ++i)
                    {
                        aitem[i] = ItemRewriter.toClient(aitem[i]);
                    }

                    if (short1 == 0 && aitem.length == 46)
                    {
                        Item[] aitem2 = aitem;
                        aitem = new Item[45];
                        System.arraycopy(aitem2, 0, aitem, 0, 45);
                    }
                    else {
                        String s = ((Windows)packetWrapper.user().get(Windows.class)).get(short1);

                        if (s != null && s.equalsIgnoreCase("minecraft:brewing_stand"))
                        {
                            System.arraycopy(aitem, 0, ((Windows)packetWrapper.user().get(Windows.class)).getBrewingItems(short1), 0, 4);
                            Windows.updateBrewingStand(packetWrapper.user(), aitem[4], short1);
                            Item[] aitem1 = aitem;
                            aitem = new Item[aitem.length - 1];
                            System.arraycopy(aitem1, 0, aitem, 0, 4);
                            System.arraycopy(aitem1, 5, aitem, 4, aitem1.length - 5);
                        }
                    }

                    packetWrapper.write(Type.ITEM_ARRAY, aitem);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.SET_SLOT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.SHORT);
                this.map(Type.ITEM);
                this.handler((packetWrapper) ->
                {
                    packetWrapper.set(Type.ITEM, 0, ItemRewriter.toClient((Item)packetWrapper.get(Type.ITEM, 0)));
                    byte b0 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).byteValue();
                    short short1 = ((Short)packetWrapper.get(Type.SHORT, 0)).shortValue();

                    if (b0 == 0 && short1 == 45)
                    {
                        packetWrapper.cancel();
                    }
                    else {
                        String s = ((Windows)packetWrapper.user().get(Windows.class)).get((short)b0);

                        if (s != null)
                        {
                            if (s.equalsIgnoreCase("minecraft:brewing_stand"))
                            {
                                if (short1 > 4)
                                {
                                    --short1;
                                    packetWrapper.set(Type.SHORT, 0, Short.valueOf(short1));
                                }
                                else
                                {
                                    if (short1 == 4)
                                    {
                                        packetWrapper.cancel();
                                        Windows.updateBrewingStand(packetWrapper.user(), (Item)packetWrapper.get(Type.ITEM, 0), (short)b0);
                                        return;
                                    }

                                    ((Windows)packetWrapper.user().get(Windows.class)).getBrewingItems((short)b0)[short1] = (Item)packetWrapper.get(Type.ITEM, 0);
                                }
                            }
                        }
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.CLOSE_WINDOW, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    ((Windows)packetWrapper.user().get(Windows.class)).remove(short1);
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.CLICK_WINDOW, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.SHORT);
                this.map(Type.BYTE);
                this.map(Type.SHORT);
                this.map(Type.BYTE, Type.VAR_INT);
                this.map(Type.ITEM);
                this.handler((packetWrapper) ->
                {
                    packetWrapper.set(Type.ITEM, 0, ItemRewriter.toServer((Item)packetWrapper.get(Type.ITEM, 0)));
                });
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    Windows windows = (Windows)packetWrapper.user().get(Windows.class);
                    String s = windows.get(short1);

                    if (s != null)
                    {
                        if (s.equalsIgnoreCase("minecraft:brewing_stand"))
                        {
                            short short2 = ((Short)packetWrapper.get(Type.SHORT, 0)).shortValue();

                            if (short2 > 3)
                            {
                                ++short2;
                                packetWrapper.set(Type.SHORT, 0, Short.valueOf(short2));
                            }
                        }
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.CREATIVE_INVENTORY_ACTION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.SHORT);
                this.map(Type.ITEM);
                this.handler((packetWrapper) ->
                {
                    packetWrapper.set(Type.ITEM, 0, ItemRewriter.toServer((Item)packetWrapper.get(Type.ITEM, 0)));
                });
            }
        });
    }
}

package de.gerrygames.viarewind.protocol.protocol1_8to1_9.packets;

import com.viaversion.viaversion.api.minecraft.Vector;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.protocol.Protocol;
import com.viaversion.viaversion.api.protocol.packet.ClientboundPacketType;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.types.version.Types1_8;
import com.viaversion.viaversion.api.type.types.version.Types1_9;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_8.ServerboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ClientboundPackets1_9;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ServerboundPackets1_9;
import com.viaversion.viaversion.util.Pair;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.items.ItemRewriter;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.metadata.MetadataRewriter;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.Cooldown;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.EntityTracker;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.Levitation;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.PlayerPosition;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.util.RelativeMoveUtil;
import de.gerrygames.viarewind.replacement.EntityReplacement;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class EntityPackets
{
    public static void register(Protocol<ClientboundPackets1_9, ClientboundPackets1_8, ServerboundPackets1_9, ServerboundPackets1_8> protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_STATUS, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.handler((packetWrapper) ->
                {
                    byte b0 = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();

                    if (b0 > 23)
                    {
                        packetWrapper.cancel();
                    }
                    else {
                        packetWrapper.write(Type.BYTE, Byte.valueOf(b0));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_POSITION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    int j = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                    int k = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                    int l = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        entityreplacement.relMove((double)j / 4096.0D, (double)k / 4096.0D, (double)l / 4096.0D);
                    }
                    else {
                        Vector[] avector = RelativeMoveUtil.calculateRelativeMoves(packetWrapper.user(), i, j, k, l);
                        packetWrapper.write(Type.BYTE, Byte.valueOf((byte)avector[0].getBlockX()));
                        packetWrapper.write(Type.BYTE, Byte.valueOf((byte)avector[0].getBlockY()));
                        packetWrapper.write(Type.BYTE, Byte.valueOf((byte)avector[0].getBlockZ()));
                        boolean flag = ((Boolean)packetWrapper.passthrough(Type.BOOLEAN)).booleanValue();

                        if (avector.length > 1)
                        {
                            PacketWrapper packetwrapper = PacketWrapper.create(21, (ByteBuf)null, packetWrapper.user());
                            packetwrapper.write(Type.VAR_INT, (Integer)packetWrapper.get(Type.VAR_INT, 0));
                            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)avector[1].getBlockX()));
                            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)avector[1].getBlockY()));
                            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)avector[1].getBlockZ()));
                            packetwrapper.write(Type.BOOLEAN, Boolean.valueOf(flag));
                            PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
                        }
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_POSITION_AND_ROTATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    int j = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                    int k = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                    int l = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        entityreplacement.relMove((double)j / 4096.0D, (double)k / 4096.0D, (double)l / 4096.0D);
                        entityreplacement.setYawPitch((float)((Byte)packetWrapper.read(Type.BYTE)).byteValue() * 360.0F / 256.0F, (float)((Byte)packetWrapper.read(Type.BYTE)).byteValue() * 360.0F / 256.0F);
                    }
                    else {
                        Vector[] avector = RelativeMoveUtil.calculateRelativeMoves(packetWrapper.user(), i, j, k, l);
                        packetWrapper.write(Type.BYTE, Byte.valueOf((byte)avector[0].getBlockX()));
                        packetWrapper.write(Type.BYTE, Byte.valueOf((byte)avector[0].getBlockY()));
                        packetWrapper.write(Type.BYTE, Byte.valueOf((byte)avector[0].getBlockZ()));
                        byte b0 = ((Byte)packetWrapper.passthrough(Type.BYTE)).byteValue();
                        byte b1 = ((Byte)packetWrapper.passthrough(Type.BYTE)).byteValue();
                        boolean flag = ((Boolean)packetWrapper.passthrough(Type.BOOLEAN)).booleanValue();
                        EntityType entitytype = (EntityType)((EntityTracker)packetWrapper.user().get(EntityTracker.class)).getClientEntityTypes().get(Integer.valueOf(i));

                        if (entitytype == EntityType.BOAT)
                        {
                            b0 = (byte)(b0 - 64);
                            packetWrapper.set(Type.BYTE, 3, Byte.valueOf(b0));
                        }

                        if (avector.length > 1)
                        {
                            PacketWrapper packetwrapper = PacketWrapper.create(23, (ByteBuf)null, packetWrapper.user());
                            packetwrapper.write(Type.VAR_INT, (Integer)packetWrapper.get(Type.VAR_INT, 0));
                            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)avector[1].getBlockX()));
                            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)avector[1].getBlockY()));
                            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)avector[1].getBlockZ()));
                            packetwrapper.write(Type.BYTE, Byte.valueOf(b0));
                            packetwrapper.write(Type.BYTE, Byte.valueOf(b1));
                            packetwrapper.write(Type.BOOLEAN, Boolean.valueOf(flag));
                            PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
                        }
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_ROTATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        int j = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        int k = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                        entityreplacement.setYawPitch((float)j * 360.0F / 256.0F, (float)k * 360.0F / 256.0F);
                    }
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityType entitytype = (EntityType)((EntityTracker)packetWrapper.user().get(EntityTracker.class)).getClientEntityTypes().get(Integer.valueOf(i));

                    if (entitytype == EntityType.BOAT)
                    {
                        byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        b0 = (byte)(b0 - 64);
                        packetWrapper.set(Type.BYTE, 0, Byte.valueOf(b0));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.VEHICLE_MOVE, ClientboundPackets1_8.ENTITY_TELEPORT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    int i = entitytracker.getVehicle(entitytracker.getPlayerId());

                    if (i == -1)
                    {
                        packetWrapper.cancel();
                    }

                    packetWrapper.write(Type.VAR_INT, Integer.valueOf(i));
                });
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.FLOAT, Protocol1_8TO1_9.DEGREES_TO_ANGLE);
                this.map(Type.FLOAT, Protocol1_8TO1_9.DEGREES_TO_ANGLE);
                this.handler((packetWrapper) ->
                {
                    if (!packetWrapper.isCancelled())
                    {
                        PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);
                        double d0 = (double)((Integer)packetWrapper.get(Type.INT, 0)).intValue() / 32.0D;
                        double d1 = (double)((Integer)packetWrapper.get(Type.INT, 1)).intValue() / 32.0D;
                        double d2 = (double)((Integer)packetWrapper.get(Type.INT, 2)).intValue() / 32.0D;
                        playerposition.setPos(d0, d1, d2);
                    }
                });
                this.create(Type.BOOLEAN, Boolean.valueOf(true));
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityType entitytype = (EntityType)((EntityTracker)packetWrapper.user().get(EntityTracker.class)).getClientEntityTypes().get(Integer.valueOf(i));

                    if (entitytype == EntityType.BOAT)
                    {
                        byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                        b0 = (byte)(b0 - 64);
                        packetWrapper.set(Type.BYTE, 0, Byte.valueOf(b0));
                        int j = ((Integer)packetWrapper.get(Type.INT, 1)).intValue();
                        j = j + 10;
                        packetWrapper.set(Type.INT, 1, Integer.valueOf(j));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.DESTROY_ENTITIES, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT_ARRAY_PRIMITIVE);
                this.handler((packetWrapper) ->
                {
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);

                    for (int i : (int[])packetWrapper.get(Type.VAR_INT_ARRAY_PRIMITIVE, 0))
                    {
                        entitytracker.removeEntity(i);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.REMOVE_ENTITY_EFFECT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.BYTE);
                this.handler((packetWrapper) ->
                {
                    int i = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();

                    if (i > 23)
                    {
                        packetWrapper.cancel();
                    }

                    if (i == 25)
                    {
                        if (((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue() != ((EntityTracker)packetWrapper.user().get(EntityTracker.class)).getPlayerId())
                        {
                            return;
                        }

                        Levitation levitation = (Levitation)packetWrapper.user().get(Levitation.class);
                        levitation.setActive(false);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_HEAD_LOOK, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.BYTE);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        int j = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        entityreplacement.setHeadYaw((float)j * 360.0F / 256.0F);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_METADATA, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Types1_9.METADATA_LIST, Types1_8.METADATA_LIST);
                this.handler((wrapper) ->
                {
                    List<Metadata> list = (List)wrapper.get(Types1_8.METADATA_LIST, 0);
                    int i = ((Integer)wrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)wrapper.user().get(EntityTracker.class);

                    if (entitytracker.getClientEntityTypes().containsKey(Integer.valueOf(i)))
                    {
                        MetadataRewriter.transform((EntityType)entitytracker.getClientEntityTypes().get(Integer.valueOf(i)), list);

                        if (list.isEmpty())
                        {
                            wrapper.cancel();
                        }
                    }
                    else {
                        entitytracker.addMetadataToBuffer(i, list);
                        wrapper.cancel();
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ATTACH_ENTITY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.map(Type.INT);
                this.create(Type.BOOLEAN, Boolean.valueOf(true));
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_EQUIPMENT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();

                    if (i == 1)
                    {
                        packetWrapper.cancel();
                    }
                    else if (i > 1)
                    {
                        --i;
                    }

                    packetWrapper.write(Type.SHORT, Short.valueOf((short)i));
                });
                this.map(Type.ITEM);
                this.handler((packetWrapper) ->
                {
                    packetWrapper.set(Type.ITEM, 0, ItemRewriter.toClient((Item)packetWrapper.get(Type.ITEM, 0)));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.SET_PASSENGERS, (ClientboundPacketType)null, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    packetWrapper.cancel();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    int j = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    ArrayList<Integer> arraylist = new ArrayList<Integer>();

                    for (int k = 0; k < j; ++k)
                    {
                        arraylist.add((Integer)packetWrapper.read(Type.VAR_INT));
                    }

                    List<Integer> list = entitytracker.getPassengers(i);
                    entitytracker.setPassengers(i, arraylist);

                    if (!list.isEmpty())
                    {
                        for (Integer integer : list)
                        {
                            PacketWrapper packetwrapper = PacketWrapper.create(27, (ByteBuf)null, packetWrapper.user());
                            packetwrapper.write(Type.INT, integer);
                            packetwrapper.write(Type.INT, Integer.valueOf(-1));
                            packetwrapper.write(Type.BOOLEAN, Boolean.valueOf(false));
                            PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
                        }
                    }

                    for (int l = 0; l < j; ++l)
                    {
                        int i1 = l == 0 ? i : ((Integer)arraylist.get(l - 1)).intValue();
                        int j1 = ((Integer)arraylist.get(l)).intValue();
                        PacketWrapper packetwrapper1 = PacketWrapper.create(27, (ByteBuf)null, packetWrapper.user());
                        packetwrapper1.write(Type.INT, Integer.valueOf(j1));
                        packetwrapper1.write(Type.INT, Integer.valueOf(i1));
                        packetwrapper1.write(Type.BOOLEAN, Boolean.valueOf(false));
                        PacketUtil.sendPacket(packetwrapper1, Protocol1_8TO1_9.class);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_TELEPORT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityType entitytype = (EntityType)((EntityTracker)packetWrapper.user().get(EntityTracker.class)).getClientEntityTypes().get(Integer.valueOf(i));

                    if (entitytype == EntityType.BOAT)
                    {
                        byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                        b0 = (byte)(b0 - 64);
                        packetWrapper.set(Type.BYTE, 0, Byte.valueOf(b0));
                        int j = ((Integer)packetWrapper.get(Type.INT, 1)).intValue();
                        j = j + 10;
                        packetWrapper.set(Type.INT, 1, Integer.valueOf(j));
                    }
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    ((EntityTracker)packetWrapper.user().get(EntityTracker.class)).resetEntityOffset(i);
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        int j = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                        int k = ((Integer)packetWrapper.get(Type.INT, 1)).intValue();
                        int l = ((Integer)packetWrapper.get(Type.INT, 2)).intValue();
                        int i1 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        int j1 = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                        entityreplacement.setLocation((double)j / 32.0D, (double)k / 32.0D, (double)l / 32.0D);
                        entityreplacement.setYawPitch((float)i1 * 360.0F / 256.0F, (float)j1 * 360.0F / 256.0F);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_PROPERTIES, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.INT);
                this.handler((packetWrapper) ->
                {
                    boolean flag = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue() == ((EntityTracker)packetWrapper.user().get(EntityTracker.class)).getPlayerId();
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    int j = 0;

                    for (int k = 0; k < i; ++k)
                    {
                        String s = (String)packetWrapper.read(Type.STRING);
                        boolean flag1 = !Protocol1_8TO1_9.VALID_ATTRIBUTES.contains(s);
                        double d0 = ((Double)packetWrapper.read(Type.DOUBLE)).doubleValue();
                        int l = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();

                        if (!flag1)
                        {
                            packetWrapper.write(Type.STRING, s);
                            packetWrapper.write(Type.DOUBLE, Double.valueOf(d0));
                            packetWrapper.write(Type.VAR_INT, Integer.valueOf(l));
                        }
                        else
                        {
                            ++j;
                        }

                        ArrayList<Pair<Byte, Double>> arraylist = new ArrayList<Pair<Byte, Double>>();

                        for (int i1 = 0; i1 < l; ++i1)
                        {
                            UUID uuid = (UUID)packetWrapper.read(Type.UUID);
                            double d1 = ((Double)packetWrapper.read(Type.DOUBLE)).doubleValue();
                            byte b0 = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();
                            arraylist.add(new Pair(b0, d1));

                            if (!flag1)
                            {
                                packetWrapper.write(Type.UUID, uuid);
                                packetWrapper.write(Type.DOUBLE, Double.valueOf(d1));
                                packetWrapper.write(Type.BYTE, Byte.valueOf(b0));
                            }
                        }

                        if (flag && s.equals("generic.attackSpeed"))
                        {
                            ((Cooldown)packetWrapper.user().get(Cooldown.class)).setAttackSpeed(d0, arraylist);
                        }
                    }

                    packetWrapper.set(Type.INT, 0, Integer.valueOf(i - j));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.ENTITY_EFFECT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.VAR_INT);
                this.map(Type.BYTE);
                this.handler((packetWrapper) ->
                {
                    int i = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();

                    if (i > 23)
                    {
                        packetWrapper.cancel();
                    }

                    if (i == 25)
                    {
                        if (((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue() != ((EntityTracker)packetWrapper.user().get(EntityTracker.class)).getPlayerId())
                        {
                            return;
                        }

                        Levitation levitation = (Levitation)packetWrapper.user().get(Levitation.class);
                        levitation.setActive(true);
                        levitation.setAmplifier(((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue());
                    }
                });
            }
        });
    }
}

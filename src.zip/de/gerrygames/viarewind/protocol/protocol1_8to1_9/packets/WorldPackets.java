package de.gerrygames.viarewind.protocol.protocol1_8to1_9.packets;

import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.minecraft.BlockChangeRecord;
import com.viaversion.viaversion.api.minecraft.Environment;
import com.viaversion.viaversion.api.minecraft.Position;
import com.viaversion.viaversion.api.minecraft.chunks.BaseChunk;
import com.viaversion.viaversion.api.minecraft.chunks.Chunk;
import com.viaversion.viaversion.api.minecraft.chunks.ChunkSection;
import com.viaversion.viaversion.api.minecraft.chunks.ChunkSectionImpl;
import com.viaversion.viaversion.api.protocol.Protocol;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.CompoundTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.StringTag;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_8.ServerboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_9_3to1_9_1_2.storage.ClientWorld;
import com.viaversion.viaversion.protocols.protocol1_9_3to1_9_1_2.types.Chunk1_9_1_2Type;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ClientboundPackets1_9;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ServerboundPackets1_9;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.types.Chunk1_8Type;
import de.gerrygames.viarewind.ViaRewind;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.items.ReplacementRegistry1_8to1_9;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.sound.Effect;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.sound.SoundRemapper;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.function.Consumer;

public class WorldPackets
{
    public static void register(Protocol<ClientboundPackets1_9, ClientboundPackets1_8, ServerboundPackets1_9, ServerboundPackets1_8> protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_9.BLOCK_ENTITY_DATA, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.POSITION);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.NBT);
                this.handler((packetWrapper) ->
                {
                    CompoundTag compoundtag = (CompoundTag)packetWrapper.get(Type.NBT, 0);

                    if (compoundtag != null && compoundtag.contains("SpawnData"))
                    {
                        String s = (String)((CompoundTag)compoundtag.get("SpawnData")).get("id").getValue();
                        compoundtag.remove("SpawnData");
                        compoundtag.put("entityId", new StringTag(s));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.BLOCK_ACTION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.POSITION);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();

                    if (i >= 219 && i <= 234)
                    {
                        i = 130;
                        packetWrapper.set(Type.VAR_INT, 0, Integer.valueOf(130));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.BLOCK_CHANGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.POSITION);
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    int j = ReplacementRegistry1_8to1_9.replace(i);
                    packetWrapper.set(Type.VAR_INT, 0, Integer.valueOf(j));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.MULTI_BLOCK_CHANGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.BLOCK_CHANGE_RECORD_ARRAY);
                this.handler((packetWrapper) ->
                {
                    for (BlockChangeRecord blockchangerecord : (BlockChangeRecord[])packetWrapper.get(Type.BLOCK_CHANGE_RECORD_ARRAY, 0))
                    {
                        int i = ReplacementRegistry1_8to1_9.replace(blockchangerecord.getBlockId());
                        blockchangerecord.setBlockId(i);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.NAMED_SOUND, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);
                    s = SoundRemapper.getOldName(s);

                    if (s == null)
                    {
                        packetWrapper.cancel();
                    }
                    else {
                        packetWrapper.set(Type.STRING, 0, s);
                    }
                });
                this.map(Type.VAR_INT, Type.NOTHING);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.FLOAT);
                this.map(Type.UNSIGNED_BYTE);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.EXPLOSION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    packetWrapper.write(Type.INT, Integer.valueOf(i));

                    for (int j = 0; j < i; ++j)
                    {
                        packetWrapper.passthrough(Type.UNSIGNED_BYTE);
                        packetWrapper.passthrough(Type.UNSIGNED_BYTE);
                        packetWrapper.passthrough(Type.UNSIGNED_BYTE);
                    }
                });
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.UNLOAD_CHUNK, ClientboundPackets1_8.CHUNK_DATA, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    int j = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    ClientWorld clientworld = (ClientWorld)packetWrapper.user().get(ClientWorld.class);
                    packetWrapper.write(new Chunk1_8Type(clientworld), new BaseChunk(i, j, true, false, 0, new ChunkSection[16], (int[])null, new ArrayList()));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.CHUNK_DATA, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    ClientWorld clientworld = (ClientWorld)packetWrapper.user().get(ClientWorld.class);
                    Chunk chunk = (Chunk)packetWrapper.read(new Chunk1_9_1_2Type(clientworld));

                    for (ChunkSection chunksection : chunk.getSections())
                    {
                        if (chunksection != null)
                        {
                            for (int i = 0; i < chunksection.getPaletteSize(); ++i)
                            {
                                int j = chunksection.getPaletteEntry(i);
                                int k = ReplacementRegistry1_8to1_9.replace(j);
                                chunksection.setPaletteEntry(i, k);
                            }
                        }
                    }

                    if (chunk.isFullChunk() && chunk.getBitmask() == 0)
                    {
                        boolean flag = clientworld.getEnvironment() == Environment.NORMAL;
                        ChunkSection[] achunksection = new ChunkSection[16];
                        ChunkSection chunksection1 = new ChunkSectionImpl(true);
                        achunksection[0] = chunksection1;
                        chunksection1.addPaletteEntry(0);

                        if (flag)
                        {
                            chunksection1.getLight().setSkyLight(new byte[2048]);
                        }

                        chunk = new BaseChunk(chunk.getX(), chunk.getZ(), true, false, 1, achunksection, chunk.getBiomeData(), chunk.getBlockEntities());
                    }

                    packetWrapper.write(new Chunk1_8Type(clientworld), chunk);
                    UserConnection userconnection = packetWrapper.user();
                    chunk.getBlockEntities().forEach((nbt) -> {
                        if (nbt.contains("x") && nbt.contains("y") && nbt.contains("z") && nbt.contains("id"))
                        {
                            Position position = new Position(((Integer)nbt.get("x").getValue()).intValue(), (short)((Integer)nbt.get("y").getValue()).intValue(), ((Integer)nbt.get("z").getValue()).intValue());
                            String s = (String)nbt.get("id").getValue();
                            byte b0 = -1;

                            switch (s.hashCode())
                            {
                                case -1883218338:
                                    if (s.equals("minecraft:flower_pot"))
                                    {
                                        b0 = 4;
                                    }

                                    break;

                                case -1296947815:
                                    if (s.equals("minecraft:banner"))
                                    {
                                        b0 = 5;
                                    }

                                    break;

                                case -1293651279:
                                    if (s.equals("minecraft:beacon"))
                                    {
                                        b0 = 2;
                                    }

                                    break;

                                case -1134211248:
                                    if (s.equals("minecraft:skull"))
                                    {
                                        b0 = 3;
                                    }

                                    break;

                                case -199249700:
                                    if (s.equals("minecraft:mob_spawner"))
                                    {
                                        b0 = 0;
                                    }

                                    break;

                                case 339138444:
                                    if (s.equals("minecraft:command_block"))
                                    {
                                        b0 = 1;
                                    }
                            }

                            short short1;

                            switch (b0)
                            {
                                case 0:
                                    short1 = 1;
                                    break;

                                case 1:
                                    short1 = 2;
                                    break;

                                case 2:
                                    short1 = 3;
                                    break;

                                case 3:
                                    short1 = 4;
                                    break;

                                case 4:
                                    short1 = 5;
                                    break;

                                case 5:
                                    short1 = 6;
                                    break;

                                default:
                                    return;
                            }

                            PacketWrapper packetwrapper = PacketWrapper.create(9, (ByteBuf)null, user);
                            packetwrapper.write(Type.POSITION, position);
                            packetwrapper.write(Type.UNSIGNED_BYTE, Short.valueOf(short1));
                            packetwrapper.write(Type.NBT, nbt);
                            PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class, false, false);
                        }
                    });
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.EFFECT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.map(Type.POSITION);
                this.map(Type.INT);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    i = Effect.getOldId(i);

                    if (i == -1)
                    {
                        packetWrapper.cancel();
                    }
                    else {
                        packetWrapper.set(Type.INT, 0, Integer.valueOf(i));

                        if (i == 2001)
                        {
                            int j = ReplacementRegistry1_8to1_9.replace(((Integer)packetWrapper.get(Type.INT, 1)).intValue());
                            packetWrapper.set(Type.INT, 1, Integer.valueOf(j));
                        }
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.SPAWN_PARTICLE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();

                    if (i > 41 && !ViaRewind.getConfig().isReplaceParticles())
                    {
                        packetWrapper.cancel();
                    }
                    else {
                        if (i == 42)
                        {
                            packetWrapper.set(Type.INT, 0, Integer.valueOf(24));
                        }
                        else if (i == 43)
                        {
                            packetWrapper.set(Type.INT, 0, Integer.valueOf(3));
                        }
                        else if (i == 44)
                        {
                            packetWrapper.set(Type.INT, 0, Integer.valueOf(34));
                        }
                        else if (i == 45)
                        {
                            packetWrapper.set(Type.INT, 0, Integer.valueOf(1));
                        }
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.MAP_DATA, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.BYTE);
                this.map(Type.BOOLEAN, Type.NOTHING);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.SOUND, ClientboundPackets1_8.NAMED_SOUND, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    String s = SoundRemapper.oldNameFromId(i);

                    if (s == null)
                    {
                        packetWrapper.cancel();
                    }
                    else {
                        packetWrapper.write(Type.STRING, s);
                    }
                });
                this.handler((packetWrapper) ->
                {
                    packetWrapper.read(Type.VAR_INT);
                });
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.FLOAT);
                this.map(Type.UNSIGNED_BYTE);
            }
        });
    }
}

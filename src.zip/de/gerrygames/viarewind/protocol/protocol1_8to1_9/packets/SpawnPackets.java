package de.gerrygames.viarewind.protocol.protocol1_8to1_9.packets;

import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.protocol.Protocol;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.types.version.Types1_8;
import com.viaversion.viaversion.api.type.types.version.Types1_9;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_8.ServerboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ClientboundPackets1_9;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ServerboundPackets1_9;
import de.gerrygames.viarewind.ViaRewind;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.entityreplacement.ShulkerBulletReplacement;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.entityreplacement.ShulkerReplacement;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.items.ReplacementRegistry1_8to1_9;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.metadata.MetadataRewriter;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.EntityTracker;
import de.gerrygames.viarewind.replacement.EntityReplacement;
import de.gerrygames.viarewind.replacement.Replacement;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.List;

public class SpawnPackets
{
    public static void register(Protocol<ClientboundPackets1_9, ClientboundPackets1_8, ServerboundPackets1_9, ServerboundPackets1_8> protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_9.SPAWN_ENTITY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.UUID, Type.NOTHING);
                this.map(Type.BYTE);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    int j = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityType entitytype = Entity1_10Types.getTypeFromId(j, true);

                    if (j != 3 && j != 91 && j != 92 && j != 93)
                    {
                        if (entitytype == null)
                        {
                            ViaRewind.getPlatform().getLogger().warning("[ViaRewind] Unhandled Spawn Object Type: " + j);
                            packetWrapper.cancel();
                        }
                        else
                        {
                            int k = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                            int l = ((Integer)packetWrapper.get(Type.INT, 1)).intValue();
                            int i1 = ((Integer)packetWrapper.get(Type.INT, 2)).intValue();

                            if (entitytype.is(EntityType.BOAT))
                            {
                                byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                                b0 = (byte)(b0 - 64);
                                packetWrapper.set(Type.BYTE, 1, Byte.valueOf(b0));
                                l = l + 10;
                                packetWrapper.set(Type.INT, 1, Integer.valueOf(l));
                            }
                            else if (entitytype.is(EntityType.SHULKER_BULLET))
                            {
                                packetWrapper.cancel();
                                ShulkerBulletReplacement shulkerbulletreplacement = new ShulkerBulletReplacement(i, packetWrapper.user());
                                shulkerbulletreplacement.setLocation((double)k / 32.0D, (double)l / 32.0D, (double)i1 / 32.0D);
                                entitytracker.addEntityReplacement(shulkerbulletreplacement);
                                return;
                            }

                            int l1 = ((Integer)packetWrapper.get(Type.INT, 3)).intValue();

                            if (entitytype.isOrHasParent(EntityType.ARROW) && l1 != 0)
                            {
                                --l1;
                                packetWrapper.set(Type.INT, 3, Integer.valueOf(l1));
                            }

                            if (entitytype.is(EntityType.FALLING_BLOCK))
                            {
                                int j1 = l1 & 4095;
                                int k1 = l1 >> 12 & 15;
                                Replacement replacement = ReplacementRegistry1_8to1_9.getReplacement(j1, k1);

                                if (replacement != null)
                                {
                                    packetWrapper.set(Type.INT, 3, Integer.valueOf(replacement.getId() | replacement.replaceData(l1) << 12));
                                }
                            }

                            if (l1 > 0)
                            {
                                packetWrapper.passthrough(Type.SHORT);
                                packetWrapper.passthrough(Type.SHORT);
                                packetWrapper.passthrough(Type.SHORT);
                            }
                            else
                            {
                                short short1 = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                                short short2 = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                                short short3 = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                                PacketWrapper packetwrapper = PacketWrapper.create(18, (ByteBuf)null, packetWrapper.user());
                                packetwrapper.write(Type.VAR_INT, Integer.valueOf(i));
                                packetwrapper.write(Type.SHORT, Short.valueOf(short1));
                                packetwrapper.write(Type.SHORT, Short.valueOf(short2));
                                packetwrapper.write(Type.SHORT, Short.valueOf(short3));
                                PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
                            }

                            entitytracker.getClientEntityTypes().put(Integer.valueOf(i), entitytype);
                            entitytracker.sendMetadataBuffer(i);
                        }
                    }
                    else {
                        packetWrapper.cancel();
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.SPAWN_EXPERIENCE_ORB, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.SHORT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), EntityType.EXPERIENCE_ORB);
                    entitytracker.sendMetadataBuffer(i);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.SPAWN_GLOBAL_ENTITY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.BYTE);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), EntityType.LIGHTNING);
                    entitytracker.sendMetadataBuffer(i);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.SPAWN_MOB, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.UUID, Type.NOTHING);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.SHORT);
                this.map(Type.SHORT);
                this.map(Type.SHORT);
                this.map(Types1_9.METADATA_LIST, Types1_8.METADATA_LIST);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    int j = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    int k = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    int l = ((Integer)packetWrapper.get(Type.INT, 1)).intValue();
                    int i1 = ((Integer)packetWrapper.get(Type.INT, 2)).intValue();
                    byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                    byte b1 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                    byte b2 = ((Byte)packetWrapper.get(Type.BYTE, 2)).byteValue();

                    if (j == 69)
                    {
                        packetWrapper.cancel();
                        EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                        ShulkerReplacement shulkerreplacement = new ShulkerReplacement(i, packetWrapper.user());
                        shulkerreplacement.setLocation((double)k / 32.0D, (double)l / 32.0D, (double)i1 / 32.0D);
                        shulkerreplacement.setYawPitch((float)b1 * 360.0F / 256.0F, (float)b0 * 360.0F / 256.0F);
                        shulkerreplacement.setHeadYaw((float)b2 * 360.0F / 256.0F);
                        entitytracker.addEntityReplacement(shulkerreplacement);
                    }
                    else if (j == -1 || j == 255)
                    {
                        packetWrapper.cancel();
                    }
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    int j = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), Entity1_10Types.getTypeFromId(j, false));
                    entitytracker.sendMetadataBuffer(i);
                });
                this.handler((wrapper) ->
                {
                    List<Metadata> list = (List)wrapper.get(Types1_8.METADATA_LIST, 0);
                    int i = ((Integer)wrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)wrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement;

                    if ((entityreplacement = entitytracker.getEntityReplacement(i)) != null)
                    {
                        entityreplacement.updateMetadata(list);
                    }
                    else if (entitytracker.getClientEntityTypes().containsKey(Integer.valueOf(i)))
                    {
                        MetadataRewriter.transform((EntityType)entitytracker.getClientEntityTypes().get(Integer.valueOf(i)), list);
                    }
                    else {
                        wrapper.cancel();
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.SPAWN_PAINTING, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.UUID, Type.NOTHING);
                this.map(Type.STRING);
                this.map(Type.POSITION);
                this.map(Type.BYTE, Type.UNSIGNED_BYTE);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), EntityType.PAINTING);
                    entitytracker.sendMetadataBuffer(i);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.SPAWN_PLAYER, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.UUID);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.DOUBLE, Protocol1_8TO1_9.TO_OLD_INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.handler((packetWrapper) ->
                {
                    packetWrapper.write(Type.SHORT, Short.valueOf((short)0));
                });
                this.map(Types1_9.METADATA_LIST, Types1_8.METADATA_LIST);
                this.handler((wrapper) ->
                {
                    List<Metadata> list = (List)wrapper.get(Types1_8.METADATA_LIST, 0);
                    MetadataRewriter.transform(EntityType.PLAYER, list);
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), EntityType.PLAYER);
                    entitytracker.sendMetadataBuffer(i);
                });
            }
        });
    }
}

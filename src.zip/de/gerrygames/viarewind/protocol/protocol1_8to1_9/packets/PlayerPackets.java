package de.gerrygames.viarewind.protocol.protocol1_8to1_9.packets;

import com.viaversion.viaversion.api.minecraft.Position;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.minecraft.metadata.types.MetaType1_8;
import com.viaversion.viaversion.api.protocol.Protocol;
import com.viaversion.viaversion.api.protocol.packet.ClientboundPacketType;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.types.version.Types1_8;
import com.viaversion.viaversion.libs.gson.JsonElement;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.CompoundTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.ListTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.StringTag;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_8.ServerboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_9_3to1_9_1_2.storage.ClientWorld;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ClientboundPackets1_9;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.ServerboundPackets1_9;
import de.gerrygames.viarewind.ViaRewind;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.items.ItemRewriter;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.BlockPlaceDestroyTracker;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.BossBarStorage;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.Cooldown;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.EntityTracker;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.PlayerPosition;
import de.gerrygames.viarewind.utils.ChatUtil;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.TimerTask;
import java.util.UUID;

public class PlayerPackets
{
    public static void register(Protocol<ClientboundPackets1_9, ClientboundPackets1_8, ServerboundPackets1_9, ServerboundPackets1_8> protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_9.BOSSBAR, (ClientboundPacketType)null, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    packetWrapper.cancel();
                    UUID uuid = (UUID)packetWrapper.read(Type.UUID);
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    BossBarStorage bossbarstorage = (BossBarStorage)packetWrapper.user().get(BossBarStorage.class);

                    if (i == 0)
                    {
                        bossbarstorage.add(uuid, ChatUtil.jsonToLegacy((JsonElement)packetWrapper.read(Type.COMPONENT)), ((Float)packetWrapper.read(Type.FLOAT)).floatValue());
                        packetWrapper.read(Type.VAR_INT);
                        packetWrapper.read(Type.VAR_INT);
                        packetWrapper.read(Type.UNSIGNED_BYTE);
                    }
                    else if (i == 1)
                    {
                        bossbarstorage.remove(uuid);
                    }
                    else if (i == 2)
                    {
                        bossbarstorage.updateHealth(uuid, ((Float)packetWrapper.read(Type.FLOAT)).floatValue());
                    }
                    else if (i == 3)
                    {
                        String s = ChatUtil.jsonToLegacy((JsonElement)packetWrapper.read(Type.COMPONENT));
                        bossbarstorage.updateTitle(uuid, s);
                    }
                });
            }
        });
        protocol.cancelClientbound(ClientboundPackets1_9.COOLDOWN);
        protocol.registerClientbound(ClientboundPackets1_9.PLUGIN_MESSAGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);

                    if (s.equalsIgnoreCase("MC|TrList"))
                    {
                        packetWrapper.passthrough(Type.INT);
                        int i;

                        if (packetWrapper.isReadable(Type.BYTE, 0))
                        {
                            i = ((Byte)packetWrapper.passthrough(Type.BYTE)).byteValue();
                        }
                        else
                        {
                            i = ((Short)packetWrapper.passthrough(Type.UNSIGNED_BYTE)).shortValue();
                        }

                        for (int j = 0; j < i; ++j)
                        {
                            packetWrapper.write(Type.ITEM, ItemRewriter.toClient((Item)packetWrapper.read(Type.ITEM)));
                            packetWrapper.write(Type.ITEM, ItemRewriter.toClient((Item)packetWrapper.read(Type.ITEM)));
                            boolean flag = ((Boolean)packetWrapper.passthrough(Type.BOOLEAN)).booleanValue();

                            if (flag)
                            {
                                packetWrapper.write(Type.ITEM, ItemRewriter.toClient((Item)packetWrapper.read(Type.ITEM)));
                            }

                            packetWrapper.passthrough(Type.BOOLEAN);
                            packetWrapper.passthrough(Type.INT);
                            packetWrapper.passthrough(Type.INT);
                        }
                    }
                    else if (s.equalsIgnoreCase("MC|BOpen"))
                    {
                        packetWrapper.read(Type.VAR_INT);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.GAME_EVENT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.FLOAT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();

                    if (i == 3)
                    {
                        ((EntityTracker)packetWrapper.user().get(EntityTracker.class)).setPlayerGamemode(((Float)packetWrapper.get(Type.FLOAT, 0)).intValue());
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.JOIN_GAME, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.BYTE);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.STRING);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.setPlayerId(((Integer)packetWrapper.get(Type.INT, 0)).intValue());
                    entitytracker.setPlayerGamemode(((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue());
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(entitytracker.getPlayerId()), EntityType.ENTITY_HUMAN);
                });
                this.handler((packetWrapper) ->
                {
                    ClientWorld clientworld = (ClientWorld)packetWrapper.user().get(ClientWorld.class);
                    clientworld.setEnvironment(((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue());
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.PLAYER_POSITION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.BYTE);
                this.handler((packetWrapper) ->
                {
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    playerposition.setConfirmId(i);
                    byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                    double d0 = ((Double)packetWrapper.get(Type.DOUBLE, 0)).doubleValue();
                    double d1 = ((Double)packetWrapper.get(Type.DOUBLE, 1)).doubleValue();
                    double d2 = ((Double)packetWrapper.get(Type.DOUBLE, 2)).doubleValue();
                    float f = ((Float)packetWrapper.get(Type.FLOAT, 0)).floatValue();
                    float f1 = ((Float)packetWrapper.get(Type.FLOAT, 1)).floatValue();
                    packetWrapper.set(Type.BYTE, 0, Byte.valueOf((byte)0));

                    if (b0 != 0)
                    {
                        if ((b0 & 1) != 0)
                        {
                            d0 += playerposition.getPosX();
                            packetWrapper.set(Type.DOUBLE, 0, Double.valueOf(d0));
                        }

                        if ((b0 & 2) != 0)
                        {
                            d1 += playerposition.getPosY();
                            packetWrapper.set(Type.DOUBLE, 1, Double.valueOf(d1));
                        }

                        if ((b0 & 4) != 0)
                        {
                            d2 += playerposition.getPosZ();
                            packetWrapper.set(Type.DOUBLE, 2, Double.valueOf(d2));
                        }

                        if ((b0 & 8) != 0)
                        {
                            f += playerposition.getYaw();
                            packetWrapper.set(Type.FLOAT, 0, Float.valueOf(f));
                        }

                        if ((b0 & 16) != 0)
                        {
                            f1 += playerposition.getPitch();
                            packetWrapper.set(Type.FLOAT, 1, Float.valueOf(f1));
                        }
                    }

                    playerposition.setPos(d0, d1, d2);
                    playerposition.setYaw(f);
                    playerposition.setPitch(f1);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_9.RESPAWN, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    ((EntityTracker)packetWrapper.user().get(EntityTracker.class)).setPlayerGamemode(((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 1)).shortValue());
                });
                this.handler((packetWrapper) ->
                {
                    ((BossBarStorage)packetWrapper.user().get(BossBarStorage.class)).updateLocation();
                    ((BossBarStorage)packetWrapper.user().get(BossBarStorage.class)).changeWorld();
                });
                this.handler((packetWrapper) ->
                {
                    ClientWorld clientworld = (ClientWorld)packetWrapper.user().get(ClientWorld.class);
                    clientworld.setEnvironment(((Integer)packetWrapper.get(Type.INT, 0)).intValue());
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.CHAT_MESSAGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);

                    if (s.toLowerCase().startsWith("/offhand"))
                    {
                        packetWrapper.cancel();
                        PacketWrapper packetwrapper = PacketWrapper.create(19, (ByteBuf)null, packetWrapper.user());
                        packetwrapper.write(Type.VAR_INT, Integer.valueOf(6));
                        packetwrapper.write(Type.POSITION, new Position(0, (short)0, 0));
                        packetwrapper.write(Type.BYTE, Byte.valueOf((byte) - 1));
                        PacketUtil.sendToServer(packetwrapper, Protocol1_8TO1_9.class, true, true);
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.INTERACT_ENTITY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 1)).intValue();

                    if (i == 2)
                    {
                        packetWrapper.passthrough(Type.FLOAT);
                        packetWrapper.passthrough(Type.FLOAT);
                        packetWrapper.passthrough(Type.FLOAT);
                    }

                    if (i == 2 || i == 0)
                    {
                        packetWrapper.write(Type.VAR_INT, Integer.valueOf(0));
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.PLAYER_MOVEMENT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    int i = entitytracker.getPlayerId();

                    if (entitytracker.isInsideVehicle(i))
                    {
                        packetWrapper.cancel();
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.PLAYER_POSITION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);

                    if (playerposition.getConfirmId() == -1)
                    {
                        playerposition.setPos(((Double)packetWrapper.get(Type.DOUBLE, 0)).doubleValue(), ((Double)packetWrapper.get(Type.DOUBLE, 1)).doubleValue(), ((Double)packetWrapper.get(Type.DOUBLE, 2)).doubleValue());
                        playerposition.setOnGround(((Boolean)packetWrapper.get(Type.BOOLEAN, 0)).booleanValue());
                    }
                });
                this.handler((packetWrapper) ->
                {
                    ((BossBarStorage)packetWrapper.user().get(BossBarStorage.class)).updateLocation();
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.PLAYER_ROTATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);

                    if (playerposition.getConfirmId() == -1)
                    {
                        playerposition.setYaw(((Float)packetWrapper.get(Type.FLOAT, 0)).floatValue());
                        playerposition.setPitch(((Float)packetWrapper.get(Type.FLOAT, 1)).floatValue());
                        playerposition.setOnGround(((Boolean)packetWrapper.get(Type.BOOLEAN, 0)).booleanValue());
                    }
                });
                this.handler((packetWrapper) ->
                {
                    ((BossBarStorage)packetWrapper.user().get(BossBarStorage.class)).updateLocation();
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.PLAYER_POSITION_AND_ROTATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    double d0 = ((Double)packetWrapper.get(Type.DOUBLE, 0)).doubleValue();
                    double d1 = ((Double)packetWrapper.get(Type.DOUBLE, 1)).doubleValue();
                    double d2 = ((Double)packetWrapper.get(Type.DOUBLE, 2)).doubleValue();
                    float f = ((Float)packetWrapper.get(Type.FLOAT, 0)).floatValue();
                    float f1 = ((Float)packetWrapper.get(Type.FLOAT, 1)).floatValue();
                    boolean flag = ((Boolean)packetWrapper.get(Type.BOOLEAN, 0)).booleanValue();
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);

                    if (playerposition.getConfirmId() != -1)
                    {
                        if (playerposition.getPosX() == d0 && playerposition.getPosY() == d1 && playerposition.getPosZ() == d2 && playerposition.getYaw() == f && playerposition.getPitch() == f1)
                        {
                            PacketWrapper packetwrapper = packetWrapper.create(0);
                            packetwrapper.write(Type.VAR_INT, Integer.valueOf(playerposition.getConfirmId()));
                            PacketUtil.sendToServer(packetwrapper, Protocol1_8TO1_9.class, true, true);
                            playerposition.setConfirmId(-1);
                        }
                    }
                    else {
                        playerposition.setPos(d0, d1, d2);
                        playerposition.setYaw(f);
                        playerposition.setPitch(f1);
                        playerposition.setOnGround(flag);
                        ((BossBarStorage)packetWrapper.user().get(BossBarStorage.class)).updateLocation();
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.PLAYER_DIGGING, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.POSITION);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();

                    if (i == 0)
                    {
                        ((BlockPlaceDestroyTracker)packetWrapper.user().get(BlockPlaceDestroyTracker.class)).setMining(true);
                    }
                    else if (i == 2)
                    {
                        BlockPlaceDestroyTracker blockplacedestroytracker = (BlockPlaceDestroyTracker)packetWrapper.user().get(BlockPlaceDestroyTracker.class);
                        blockplacedestroytracker.setMining(false);
                        blockplacedestroytracker.setLastMining(System.currentTimeMillis() + 100L);
                        ((Cooldown)packetWrapper.user().get(Cooldown.class)).setLastHit(0L);
                    }
                    else if (i == 1)
                    {
                        BlockPlaceDestroyTracker blockplacedestroytracker1 = (BlockPlaceDestroyTracker)packetWrapper.user().get(BlockPlaceDestroyTracker.class);
                        blockplacedestroytracker1.setMining(false);
                        blockplacedestroytracker1.setLastMining(0L);
                        ((Cooldown)packetWrapper.user().get(Cooldown.class)).hit();
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.PLAYER_BLOCK_PLACEMENT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.POSITION);
                this.map(Type.BYTE, Type.VAR_INT);
                this.map(Type.ITEM, Type.NOTHING);
                this.create(Type.VAR_INT, Integer.valueOf(0));
                this.map(Type.BYTE, Type.UNSIGNED_BYTE);
                this.map(Type.BYTE, Type.UNSIGNED_BYTE);
                this.map(Type.BYTE, Type.UNSIGNED_BYTE);
                this.handler((packetWrapper) ->
                {
                    if (((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue() == -1)
                    {
                        packetWrapper.cancel();
                        PacketWrapper packetwrapper = PacketWrapper.create(29, (ByteBuf)null, packetWrapper.user());
                        packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
                        PacketUtil.sendToServer(packetwrapper, Protocol1_8TO1_9.class, true, true);
                    }
                });
                this.handler((packetWrapper) ->
                {
                    if (((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue() != -1)
                    {
                        ((BlockPlaceDestroyTracker)packetWrapper.user().get(BlockPlaceDestroyTracker.class)).place();
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.HELD_ITEM_CHANGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    ((Cooldown)packetWrapper.user().get(Cooldown.class)).hit();
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.ANIMATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    packetWrapper.cancel();
                    final PacketWrapper packetwrapper = PacketWrapper.create(26, (ByteBuf)null, packetWrapper.user());
                    packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
                    Protocol1_8TO1_9.TIMER.schedule(new TimerTask()
                    {
                        public void run()
                        {
                            PacketUtil.sendToServer(packetwrapper, Protocol1_8TO1_9.class);
                        }
                    }, 5L);
                });
                this.handler((packetWrapper) ->
                {
                    ((BlockPlaceDestroyTracker)packetWrapper.user().get(BlockPlaceDestroyTracker.class)).updateMining();
                    ((Cooldown)packetWrapper.user().get(Cooldown.class)).hit();
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.ENTITY_ACTION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.VAR_INT);
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 1)).intValue();

                    if (i == 6)
                    {
                        packetWrapper.set(Type.VAR_INT, 1, Integer.valueOf(7));
                    }
                    else if (i == 0)
                    {
                        PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);

                        if (!playerposition.isOnGround())
                        {
                            PacketWrapper packetwrapper = PacketWrapper.create(20, (ByteBuf)null, packetWrapper.user());
                            packetwrapper.write(Type.VAR_INT, (Integer)packetWrapper.get(Type.VAR_INT, 0));
                            packetwrapper.write(Type.VAR_INT, Integer.valueOf(8));
                            packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
                            PacketUtil.sendToServer(packetwrapper, Protocol1_8TO1_9.class, true, false);
                        }
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.STEER_VEHICLE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.UNSIGNED_BYTE);
                this.handler((packetWrapper) ->
                {
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    int i = entitytracker.getPlayerId();
                    int j = entitytracker.getVehicle(i);

                    if (j != -1 && entitytracker.getClientEntityTypes().get(Integer.valueOf(j)) == EntityType.BOAT)
                    {
                        PacketWrapper packetwrapper = PacketWrapper.create(17, (ByteBuf)null, packetWrapper.user());
                        float f = ((Float)packetWrapper.get(Type.FLOAT, 0)).floatValue();
                        float f1 = ((Float)packetWrapper.get(Type.FLOAT, 1)).floatValue();
                        packetwrapper.write(Type.BOOLEAN, Boolean.valueOf(f1 != 0.0F || f < 0.0F));
                        packetwrapper.write(Type.BOOLEAN, Boolean.valueOf(f1 != 0.0F || f > 0.0F));
                        PacketUtil.sendToServer(packetwrapper, Protocol1_8TO1_9.class);
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.UPDATE_SIGN, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.POSITION);
                this.handler((packetWrapper) ->
                {
                    for (int i = 0; i < 4; ++i)
                    {
                        packetWrapper.write(Type.STRING, ChatUtil.jsonToLegacy((JsonElement)packetWrapper.read(Type.COMPONENT)));
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.TAB_COMPLETE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    packetWrapper.write(Type.BOOLEAN, Boolean.valueOf(false));
                });
                this.map(Type.OPTIONAL_POSITION);
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.CLIENT_SETTINGS, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.map(Type.BYTE);
                this.map(Type.BYTE, Type.VAR_INT);
                this.map(Type.BOOLEAN);
                this.map(Type.UNSIGNED_BYTE);
                this.create(Type.VAR_INT, Integer.valueOf(1));
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    PacketWrapper packetwrapper = PacketWrapper.create(28, (ByteBuf)null, packetWrapper.user());
                    packetwrapper.write(Type.VAR_INT, Integer.valueOf(((EntityTracker)packetWrapper.user().get(EntityTracker.class)).getPlayerId()));
                    ArrayList<Metadata> arraylist = new ArrayList<Metadata>();
                    arraylist.add(new Metadata(10, MetaType1_8.Byte, (byte)short1));
                    packetwrapper.write(Types1_8.METADATA_LIST, arraylist);
                    PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_8.PLUGIN_MESSAGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);

                    if (!s.equalsIgnoreCase("MC|BEdit") && !s.equalsIgnoreCase("MC|BSign"))
                    {
                        if (s.equalsIgnoreCase("MC|AdvCdm"))
                        {
                            s = "MC|AdvCmd";
                            packetWrapper.set(Type.STRING, 0, "MC|AdvCmd");
                        }
                    }
                    else {
                        Item item = (Item)packetWrapper.passthrough(Type.ITEM);
                        item.setIdentifier(386);
                        CompoundTag compoundtag = item.tag();

                        if (compoundtag.contains("pages"))
                        {
                            ListTag listtag = (ListTag)compoundtag.get("pages");

                            if (listtag.size() > ViaRewind.getConfig().getMaxBookPages())
                            {
                                packetWrapper.user().disconnect("Too many book pages");
                                return;
                            }

                            for (int i = 0; i < listtag.size(); ++i)
                            {
                                StringTag stringtag = (StringTag)listtag.get(i);
                                String s1 = stringtag.getValue();

                                if (s1.length() > ViaRewind.getConfig().getMaxBookPageSize())
                                {
                                    packetWrapper.user().disconnect("Book page too large");
                                    return;
                                }

                                s1 = ChatUtil.jsonToLegacy(s1);
                                stringtag.setValue(s1);
                            }
                        }
                    }
                });
            }
        });
    }
}

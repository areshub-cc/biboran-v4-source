package de.gerrygames.viarewind.protocol.protocol1_8to1_9.util;

import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.minecraft.Vector;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage.EntityTracker;

public class RelativeMoveUtil
{
    public static Vector[] calculateRelativeMoves(UserConnection user, int entityId, int relX, int relY, int relZ)
    {
        EntityTracker entitytracker = (EntityTracker)user.get(EntityTracker.class);
        Vector vector = entitytracker.getEntityOffset(entityId);
        relX = relX + vector.getBlockX();
        relY = relY + vector.getBlockY();
        relZ = relZ + vector.getBlockZ();

        if (relX > 32767)
        {
            vector.setBlockX(relX - 32767);
            relX = 32767;
        }
        else if (relX < -32768)
        {
            vector.setBlockX(relX - -32768);
            relX = -32768;
        }
        else
        {
            vector.setBlockX(0);
        }

        if (relY > 32767)
        {
            vector.setBlockY(relY - 32767);
            relY = 32767;
        }
        else if (relY < -32768)
        {
            vector.setBlockY(relY - -32768);
            relY = -32768;
        }
        else
        {
            vector.setBlockY(0);
        }

        if (relZ > 32767)
        {
            vector.setBlockZ(relZ - 32767);
            relZ = 32767;
        }
        else if (relZ < -32768)
        {
            vector.setBlockZ(relZ - -32768);
            relZ = -32768;
        }
        else
        {
            vector.setBlockZ(0);
        }

        int i;
        int j;
        int k;
        Vector[] avector;

        if (relX <= 16256 && relX >= -16384 && relY <= 16256 && relY >= -16384 && relZ <= 16256 && relZ >= -16384)
        {
            i = Math.round((float)relX / 128.0F);
            j = Math.round((float)relY / 128.0F);
            k = Math.round((float)relZ / 128.0F);
            avector = new Vector[] {new Vector(i, j, k)};
        }
        else
        {
            byte b0 = (byte)(relX / 256);
            byte b1 = (byte)Math.round((float)(relX - b0 * 128) / 128.0F);
            byte b2 = (byte)(relY / 256);
            byte b3 = (byte)Math.round((float)(relY - b2 * 128) / 128.0F);
            byte b4 = (byte)(relZ / 256);
            byte b5 = (byte)Math.round((float)(relZ - b4 * 128) / 128.0F);
            i = b0 + b1;
            j = b2 + b3;
            k = b4 + b5;
            avector = new Vector[] {new Vector(b0, b2, b4), new Vector(b1, b3, b5)};
        }

        vector.setBlockX(vector.getBlockX() + relX - i * 128);
        vector.setBlockY(vector.getBlockY() + relY - j * 128);
        vector.setBlockZ(vector.getBlockZ() + relZ - k * 128);
        entitytracker.setEntityOffset(entityId, vector);
        return avector;
    }
}

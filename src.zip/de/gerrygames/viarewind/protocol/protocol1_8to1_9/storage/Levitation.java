package de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.utils.PacketUtil;
import de.gerrygames.viarewind.utils.Tickable;
import io.netty.buffer.ByteBuf;

public class Levitation extends StoredObject implements Tickable
{
    private int amplifier;
    private volatile boolean active = false;

    public Levitation(UserConnection user)
    {
        super(user);
    }

    public void tick()
    {
        if (this.active)
        {
            int i = (this.amplifier + 1) * 360;
            PacketWrapper packetwrapper = PacketWrapper.create(18, (ByteBuf)null, this.getUser());
            packetwrapper.write(Type.VAR_INT, Integer.valueOf(((EntityTracker)this.getUser().get(EntityTracker.class)).getPlayerId()));
            packetwrapper.write(Type.SHORT, Short.valueOf((short)0));
            packetwrapper.write(Type.SHORT, Short.valueOf((short)i));
            packetwrapper.write(Type.SHORT, Short.valueOf((short)0));
            PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
        }
    }

    public void setActive(boolean active)
    {
        this.active = active;
    }

    public void setAmplifier(int amplifier)
    {
        this.amplifier = amplifier;
    }
}

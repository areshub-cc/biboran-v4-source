package de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;

public class BlockPlaceDestroyTracker extends StoredObject
{
    private long blockPlaced;
    private long lastMining;
    private boolean mining;

    public BlockPlaceDestroyTracker(UserConnection user)
    {
        super(user);
    }

    public long getBlockPlaced()
    {
        return this.blockPlaced;
    }

    public void place()
    {
        this.blockPlaced = System.currentTimeMillis();
    }

    public boolean isMining()
    {
        long i = System.currentTimeMillis() - this.lastMining;
        return this.mining && i < 75L || i < 75L;
    }

    public void setMining(boolean mining)
    {
        this.mining = mining && ((EntityTracker)this.getUser().get(EntityTracker.class)).getPlayerGamemode() != 1;
        this.lastMining = System.currentTimeMillis();
    }

    public long getLastMining()
    {
        return this.lastMining;
    }

    public void updateMining()
    {
        if (this.isMining())
        {
            this.lastMining = System.currentTimeMillis();
        }
    }

    public void setLastMining(long lastMining)
    {
        this.lastMining = lastMining;
    }
}

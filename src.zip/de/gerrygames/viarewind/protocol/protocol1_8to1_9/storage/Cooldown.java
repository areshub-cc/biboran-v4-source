package de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.util.Pair;
import de.gerrygames.viarewind.ViaRewind;
import de.gerrygames.viarewind.api.ViaRewindConfig;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.utils.PacketUtil;
import de.gerrygames.viarewind.utils.Tickable;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.UUID;

public class Cooldown extends StoredObject implements Tickable
{
    private double attackSpeed = 4.0D;
    private long lastHit = 0L;
    private final ViaRewindConfig.CooldownIndicator cooldownIndicator;
    private UUID bossUUID;
    private boolean lastSend;
    private static final int max = 10;

    public Cooldown(UserConnection user)
    {
        super(user);
        ViaRewindConfig.CooldownIndicator viarewindconfig$cooldownindicator;

        try
        {
            viarewindconfig$cooldownindicator = ViaRewind.getConfig().getCooldownIndicator();
        }
        catch (IllegalArgumentException var4)
        {
            ViaRewind.getPlatform().getLogger().warning("Invalid cooldown-indicator setting");
            viarewindconfig$cooldownindicator = ViaRewindConfig.CooldownIndicator.DISABLED;
        }

        this.cooldownIndicator = viarewindconfig$cooldownindicator;
    }

    public void tick()
    {
        if (!this.hasCooldown())
        {
            if (this.lastSend)
            {
                this.hide();
                this.lastSend = false;
            }
        }
        else
        {
            BlockPlaceDestroyTracker blockplacedestroytracker = (BlockPlaceDestroyTracker)this.getUser().get(BlockPlaceDestroyTracker.class);

            if (blockplacedestroytracker.isMining())
            {
                this.lastHit = 0L;

                if (this.lastSend)
                {
                    this.hide();
                    this.lastSend = false;
                }
            }
            else
            {
                this.showCooldown();
                this.lastSend = true;
            }
        }
    }

    private void showCooldown()
    {
        if (this.cooldownIndicator == ViaRewindConfig.CooldownIndicator.TITLE)
        {
            this.sendTitle("", this.getTitle(), 0, 2, 5);
        }
        else if (this.cooldownIndicator == ViaRewindConfig.CooldownIndicator.ACTION_BAR)
        {
            this.sendActionBar(this.getTitle());
        }
        else if (this.cooldownIndicator == ViaRewindConfig.CooldownIndicator.BOSS_BAR)
        {
            this.sendBossBar((float)this.getCooldown());
        }
    }

    private void hide()
    {
        if (this.cooldownIndicator == ViaRewindConfig.CooldownIndicator.ACTION_BAR)
        {
            this.sendActionBar("\u00a7r");
        }
        else if (this.cooldownIndicator == ViaRewindConfig.CooldownIndicator.TITLE)
        {
            this.hideTitle();
        }
        else if (this.cooldownIndicator == ViaRewindConfig.CooldownIndicator.BOSS_BAR)
        {
            this.hideBossBar();
        }
    }

    private void hideBossBar()
    {
        if (this.bossUUID != null)
        {
            PacketWrapper packetwrapper = PacketWrapper.create(12, (ByteBuf)null, this.getUser());
            packetwrapper.write(Type.UUID, this.bossUUID);
            packetwrapper.write(Type.VAR_INT, Integer.valueOf(1));
            PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class, false, true);
            this.bossUUID = null;
        }
    }

    private void sendBossBar(float cooldown)
    {
        PacketWrapper packetwrapper = PacketWrapper.create(12, (ByteBuf)null, this.getUser());

        if (this.bossUUID == null)
        {
            this.bossUUID = UUID.randomUUID();
            packetwrapper.write(Type.UUID, this.bossUUID);
            packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
            packetwrapper.write(Type.STRING, "{\"text\":\"  \"}");
            packetwrapper.write(Type.FLOAT, Float.valueOf(cooldown));
            packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
            packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
            packetwrapper.write(Type.UNSIGNED_BYTE, Short.valueOf((short)0));
        }
        else
        {
            packetwrapper.write(Type.UUID, this.bossUUID);
            packetwrapper.write(Type.VAR_INT, Integer.valueOf(2));
            packetwrapper.write(Type.FLOAT, Float.valueOf(cooldown));
        }

        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class, false, true);
    }

    private void hideTitle()
    {
        PacketWrapper packetwrapper = PacketWrapper.create(69, (ByteBuf)null, this.getUser());
        packetwrapper.write(Type.VAR_INT, Integer.valueOf(3));
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
    }

    private void sendTitle(String title, String subTitle, int fadeIn, int stay, int fadeOut)
    {
        PacketWrapper packetwrapper = PacketWrapper.create(69, (ByteBuf)null, this.getUser());
        packetwrapper.write(Type.VAR_INT, Integer.valueOf(2));
        packetwrapper.write(Type.INT, Integer.valueOf(fadeIn));
        packetwrapper.write(Type.INT, Integer.valueOf(stay));
        packetwrapper.write(Type.INT, Integer.valueOf(fadeOut));
        PacketWrapper packetwrapper1 = PacketWrapper.create(69, (ByteBuf)null, this.getUser());
        packetwrapper1.write(Type.VAR_INT, Integer.valueOf(0));
        packetwrapper1.write(Type.STRING, title);
        PacketWrapper packetwrapper2 = PacketWrapper.create(69, (ByteBuf)null, this.getUser());
        packetwrapper2.write(Type.VAR_INT, Integer.valueOf(1));
        packetwrapper2.write(Type.STRING, subTitle);
        PacketUtil.sendPacket(packetwrapper1, Protocol1_8TO1_9.class);
        PacketUtil.sendPacket(packetwrapper2, Protocol1_8TO1_9.class);
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
    }

    private void sendActionBar(String bar)
    {
        PacketWrapper packetwrapper = PacketWrapper.create(2, (ByteBuf)null, this.getUser());
        packetwrapper.write(Type.STRING, bar);
        packetwrapper.write(Type.BYTE, Byte.valueOf((byte)2));
        PacketUtil.sendPacket(packetwrapper, Protocol1_8TO1_9.class);
    }

    public boolean hasCooldown()
    {
        long i = System.currentTimeMillis() - this.lastHit;
        double d0 = this.restrain((double)i * this.attackSpeed / 1000.0D, 0.0D, 1.5D);
        return d0 > 0.1D && d0 < 1.1D;
    }

    public double getCooldown()
    {
        long i = System.currentTimeMillis() - this.lastHit;
        return this.restrain((double)i * this.attackSpeed / 1000.0D, 0.0D, 1.0D);
    }

    private double restrain(double x, double a, double b)
    {
        if (x < a)
        {
            return a;
        }
        else
        {
            return x > b ? b : x;
        }
    }

    private String getTitle()
    {
        String s = this.cooldownIndicator == ViaRewindConfig.CooldownIndicator.ACTION_BAR ? "\u25a0" : "\u02d9";
        double d0 = this.getCooldown();
        int i = (int)Math.floor(10.0D * d0);
        int j = 10 - i;
        StringBuilder stringbuilder = new StringBuilder("\u00a78");

        while (i-- > 0)
        {
            stringbuilder.append(s);
        }

        stringbuilder.append("\u00a77");

        while (j-- > 0)
        {
            stringbuilder.append(s);
        }

        return stringbuilder.toString();
    }

    public double getAttackSpeed()
    {
        return this.attackSpeed;
    }

    public void setAttackSpeed(double attackSpeed)
    {
        this.attackSpeed = attackSpeed;
    }

    public void setAttackSpeed(double base, ArrayList<Pair<Byte, Double>> modifiers)
    {
        this.attackSpeed = base;

        for (int i = 0; i < modifiers.size(); ++i)
        {
            if (((Byte)((Pair)modifiers.get(i)).getKey()).byteValue() == 0)
            {
                this.attackSpeed += ((Double)((Pair)modifiers.get(i)).getValue()).doubleValue();
                modifiers.remove(i--);
            }
        }

        for (int j = 0; j < modifiers.size(); ++j)
        {
            if (((Byte)((Pair)modifiers.get(j)).getKey()).byteValue() == 1)
            {
                this.attackSpeed += base * ((Double)((Pair)modifiers.get(j)).getValue()).doubleValue();
                modifiers.remove(j--);
            }
        }

        for (int k = 0; k < modifiers.size(); ++k)
        {
            if (((Byte)((Pair)modifiers.get(k)).getKey()).byteValue() == 2)
            {
                this.attackSpeed *= 1.0D + ((Double)((Pair)modifiers.get(k)).getValue()).doubleValue();
                modifiers.remove(k--);
            }
        }
    }

    public void hit()
    {
        this.lastHit = System.currentTimeMillis();
    }

    public void setLastHit(long lastHit)
    {
        this.lastHit = lastHit;
    }
}

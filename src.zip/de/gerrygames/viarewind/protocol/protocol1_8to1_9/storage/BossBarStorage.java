package de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.bossbar.WitherBossBar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

public class BossBarStorage extends StoredObject
{
    private Map<UUID, WitherBossBar> bossBars = new HashMap<UUID, WitherBossBar>();

    public BossBarStorage(UserConnection user)
    {
        super(user);
    }

    public void add(UUID uuid, String title, float health)
    {
        WitherBossBar witherbossbar = new WitherBossBar(this.getUser(), uuid, title, health);
        PlayerPosition playerposition = (PlayerPosition)this.getUser().get(PlayerPosition.class);
        witherbossbar.setPlayerLocation(playerposition.getPosX(), playerposition.getPosY(), playerposition.getPosZ(), playerposition.getYaw(), playerposition.getPitch());
        witherbossbar.show();
        this.bossBars.put(uuid, witherbossbar);
    }

    public void remove(UUID uuid)
    {
        WitherBossBar witherbossbar = this.bossBars.remove(uuid);

        if (witherbossbar != null)
        {
            witherbossbar.hide();
        }
    }

    public void updateLocation()
    {
        PlayerPosition playerposition = (PlayerPosition)this.getUser().get(PlayerPosition.class);
        this.bossBars.values().forEach((bossBar) ->
        {
            bossBar.setPlayerLocation(playerPosition.getPosX(), playerPosition.getPosY(), playerPosition.getPosZ(), playerPosition.getYaw(), playerPosition.getPitch());
        });
    }

    public void changeWorld()
    {
        this.bossBars.values().forEach((bossBar) ->
        {
            bossBar.hide();
            bossBar.show();
        });
    }

    public void updateHealth(UUID uuid, float health)
    {
        WitherBossBar witherbossbar = this.bossBars.get(uuid);

        if (witherbossbar != null)
        {
            witherbossbar.setHealth(health);
        }
    }

    public void updateTitle(UUID uuid, String title)
    {
        WitherBossBar witherbossbar = this.bossBars.get(uuid);

        if (witherbossbar != null)
        {
            witherbossbar.setTitle(title);
        }
    }
}

package de.gerrygames.viarewind.protocol.protocol1_8to1_9.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;

public class PlayerPosition extends StoredObject
{
    private double posX;
    private double posY;
    private double posZ;
    private float yaw;
    private float pitch;
    private boolean onGround;
    private int confirmId = -1;

    public PlayerPosition(UserConnection user)
    {
        super(user);
    }

    public void setPos(double x, double y, double z)
    {
        this.posX = x;
        this.posY = y;
        this.posZ = z;
    }

    public void setYaw(float yaw)
    {
        this.yaw = yaw % 360.0F;
    }

    public void setPitch(float pitch)
    {
        this.pitch = pitch % 360.0F;
    }

    public double getPosX()
    {
        return this.posX;
    }

    public double getPosY()
    {
        return this.posY;
    }

    public double getPosZ()
    {
        return this.posZ;
    }

    public float getYaw()
    {
        return this.yaw;
    }

    public float getPitch()
    {
        return this.pitch;
    }

    public boolean isOnGround()
    {
        return this.onGround;
    }

    public int getConfirmId()
    {
        return this.confirmId;
    }

    public void setPosX(double posX)
    {
        this.posX = posX;
    }

    public void setPosY(double posY)
    {
        this.posY = posY;
    }

    public void setPosZ(double posZ)
    {
        this.posZ = posZ;
    }

    public void setOnGround(boolean onGround)
    {
        this.onGround = onGround;
    }

    public void setConfirmId(int confirmId)
    {
        this.confirmId = confirmId;
    }

    public boolean equals(Object o)
    {
        if (o == this)
        {
            return true;
        }
        else if (!(o instanceof PlayerPosition))
        {
            return false;
        }
        else
        {
            PlayerPosition playerposition = (PlayerPosition)o;

            if (!playerposition.canEqual(this))
            {
                return false;
            }
            else if (Double.compare(this.getPosX(), playerposition.getPosX()) != 0)
            {
                return false;
            }
            else if (Double.compare(this.getPosY(), playerposition.getPosY()) != 0)
            {
                return false;
            }
            else if (Double.compare(this.getPosZ(), playerposition.getPosZ()) != 0)
            {
                return false;
            }
            else if (Float.compare(this.getYaw(), playerposition.getYaw()) != 0)
            {
                return false;
            }
            else if (Float.compare(this.getPitch(), playerposition.getPitch()) != 0)
            {
                return false;
            }
            else if (this.isOnGround() != playerposition.isOnGround())
            {
                return false;
            }
            else
            {
                return this.getConfirmId() == playerposition.getConfirmId();
            }
        }
    }

    protected boolean canEqual(Object other)
    {
        return other instanceof PlayerPosition;
    }

    public int hashCode()
    {
        int i = 59;
        int j = 1;
        long k = Double.doubleToLongBits(this.getPosX());
        j = j * 59 + (int)(k >>> 32 ^ k);
        long l = Double.doubleToLongBits(this.getPosY());
        j = j * 59 + (int)(l >>> 32 ^ l);
        long i1 = Double.doubleToLongBits(this.getPosZ());
        j = j * 59 + (int)(i1 >>> 32 ^ i1);
        j = j * 59 + Float.floatToIntBits(this.getYaw());
        j = j * 59 + Float.floatToIntBits(this.getPitch());
        j = j * 59 + (this.isOnGround() ? 79 : 97);
        j = j * 59 + this.getConfirmId();
        return j;
    }

    public String toString()
    {
        return "PlayerPosition(posX=" + this.getPosX() + ", posY=" + this.getPosY() + ", posZ=" + this.getPosZ() + ", yaw=" + this.getYaw() + ", pitch=" + this.getPitch() + ", onGround=" + this.isOnGround() + ", confirmId=" + this.getConfirmId() + ")";
    }
}

package de.gerrygames.viarewind.protocol.protocol1_7_0_5to1_7_6_10;

import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.protocol.AbstractProtocol;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.packet.State;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.protocol.remapper.ValueTransformer;
import com.viaversion.viaversion.api.type.Type;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.ClientboundPackets1_7;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.ServerboundPackets1_7;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.Types1_7_6_10;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Protocol1_7_0_5to1_7_6_10 extends AbstractProtocol<ClientboundPackets1_7, ClientboundPackets1_7, ServerboundPackets1_7, ServerboundPackets1_7>
{
    public static final ValueTransformer<String, String> REMOVE_DASHES = new ValueTransformer<String, String>(Type.STRING)
    {
        public String transform(PacketWrapper packetWrapper, String s)
        {
            return s.replace("-", "");
        }
    };

    public Protocol1_7_0_5to1_7_6_10()
    {
        super(ClientboundPackets1_7.class, ClientboundPackets1_7.class, ServerboundPackets1_7.class, ServerboundPackets1_7.class);
    }

    protected void registerPackets()
    {
        this.registerClientbound(State.LOGIN, 2, 2, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING, Protocol1_7_0_5to1_7_6_10.REMOVE_DASHES);
                this.map(Type.STRING);
            }
        });
        this.registerClientbound(ClientboundPackets1_7.SPAWN_PLAYER, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.STRING, Protocol1_7_0_5to1_7_6_10.REMOVE_DASHES);
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();

                    for (int j = 0; j < i * 3; ++j)
                    {
                        packetWrapper.read(Type.STRING);
                    }
                });
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.SHORT);
                this.map(Types1_7_6_10.METADATA_LIST);
            }
        });
        this.registerClientbound(ClientboundPackets1_7.TEAMS, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.map(Type.BYTE);
                this.handler((packetWrapper) ->
                {
                    byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();

                    if (b0 == 0 || b0 == 2)
                    {
                        packetWrapper.passthrough(Type.STRING);
                        packetWrapper.passthrough(Type.STRING);
                        packetWrapper.passthrough(Type.STRING);
                        packetWrapper.passthrough(Type.BYTE);
                    }

                    if (b0 == 0 || b0 == 3 || b0 == 4)
                    {
                        List<String> list = new ArrayList<String>();
                        int i = ((Short)packetWrapper.read(Type.SHORT)).shortValue();

                        for (int j = 0; j < i; ++j)
                        {
                            list.add((String)packetWrapper.read(Type.STRING));
                        }

                        list = (List)list.stream().<String>map((it) ->
                        {
                            return it.length() > 16 ? it.substring(0, 16) : it;
                        }).distinct().collect(Collectors.toList());
                        packetWrapper.write(Type.SHORT, Short.valueOf((short)list.size()));

                        for (String s : list)
                        {
                            packetWrapper.write(Type.STRING, s);
                        }
                    }
                });
            }
        });
    }

    public void init(UserConnection userConnection)
    {
    }
}

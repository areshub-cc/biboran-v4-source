package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.packets;

import com.viaversion.viaversion.api.minecraft.BlockChangeRecord;
import com.viaversion.viaversion.api.minecraft.Position;
import com.viaversion.viaversion.api.minecraft.chunks.Chunk;
import com.viaversion.viaversion.api.minecraft.chunks.ChunkSection;
import com.viaversion.viaversion.api.protocol.packet.ClientboundPacketType;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.types.CustomByteType;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_9_3to1_9_1_2.storage.ClientWorld;
import com.viaversion.viaversion.protocols.protocol1_9to1_8.types.Chunk1_8Type;
import com.viaversion.viaversion.util.ChatColorUtil;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.chunks.ChunkPacketTransformer;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.items.ReplacementRegistry1_7_6_10to1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.WorldBorder;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.Chunk1_7_10Type;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.Particle;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.Types1_7_6_10;
import de.gerrygames.viarewind.replacement.Replacement;
import de.gerrygames.viarewind.types.VarLongType;
import de.gerrygames.viarewind.utils.ChatUtil;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;

public class WorldPackets
{
    public static void register(Protocol1_7_6_10TO1_8 protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_8.CHUNK_DATA, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    ClientWorld clientworld = (ClientWorld)packetWrapper.user().get(ClientWorld.class);
                    Chunk chunk = (Chunk)packetWrapper.read(new Chunk1_8Type(clientworld));
                    packetWrapper.write(new Chunk1_7_10Type(clientworld), chunk);

                    for (ChunkSection chunksection : chunk.getSections())
                    {
                        if (chunksection != null)
                        {
                            for (int i = 0; i < chunksection.getPaletteSize(); ++i)
                            {
                                int j = chunksection.getPaletteEntry(i);
                                int k = ReplacementRegistry1_7_6_10to1_8.replace(j);
                                chunksection.setPaletteEntry(i, k);
                            }
                        }
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.MULTI_BLOCK_CHANGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.map(Type.INT);
                this.handler((packetWrapper) ->
                {
                    BlockChangeRecord[] ablockchangerecord = (BlockChangeRecord[])packetWrapper.read(Type.BLOCK_CHANGE_RECORD_ARRAY);
                    packetWrapper.write(Type.SHORT, Short.valueOf((short)ablockchangerecord.length));
                    packetWrapper.write(Type.INT, Integer.valueOf(ablockchangerecord.length * 4));

                    for (BlockChangeRecord blockchangerecord : ablockchangerecord)
                    {
                        short short1 = (short)(blockchangerecord.getSectionX() << 12 | blockchangerecord.getSectionZ() << 8 | blockchangerecord.getY());
                        packetWrapper.write(Type.SHORT, Short.valueOf(short1));
                        int i = ReplacementRegistry1_7_6_10to1_8.replace(blockchangerecord.getBlockId());
                        packetWrapper.write(Type.SHORT, Short.valueOf((short)i));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.BLOCK_CHANGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.UNSIGNED_BYTE, Short.valueOf((short)position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    int j = i >> 4;
                    int k = i & 15;
                    Replacement replacement = ReplacementRegistry1_7_6_10to1_8.getReplacement(j, k);

                    if (replacement != null)
                    {
                        j = replacement.getId();
                        k = replacement.replaceData(k);
                    }

                    packetWrapper.write(Type.VAR_INT, Integer.valueOf(j));
                    packetWrapper.write(Type.UNSIGNED_BYTE, Short.valueOf((short)k));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.BLOCK_ACTION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.SHORT, Short.valueOf((short)position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.VAR_INT);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.BLOCK_BREAK_ANIMATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
                this.map(Type.BYTE);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.MAP_BULK_CHUNK, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler(ChunkPacketTransformer::transformChunkBulk);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.EFFECT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.BYTE, Byte.valueOf((byte)position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
                this.map(Type.INT);
                this.map(Type.BOOLEAN);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.SPAWN_PARTICLE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    Particle particle = Particle.find(i);

                    if (particle == null)
                    {
                        particle = Particle.CRIT;
                    }

                    packetWrapper.write(Type.STRING, particle.name);
                    packetWrapper.read(Type.BOOLEAN);
                });
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.INT);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);
                    Particle particle = Particle.find(s);

                    if (particle == Particle.ICON_CRACK || particle == Particle.BLOCK_CRACK || particle == Particle.BLOCK_DUST)
                    {
                        int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                        int j = particle == Particle.ICON_CRACK ? ((Integer)packetWrapper.read(Type.VAR_INT)).intValue() : 0;

                        if ((i < 256 || i > 422) && (i < 2256 || i > 2267))
                        {
                            if ((i < 0 || i > 164) && (i < 170 || i > 175))
                            {
                                packetWrapper.cancel();
                                return;
                            }

                            if (particle == Particle.ICON_CRACK)
                            {
                                particle = Particle.BLOCK_CRACK;
                            }
                        }
                        else
                        {
                            particle = Particle.ICON_CRACK;
                        }

                        s = particle.name + "_" + i + "_" + j;
                    }

                    packetWrapper.set(Type.STRING, 0, s);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.UPDATE_SIGN, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.SHORT, Short.valueOf((short)position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
                this.handler((packetWrapper) ->
                {
                    for (int i = 0; i < 4; ++i)
                    {
                        String s = (String)packetWrapper.read(Type.STRING);
                        s = ChatUtil.jsonToLegacy(s);
                        s = ChatUtil.removeUnusedColor(s, '0');

                        if (s.length() > 15)
                        {
                            s = ChatColorUtil.stripColor(s);

                            if (s.length() > 15)
                            {
                                s = s.substring(0, 15);
                            }
                        }

                        packetWrapper.write(Type.STRING, s);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.MAP_DATA, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    packetWrapper.cancel();
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    byte b0 = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();
                    int j = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    byte[] abyte = new byte[j * 4];

                    for (int k = 0; k < j; ++k)
                    {
                        int l = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();
                        abyte[k * 4] = (byte)(l >> 4 & 15);
                        abyte[k * 4 + 1] = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();
                        abyte[k * 4 + 2] = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();
                        abyte[k * 4 + 3] = (byte)(l & 15);
                    }

                    short short3 = ((Short)packetWrapper.read(Type.UNSIGNED_BYTE)).shortValue();

                    if (short3 > 0)
                    {
                        short short4 = ((Short)packetWrapper.read(Type.UNSIGNED_BYTE)).shortValue();
                        short short1 = ((Short)packetWrapper.read(Type.UNSIGNED_BYTE)).shortValue();
                        short short2 = ((Short)packetWrapper.read(Type.UNSIGNED_BYTE)).shortValue();
                        byte[] abyte1 = (byte[])packetWrapper.read(Type.BYTE_ARRAY_PRIMITIVE);

                        for (int i1 = 0; i1 < short3; ++i1)
                        {
                            byte[] abyte2 = new byte[short4 + 3];
                            abyte2[0] = 0;
                            abyte2[1] = (byte)(short1 + i1);
                            abyte2[2] = (byte)short2;

                            for (int j1 = 0; j1 < short4; ++j1)
                            {
                                abyte2[j1 + 3] = abyte1[i1 + j1 * short3];
                            }

                            PacketWrapper packetwrapper2 = PacketWrapper.create(52, (ByteBuf)null, packetWrapper.user());
                            packetwrapper2.write(Type.VAR_INT, Integer.valueOf(i));
                            packetwrapper2.write(Type.SHORT, Short.valueOf((short)abyte2.length));
                            packetwrapper2.write(new CustomByteType(abyte2.length), abyte2);
                            PacketUtil.sendPacket(packetwrapper2, Protocol1_7_6_10TO1_8.class, true, true);
                        }
                    }

                    if (j > 0)
                    {
                        byte[] abyte3 = new byte[j * 3 + 1];
                        abyte3[0] = 1;

                        for (int k1 = 0; k1 < j; ++k1)
                        {
                            abyte3[k1 * 3 + 1] = (byte)(abyte[k1 * 4] << 4 | abyte[k1 * 4 + 3] & 15);
                            abyte3[k1 * 3 + 2] = abyte[k1 * 4 + 1];
                            abyte3[k1 * 3 + 3] = abyte[k1 * 4 + 2];
                        }

                        PacketWrapper packetwrapper1 = PacketWrapper.create(52, (ByteBuf)null, packetWrapper.user());
                        packetwrapper1.write(Type.VAR_INT, Integer.valueOf(i));
                        packetwrapper1.write(Type.SHORT, Short.valueOf((short)abyte3.length));
                        CustomByteType custombytetype = new CustomByteType(abyte3.length);
                        packetwrapper1.write(custombytetype, abyte3);
                        PacketUtil.sendPacket(packetwrapper1, Protocol1_7_6_10TO1_8.class, true, true);
                    }

                    PacketWrapper packetwrapper = PacketWrapper.create(52, (ByteBuf)null, packetWrapper.user());
                    packetwrapper.write(Type.VAR_INT, Integer.valueOf(i));
                    packetwrapper.write(Type.SHORT, Short.valueOf((short)2));
                    packetwrapper.write(new CustomByteType(Integer.valueOf(2)), new byte[]{2, b0});
                    PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.BLOCK_ENTITY_DATA, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.SHORT, Short.valueOf((short)position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.NBT, Types1_7_6_10.COMPRESSED_NBT);
            }
        });
        protocol.cancelClientbound(ClientboundPackets1_8.SERVER_DIFFICULTY);
        protocol.cancelClientbound(ClientboundPackets1_8.COMBAT_EVENT);
        protocol.registerClientbound(ClientboundPackets1_8.WORLD_BORDER, (ClientboundPacketType)null, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    WorldBorder worldborder = (WorldBorder)packetWrapper.user().get(WorldBorder.class);

                    if (i == 0)
                    {
                        worldborder.setSize(((Double)packetWrapper.read(Type.DOUBLE)).doubleValue());
                    }
                    else if (i == 1)
                    {
                        worldborder.lerpSize(((Double)packetWrapper.read(Type.DOUBLE)).doubleValue(), ((Double)packetWrapper.read(Type.DOUBLE)).doubleValue(), ((Long)packetWrapper.read(VarLongType.VAR_LONG)).longValue());
                    }
                    else if (i == 2)
                    {
                        worldborder.setCenter(((Double)packetWrapper.read(Type.DOUBLE)).doubleValue(), ((Double)packetWrapper.read(Type.DOUBLE)).doubleValue());
                    }
                    else if (i == 3)
                    {
                        worldborder.init(((Double)packetWrapper.read(Type.DOUBLE)).doubleValue(), ((Double)packetWrapper.read(Type.DOUBLE)).doubleValue(), ((Double)packetWrapper.read(Type.DOUBLE)).doubleValue(), ((Double)packetWrapper.read(Type.DOUBLE)).doubleValue(), ((Long)packetWrapper.read(VarLongType.VAR_LONG)).longValue(), ((Integer)packetWrapper.read(Type.VAR_INT)).intValue(), ((Integer)packetWrapper.read(Type.VAR_INT)).intValue(), ((Integer)packetWrapper.read(Type.VAR_INT)).intValue());
                    }
                    else if (i == 4)
                    {
                        worldborder.setWarningTime(((Integer)packetWrapper.read(Type.VAR_INT)).intValue());
                    }
                    else if (i == 5)
                    {
                        worldborder.setWarningBlocks(((Integer)packetWrapper.read(Type.VAR_INT)).intValue());
                    }

                    packetWrapper.cancel();
                });
            }
        });
    }
}

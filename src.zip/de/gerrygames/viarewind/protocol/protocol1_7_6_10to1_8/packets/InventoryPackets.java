package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.packets;

import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.libs.gson.JsonElement;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.ServerboundPackets1_7;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.items.ItemRewriter;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.EntityTracker;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.GameProfileStorage;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.Windows;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.Types1_7_6_10;
import de.gerrygames.viarewind.utils.ChatUtil;
import java.util.UUID;
import java.util.function.Function;

public class InventoryPackets
{
    public static void register(Protocol1_7_6_10TO1_8 protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_8.OPEN_WINDOW, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.passthrough(Type.UNSIGNED_BYTE)).shortValue();
                    String s = (String)packetWrapper.read(Type.STRING);
                    short short2 = (short)Windows.getInventoryType(s);
                    ((Windows)packetWrapper.user().get(Windows.class)).types.put(Short.valueOf(short1), Short.valueOf(short2));
                    packetWrapper.write(Type.UNSIGNED_BYTE, Short.valueOf(short2));
                    JsonElement jsonelement = (JsonElement)packetWrapper.read(Type.COMPONENT);
                    String s1 = ChatUtil.jsonToLegacy(jsonelement);
                    s1 = ChatUtil.removeUnusedColor(s1, '8');

                    if (s1.length() > 32)
                    {
                        s1 = s1.substring(0, 32);
                    }

                    packetWrapper.write(Type.STRING, s1);
                    packetWrapper.passthrough(Type.UNSIGNED_BYTE);
                    packetWrapper.write(Type.BOOLEAN, Boolean.valueOf(true));

                    if (short2 == 11)
                    {
                        packetWrapper.passthrough(Type.INT);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.CLOSE_WINDOW, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    ((Windows)packetWrapper.user().get(Windows.class)).remove(short1);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.SET_SLOT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.read(Type.UNSIGNED_BYTE)).shortValue();
                    short short2 = ((Windows)packetWrapper.user().get(Windows.class)).get(short1);
                    packetWrapper.write(Type.UNSIGNED_BYTE, Short.valueOf(short1));
                    short short3 = ((Short)packetWrapper.read(Type.SHORT)).shortValue();

                    if (short2 == 4)
                    {
                        if (short3 == 1)
                        {
                            packetWrapper.cancel();
                            return;
                        }

                        if (short3 >= 2)
                        {
                            --short3;
                        }
                    }

                    packetWrapper.write(Type.SHORT, Short.valueOf(short3));
                });
                this.map(Type.ITEM, Types1_7_6_10.COMPRESSED_NBT_ITEM);
                this.handler((packetWrapper) ->
                {
                    Item item = (Item)packetWrapper.get(Types1_7_6_10.COMPRESSED_NBT_ITEM, 0);
                    ItemRewriter.toClient(item);
                    packetWrapper.set(Types1_7_6_10.COMPRESSED_NBT_ITEM, 0, item);
                });
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();

                    if (short1 == 0)
                    {
                        short short2 = ((Short)packetWrapper.get(Type.SHORT, 0)).shortValue();

                        if (short2 >= 5 && short2 <= 8)
                        {
                            Item item = (Item)packetWrapper.get(Types1_7_6_10.COMPRESSED_NBT_ITEM, 0);
                            EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                            UUID uuid = packetWrapper.user().getProtocolInfo().getUuid();
                            Item[] aitem = entitytracker.getPlayerEquipment(uuid);

                            if (aitem == null)
                            {
                                entitytracker.setPlayerEquipment(uuid, aitem = new Item[5]);
                            }

                            aitem[9 - short2] = item;

                            if (entitytracker.getGamemode() == 3)
                            {
                                packetWrapper.cancel();
                            }
                        }
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.WINDOW_ITEMS, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.read(Type.UNSIGNED_BYTE)).shortValue();
                    short short2 = ((Windows)packetWrapper.user().get(Windows.class)).get(short1);
                    packetWrapper.write(Type.UNSIGNED_BYTE, Short.valueOf(short1));
                    Item[] aitem = (Item[])packetWrapper.read(Type.ITEM_ARRAY);

                    if (short2 == 4)
                    {
                        Item[] aitem1 = aitem;
                        aitem = new Item[aitem.length - 1];
                        aitem[0] = aitem1[0];
                        System.arraycopy(aitem1, 2, aitem, 1, aitem1.length - 3);
                    }

                    for (int i = 0; i < aitem.length; ++i)
                    {
                        aitem[i] = ItemRewriter.toClient(aitem[i]);
                    }

                    packetWrapper.write(Types1_7_6_10.COMPRESSED_NBT_ITEM_ARRAY, aitem);
                });
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();

                    if (short1 == 0)
                    {
                        Item[] aitem = (Item[])packetWrapper.get(Types1_7_6_10.COMPRESSED_NBT_ITEM_ARRAY, 0);
                        EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                        UUID uuid = packetWrapper.user().getProtocolInfo().getUuid();
                        Item[] aitem1 = entitytracker.getPlayerEquipment(uuid);

                        if (aitem1 == null)
                        {
                            entitytracker.setPlayerEquipment(uuid, aitem1 = new Item[5]);
                        }

                        for (int i = 5; i < 9; ++i)
                        {
                            aitem1[9 - i] = aitem[i];

                            if (entitytracker.getGamemode() == 3)
                            {
                                aitem[i] = null;
                            }
                        }

                        if (entitytracker.getGamemode() == 3)
                        {
                            GameProfileStorage.GameProfile gameprofilestorage$gameprofile = ((GameProfileStorage)packetWrapper.user().get(GameProfileStorage.class)).get(uuid);

                            if (gameprofilestorage$gameprofile != null)
                            {
                                aitem[5] = gameprofilestorage$gameprofile.getSkull();
                            }
                        }
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.WINDOW_PROPERTY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.SHORT);
                this.map(Type.SHORT);
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    Windows windows = (Windows)packetWrapper.user().get(Windows.class);
                    short short2 = windows.get(short1);
                    short short3 = ((Short)packetWrapper.get(Type.SHORT, 0)).shortValue();
                    short short4 = ((Short)packetWrapper.get(Type.SHORT, 1)).shortValue();

                    if (short2 != -1)
                    {
                        if (short2 == 2)
                        {
                            Windows.Furnace windows$furnace = windows.furnace.computeIfAbsent(Short.valueOf(short1), (x) ->
                            {
                                return new Windows.Furnace();
                            });

                            if (short3 != 0 && short3 != 1)
                            {
                                if (short3 == 2 || short3 == 3)
                                {
                                    if (short3 == 2)
                                    {
                                        windows$furnace.setProgress(short4);
                                    }
                                    else
                                    {
                                        windows$furnace.setMaxProgress(short4);
                                    }

                                    if (windows$furnace.getMaxProgress() == 0)
                                    {
                                        packetWrapper.cancel();
                                        return;
                                    }

                                    short4 = (short)(200 * windows$furnace.getProgress() / windows$furnace.getMaxProgress());
                                    packetWrapper.set(Type.SHORT, 0, Short.valueOf((short)0));
                                    packetWrapper.set(Type.SHORT, 1, Short.valueOf(short4));
                                }
                            }
                            else
                            {
                                if (short3 == 0)
                                {
                                    windows$furnace.setFuelLeft(short4);
                                }
                                else
                                {
                                    windows$furnace.setMaxFuel(short4);
                                }

                                if (windows$furnace.getMaxFuel() == 0)
                                {
                                    packetWrapper.cancel();
                                    return;
                                }

                                short4 = (short)(200 * windows$furnace.getFuelLeft() / windows$furnace.getMaxFuel());
                                packetWrapper.set(Type.SHORT, 0, Short.valueOf((short)1));
                                packetWrapper.set(Type.SHORT, 1, Short.valueOf(short4));
                            }
                        }
                        else if (short2 == 4)
                        {
                            if (short3 > 2)
                            {
                                packetWrapper.cancel();
                                return;
                            }
                        }
                        else if (short2 == 8)
                        {
                            windows.levelCost = short4;
                            windows.anvilId = short1;
                        }
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.CLOSE_WINDOW, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.handler((packetWrapper) ->
                {
                    short short1 = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    ((Windows)packetWrapper.user().get(Windows.class)).remove(short1);
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.CLICK_WINDOW, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    short short1 = (short)((Byte)packetWrapper.read(Type.BYTE)).byteValue();
                    packetWrapper.write(Type.UNSIGNED_BYTE, Short.valueOf(short1));
                    short short2 = ((Windows)packetWrapper.user().get(Windows.class)).get(short1);
                    short short3 = ((Short)packetWrapper.read(Type.SHORT)).shortValue();

                    if (short2 == 4 && short3 > 0)
                    {
                        ++short3;
                    }

                    packetWrapper.write(Type.SHORT, Short.valueOf(short3));
                });
                this.map(Type.BYTE);
                this.map(Type.SHORT);
                this.map(Type.BYTE);
                this.map(Types1_7_6_10.COMPRESSED_NBT_ITEM, Type.ITEM);
                this.handler((packetWrapper) ->
                {
                    Item item = (Item)packetWrapper.get(Type.ITEM, 0);
                    ItemRewriter.toServer(item);
                    packetWrapper.set(Type.ITEM, 0, item);
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.WINDOW_CONFIRMATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.BYTE);
                this.map(Type.SHORT);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    int i = ((Short)packetWrapper.get(Type.SHORT, 0)).shortValue();

                    if (i == -89)
                    {
                        packetWrapper.cancel();
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.CREATIVE_INVENTORY_ACTION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.SHORT);
                this.map(Types1_7_6_10.COMPRESSED_NBT_ITEM, Type.ITEM);
                this.handler((packetWrapper) ->
                {
                    Item item = (Item)packetWrapper.get(Type.ITEM, 0);
                    ItemRewriter.toServer(item);
                    packetWrapper.set(Type.ITEM, 0, item);
                });
            }
        });
    }
}

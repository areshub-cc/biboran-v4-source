package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.packets;

import com.viaversion.viaversion.api.minecraft.Position;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.types.version.Types1_8;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.items.ItemRewriter;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.metadata.MetadataRewriter;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.EntityTracker;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.GameProfileStorage;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.Types1_7_6_10;
import de.gerrygames.viarewind.replacement.EntityReplacement;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.List;
import java.util.UUID;

public class EntityPackets
{
    public static void register(Protocol1_7_6_10TO1_8 protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_EQUIPMENT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.SHORT);
                this.map(Type.ITEM, Types1_7_6_10.COMPRESSED_NBT_ITEM);
                this.handler((packetWrapper) ->
                {
                    Item item = (Item)packetWrapper.get(Types1_7_6_10.COMPRESSED_NBT_ITEM, 0);
                    ItemRewriter.toClient(item);
                    packetWrapper.set(Types1_7_6_10.COMPRESSED_NBT_ITEM, 0, item);
                });
                this.handler((packetWrapper) ->
                {
                    if (((Short)packetWrapper.get(Type.SHORT, 0)).shortValue() > 4)
                    {
                        packetWrapper.cancel();
                    }
                });
                this.handler((packetWrapper) ->
                {
                    if (!packetWrapper.isCancelled())
                    {
                        EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                        UUID uuid = entitytracker.getPlayerUUID(((Integer)packetWrapper.get(Type.INT, 0)).intValue());

                        if (uuid != null)
                        {
                            Item[] aitem = entitytracker.getPlayerEquipment(uuid);

                            if (aitem == null)
                            {
                                entitytracker.setPlayerEquipment(uuid, aitem = new Item[5]);
                            }

                            aitem[((Short)packetWrapper.get(Type.SHORT, 0)).shortValue()] = (Item)packetWrapper.get(Types1_7_6_10.COMPRESSED_NBT_ITEM, 0);
                            GameProfileStorage gameprofilestorage = (GameProfileStorage)packetWrapper.user().get(GameProfileStorage.class);
                            GameProfileStorage.GameProfile gameprofilestorage$gameprofile = gameprofilestorage.get(uuid);

                            if (gameprofilestorage$gameprofile != null && gameprofilestorage$gameprofile.gamemode == 3)
                            {
                                packetWrapper.cancel();
                            }
                        }
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.USE_BED, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.UNSIGNED_BYTE, Short.valueOf((short)position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.COLLECT_ITEM, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.VAR_INT, Type.INT);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_VELOCITY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.SHORT);
                this.map(Type.SHORT);
                this.map(Type.SHORT);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.DESTROY_ENTITIES, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    int[] aint = (int[])packetWrapper.read(Type.VAR_INT_ARRAY_PRIMITIVE);
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);

                    for (int i : aint)
                    {
                        entitytracker.removeEntity(i);
                    }

                    while (aint.length > 127)
                    {
                        int[] aint1 = new int[127];
                        System.arraycopy(aint, 0, aint1, 0, 127);
                        int[] aint2 = new int[aint.length - 127];
                        System.arraycopy(aint, 127, aint2, 0, aint2.length);
                        aint = aint2;
                        PacketWrapper packetwrapper = PacketWrapper.create(19, (ByteBuf)null, packetWrapper.user());
                        packetwrapper.write(Types1_7_6_10.INT_ARRAY, aint1);
                        PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
                    }

                    packetWrapper.write(Types1_7_6_10.INT_ARRAY, aint);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_MOVEMENT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_POSITION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BOOLEAN, Type.NOTHING);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        int j = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        int k = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                        int l = ((Byte)packetWrapper.get(Type.BYTE, 2)).byteValue();
                        entityreplacement.relMove((double)j / 32.0D, (double)k / 32.0D, (double)l / 32.0D);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_ROTATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BOOLEAN, Type.NOTHING);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        int j = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        int k = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                        entityreplacement.setYawPitch((float)j * 360.0F / 256.0F, (float)k * 360.0F / 256.0F);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_POSITION_AND_ROTATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BOOLEAN, Type.NOTHING);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        int j = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        int k = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                        int l = ((Byte)packetWrapper.get(Type.BYTE, 2)).byteValue();
                        int i1 = ((Byte)packetWrapper.get(Type.BYTE, 3)).byteValue();
                        int j1 = ((Byte)packetWrapper.get(Type.BYTE, 4)).byteValue();
                        entityreplacement.relMove((double)j / 32.0D, (double)k / 32.0D, (double)l / 32.0D);
                        entityreplacement.setYawPitch((float)i1 * 360.0F / 256.0F, (float)j1 * 360.0F / 256.0F);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_TELEPORT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BOOLEAN, Type.NOTHING);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityType entitytype = (EntityType)entitytracker.getClientEntityTypes().get(Integer.valueOf(i));

                    if (entitytype == EntityType.MINECART_ABSTRACT)
                    {
                        int j = ((Integer)packetWrapper.get(Type.INT, 2)).intValue();
                        j = j + 12;
                        packetWrapper.set(Type.INT, 2, Integer.valueOf(j));
                    }
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        int j = ((Integer)packetWrapper.get(Type.INT, 1)).intValue();
                        int k = ((Integer)packetWrapper.get(Type.INT, 2)).intValue();
                        int l = ((Integer)packetWrapper.get(Type.INT, 3)).intValue();
                        int i1 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        int j1 = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                        entityreplacement.setLocation((double)j / 32.0D, (double)k / 32.0D, (double)l / 32.0D);
                        entityreplacement.setYawPitch((float)i1 * 360.0F / 256.0F, (float)j1 * 360.0F / 256.0F);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_HEAD_LOOK, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.BYTE);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                    if (entityreplacement != null)
                    {
                        packetWrapper.cancel();
                        int j = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        entityreplacement.setHeadYaw((float)j * 360.0F / 256.0F);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ATTACH_ENTITY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    boolean flag = ((Boolean)packetWrapper.get(Type.BOOLEAN, 0)).booleanValue();

                    if (!flag)
                    {
                        int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                        int j = ((Integer)packetWrapper.get(Type.INT, 1)).intValue();
                        EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                        entitytracker.setPassenger(j, i);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_METADATA, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Types1_8.METADATA_LIST, Types1_7_6_10.METADATA_LIST);
                this.handler((wrapper) ->
                {
                    List<Metadata> list = (List)wrapper.get(Types1_7_6_10.METADATA_LIST, 0);
                    int i = ((Integer)wrapper.get(Type.INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)wrapper.user().get(EntityTracker.class);

                    if (entitytracker.getClientEntityTypes().containsKey(Integer.valueOf(i)))
                    {
                        EntityReplacement entityreplacement = entitytracker.getEntityReplacement(i);

                        if (entityreplacement != null)
                        {
                            wrapper.cancel();
                            entityreplacement.updateMetadata(list);
                        }
                        else
                        {
                            MetadataRewriter.transform((EntityType)entitytracker.getClientEntityTypes().get(Integer.valueOf(i)), list);

                            if (list.isEmpty())
                            {
                                wrapper.cancel();
                            }
                        }
                    }
                    else {
                        entitytracker.addMetadataToBuffer(i, list);
                        wrapper.cancel();
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_EFFECT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.VAR_INT, Type.SHORT);
                this.map(Type.BYTE, Type.NOTHING);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.REMOVE_ENTITY_EFFECT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.map(Type.BYTE);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.ENTITY_PROPERTIES, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT, Type.INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);

                    if (entitytracker.getEntityReplacement(i) != null)
                    {
                        packetWrapper.cancel();
                    }
                    else {
                        int j = ((Integer)packetWrapper.passthrough(Type.INT)).intValue();

                        for (int k = 0; k < j; ++k)
                        {
                            packetWrapper.passthrough(Type.STRING);
                            packetWrapper.passthrough(Type.DOUBLE);
                            int l = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                            packetWrapper.write(Type.SHORT, Short.valueOf((short)l));

                            for (int i1 = 0; i1 < l; ++i1)
                            {
                                packetWrapper.passthrough(Type.UUID);
                                packetWrapper.passthrough(Type.DOUBLE);
                                packetWrapper.passthrough(Type.BYTE);
                            }
                        }
                    }
                });
            }
        });
        protocol.cancelClientbound(ClientboundPackets1_8.UPDATE_ENTITY_NBT);
    }
}

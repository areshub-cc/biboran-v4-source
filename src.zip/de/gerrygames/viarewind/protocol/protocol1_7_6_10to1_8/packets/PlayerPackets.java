package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.packets;

import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.minecraft.Position;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.protocol.packet.ClientboundPacketType;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.libs.gson.JsonElement;
import com.viaversion.viaversion.libs.gson.JsonParser;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.CompoundTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.ListTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.StringTag;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import com.viaversion.viaversion.protocols.protocol1_9_3to1_9_1_2.storage.ClientWorld;
import de.gerrygames.viarewind.ViaRewind;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.ClientboundPackets1_7;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.ServerboundPackets1_7;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.entityreplacements.ArmorStandReplacement;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.items.ItemRewriter;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.provider.TitleRenderProvider;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.EntityTracker;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.GameProfileStorage;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.PlayerAbilities;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.PlayerPosition;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.Scoreboard;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.Windows;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.Types1_7_6_10;
import de.gerrygames.viarewind.replacement.EntityReplacement;
import de.gerrygames.viarewind.utils.ChatUtil;
import de.gerrygames.viarewind.utils.PacketUtil;
import de.gerrygames.viarewind.utils.Utils;
import de.gerrygames.viarewind.utils.math.AABB;
import de.gerrygames.viarewind.utils.math.Ray3d;
import de.gerrygames.viarewind.utils.math.RayTracing;
import de.gerrygames.viarewind.utils.math.Vector3d;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.Unpooled;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

public class PlayerPackets
{
    public static void register(Protocol1_7_6_10TO1_8 protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_8.JOIN_GAME, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.BYTE);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.STRING);
                this.map(Type.BOOLEAN, Type.NOTHING);
                this.handler((packetWrapper) ->
                {
                    if (ViaRewind.getConfig().isReplaceAdventureMode())
                    {
                        if (((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue() == 2)
                        {
                            packetWrapper.set(Type.UNSIGNED_BYTE, 0, Short.valueOf((short)0));
                        }
                    }
                });
                this.handler((packetWrapper) ->
                {
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.setGamemode(((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue());
                    entitytracker.setPlayerId(((Integer)packetWrapper.get(Type.INT, 0)).intValue());
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(entitytracker.getPlayerId()), EntityType.ENTITY_HUMAN);
                    entitytracker.setDimension(((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue());
                });
                this.handler((packetWrapper) ->
                {
                    ClientWorld clientworld = (ClientWorld)packetWrapper.user().get(ClientWorld.class);
                    clientworld.setEnvironment(((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue());
                });
                this.handler((wrapper) ->
                {
                    wrapper.user().put(new Scoreboard(wrapper.user()));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.CHAT_MESSAGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.COMPONENT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();

                    if (i == 2)
                    {
                        packetWrapper.cancel();
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.SPAWN_POSITION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.UPDATE_HEALTH, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.FLOAT);
                this.map(Type.VAR_INT, Type.SHORT);
                this.map(Type.FLOAT);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.RESPAWN, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    if (ViaRewind.getConfig().isReplaceAdventureMode())
                    {
                        if (((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 1)).shortValue() == 2)
                        {
                            packetWrapper.set(Type.UNSIGNED_BYTE, 1, Short.valueOf((short)0));
                        }
                    }
                });
                this.handler((packetWrapper) ->
                {
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.setGamemode(((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 1)).shortValue());

                    if (entitytracker.getDimension() != ((Integer)packetWrapper.get(Type.INT, 0)).intValue())
                    {
                        entitytracker.setDimension(((Integer)packetWrapper.get(Type.INT, 0)).intValue());
                        entitytracker.clearEntities();
                        entitytracker.getClientEntityTypes().put(Integer.valueOf(entitytracker.getPlayerId()), EntityType.ENTITY_HUMAN);
                    }
                });
                this.handler((packetWrapper) ->
                {
                    ClientWorld clientworld = (ClientWorld)packetWrapper.user().get(ClientWorld.class);
                    clientworld.setEnvironment(((Integer)packetWrapper.get(Type.INT, 0)).intValue());
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.PLAYER_POSITION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.handler((packetWrapper) ->
                {
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);
                    playerposition.setPositionPacketReceived(true);
                    int i = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();

                    if ((i & 1) == 1)
                    {
                        double d0 = ((Double)packetWrapper.get(Type.DOUBLE, 0)).doubleValue();
                        d0 = d0 + playerposition.getPosX();
                        packetWrapper.set(Type.DOUBLE, 0, Double.valueOf(d0));
                    }

                    double d2 = ((Double)packetWrapper.get(Type.DOUBLE, 1)).doubleValue();

                    if ((i & 2) == 2)
                    {
                        d2 += playerposition.getPosY();
                    }

                    playerposition.setReceivedPosY(d2);
                    ++d2;
                    packetWrapper.set(Type.DOUBLE, 1, Double.valueOf(d2));

                    if ((i & 4) == 4)
                    {
                        double d1 = ((Double)packetWrapper.get(Type.DOUBLE, 2)).doubleValue();
                        d1 = d1 + playerposition.getPosZ();
                        packetWrapper.set(Type.DOUBLE, 2, Double.valueOf(d1));
                    }

                    if ((i & 8) == 8)
                    {
                        float f = ((Float)packetWrapper.get(Type.FLOAT, 0)).floatValue();
                        f = f + playerposition.getYaw();
                        packetWrapper.set(Type.FLOAT, 0, Float.valueOf(f));
                    }

                    if ((i & 16) == 16)
                    {
                        float f1 = ((Float)packetWrapper.get(Type.FLOAT, 1)).floatValue();
                        f1 = f1 + playerposition.getPitch();
                        packetWrapper.set(Type.FLOAT, 1, Float.valueOf(f1));
                    }
                });
                this.handler((packetWrapper) ->
                {
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);
                    packetWrapper.write(Type.BOOLEAN, Boolean.valueOf(playerposition.isOnGround()));
                });
                this.handler((packetWrapper) ->
                {
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);

                    if (entitytracker.getSpectating() != entitytracker.getPlayerId())
                    {
                        packetWrapper.cancel();
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.SET_EXPERIENCE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.FLOAT);
                this.map(Type.VAR_INT, Type.SHORT);
                this.map(Type.VAR_INT, Type.SHORT);
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.GAME_EVENT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.FLOAT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();

                    if (i == 3)
                    {
                        int j = ((Float)packetWrapper.get(Type.FLOAT, 0)).intValue();
                        EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);

                        if (j == 3 || entitytracker.getGamemode() == 3)
                        {
                            UUID uuid = packetWrapper.user().getProtocolInfo().getUuid();
                            Item[] aitem;

                            if (j == 3)
                            {
                                GameProfileStorage.GameProfile gameprofilestorage$gameprofile = ((GameProfileStorage)packetWrapper.user().get(GameProfileStorage.class)).get(uuid);
                                aitem = new Item[5];
                                aitem[4] = gameprofilestorage$gameprofile.getSkull();
                            }
                            else
                            {
                                aitem = entitytracker.getPlayerEquipment(uuid);

                                if (aitem == null)
                                {
                                    aitem = new Item[5];
                                }
                            }

                            for (int k = 1; k < 5; ++k)
                            {
                                PacketWrapper packetwrapper = PacketWrapper.create(47, (ByteBuf)null, packetWrapper.user());
                                packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
                                packetwrapper.write(Type.SHORT, Short.valueOf((short)(9 - k)));
                                packetwrapper.write(Types1_7_6_10.COMPRESSED_NBT_ITEM, aitem[k]);
                                PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
                            }
                        }
                    }
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();

                    if (i == 3)
                    {
                        int j = ((Float)packetWrapper.get(Type.FLOAT, 0)).intValue();

                        if (j == 2 && ViaRewind.getConfig().isReplaceAdventureMode())
                        {
                            j = 0;
                            packetWrapper.set(Type.FLOAT, 0, Float.valueOf(0.0F));
                        }

                        ((EntityTracker)packetWrapper.user().get(EntityTracker.class)).setGamemode(j);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.OPEN_SIGN_EDITOR, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.PLAYER_INFO, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    packetWrapper.cancel();
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    int j = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    GameProfileStorage gameprofilestorage = (GameProfileStorage)packetWrapper.user().get(GameProfileStorage.class);

                    for (int k = 0; k < j; ++k)
                    {
                        UUID uuid = (UUID)packetWrapper.read(Type.UUID);

                        if (i == 0)
                        {
                            String s1 = (String)packetWrapper.read(Type.STRING);
                            GameProfileStorage.GameProfile gameprofilestorage$gameprofile4 = gameprofilestorage.get(uuid);

                            if (gameprofilestorage$gameprofile4 == null)
                            {
                                gameprofilestorage$gameprofile4 = gameprofilestorage.put(uuid, s1);
                            }

                            int k1 = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();

                            while (k1-- > 0)
                            {
                                gameprofilestorage$gameprofile4.properties.add(new GameProfileStorage.Property((String)packetWrapper.read(Type.STRING), (String)packetWrapper.read(Type.STRING), ((Boolean)packetWrapper.read(Type.BOOLEAN)).booleanValue() ? (String)packetWrapper.read(Type.STRING) : null));
                            }

                            int l1 = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                            int i2 = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                            gameprofilestorage$gameprofile4.ping = i2;
                            gameprofilestorage$gameprofile4.gamemode = l1;

                            if (((Boolean)packetWrapper.read(Type.BOOLEAN)).booleanValue())
                            {
                                gameprofilestorage$gameprofile4.setDisplayName(ChatUtil.jsonToLegacy((JsonElement)packetWrapper.read(Type.COMPONENT)));
                            }

                            PacketWrapper packetwrapper3 = PacketWrapper.create(56, (ByteBuf)null, packetWrapper.user());
                            packetwrapper3.write(Type.STRING, gameprofilestorage$gameprofile4.name);
                            packetwrapper3.write(Type.BOOLEAN, Boolean.valueOf(true));
                            packetwrapper3.write(Type.SHORT, Short.valueOf((short)i2));
                            PacketUtil.sendPacket(packetwrapper3, Protocol1_7_6_10TO1_8.class);
                        }
                        else if (i == 1)
                        {
                            int j1 = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                            GameProfileStorage.GameProfile gameprofilestorage$gameprofile3 = gameprofilestorage.get(uuid);

                            if (gameprofilestorage$gameprofile3 != null && gameprofilestorage$gameprofile3.gamemode != j1)
                            {
                                if (j1 == 3 || gameprofilestorage$gameprofile3.gamemode == 3)
                                {
                                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                                    int l = entitytracker.getPlayerEntityId(uuid);

                                    if (l != -1)
                                    {
                                        Item[] aitem;

                                        if (j1 == 3)
                                        {
                                            aitem = new Item[5];
                                            aitem[4] = gameprofilestorage$gameprofile3.getSkull();
                                        }
                                        else
                                        {
                                            aitem = entitytracker.getPlayerEquipment(uuid);

                                            if (aitem == null)
                                            {
                                                aitem = new Item[5];
                                            }
                                        }

                                        for (short short1 = 0; short1 < 5; ++short1)
                                        {
                                            PacketWrapper packetwrapper2 = PacketWrapper.create(4, (ByteBuf)null, packetWrapper.user());
                                            packetwrapper2.write(Type.INT, Integer.valueOf(l));
                                            packetwrapper2.write(Type.SHORT, Short.valueOf(short1));
                                            packetwrapper2.write(Types1_7_6_10.COMPRESSED_NBT_ITEM, aitem[short1]);
                                            PacketUtil.sendPacket(packetwrapper2, Protocol1_7_6_10TO1_8.class);
                                        }
                                    }
                                }

                                gameprofilestorage$gameprofile3.gamemode = j1;
                            }
                        }
                        else if (i == 2)
                        {
                            int i1 = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                            GameProfileStorage.GameProfile gameprofilestorage$gameprofile2 = gameprofilestorage.get(uuid);

                            if (gameprofilestorage$gameprofile2 != null)
                            {
                                gameprofilestorage$gameprofile2.ping = i1;
                                PacketWrapper packetwrapper1 = PacketWrapper.create(56, (ByteBuf)null, packetWrapper.user());
                                packetwrapper1.write(Type.STRING, gameprofilestorage$gameprofile2.name);
                                packetwrapper1.write(Type.BOOLEAN, Boolean.valueOf(true));
                                packetwrapper1.write(Type.SHORT, Short.valueOf((short)i1));
                                PacketUtil.sendPacket(packetwrapper1, Protocol1_7_6_10TO1_8.class);
                            }
                        }
                        else if (i == 3)
                        {
                            String s = ((Boolean)packetWrapper.read(Type.BOOLEAN)).booleanValue() ? ChatUtil.jsonToLegacy((JsonElement)packetWrapper.read(Type.COMPONENT)) : null;
                            GameProfileStorage.GameProfile gameprofilestorage$gameprofile1 = gameprofilestorage.get(uuid);

                            if (gameprofilestorage$gameprofile1 != null && (gameprofilestorage$gameprofile1.displayName != null || s != null) && (gameprofilestorage$gameprofile1.displayName == null && s != null || gameprofilestorage$gameprofile1.displayName != null && s == null || !gameprofilestorage$gameprofile1.displayName.equals(s)))
                            {
                                gameprofilestorage$gameprofile1.setDisplayName(s);
                            }
                        }
                        else if (i == 4)
                        {
                            GameProfileStorage.GameProfile gameprofilestorage$gameprofile = gameprofilestorage.remove(uuid);

                            if (gameprofilestorage$gameprofile != null)
                            {
                                PacketWrapper packetwrapper = PacketWrapper.create(56, (ByteBuf)null, packetWrapper.user());
                                packetwrapper.write(Type.STRING, gameprofilestorage$gameprofile.name);
                                packetwrapper.write(Type.BOOLEAN, Boolean.valueOf(false));
                                packetwrapper.write(Type.SHORT, Short.valueOf((short)gameprofilestorage$gameprofile.ping));
                                PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
                            }
                        }
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.PLAYER_ABILITIES, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.BYTE);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.handler((packetWrapper) ->
                {
                    byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                    float f = ((Float)packetWrapper.get(Type.FLOAT, 0)).floatValue();
                    float f1 = ((Float)packetWrapper.get(Type.FLOAT, 1)).floatValue();
                    PlayerAbilities playerabilities = (PlayerAbilities)packetWrapper.user().get(PlayerAbilities.class);
                    playerabilities.setInvincible((b0 & 8) == 8);
                    playerabilities.setAllowFly((b0 & 4) == 4);
                    playerabilities.setFlying((b0 & 2) == 2);
                    playerabilities.setCreative((b0 & 1) == 1);
                    playerabilities.setFlySpeed(f);
                    playerabilities.setWalkSpeed(f1);

                    if (playerabilities.isSprinting() && playerabilities.isFlying())
                    {
                        packetWrapper.set(Type.FLOAT, 0, Float.valueOf(playerabilities.getFlySpeed() * 2.0F));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.PLUGIN_MESSAGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);

                    if (s.equalsIgnoreCase("MC|TrList"))
                    {
                        packetWrapper.passthrough(Type.INT);
                        int i;

                        if (packetWrapper.isReadable(Type.BYTE, 0))
                        {
                            i = ((Byte)packetWrapper.passthrough(Type.BYTE)).byteValue();
                        }
                        else
                        {
                            i = ((Short)packetWrapper.passthrough(Type.UNSIGNED_BYTE)).shortValue();
                        }

                        for (int j = 0; j < i; ++j)
                        {
                            Item item = ItemRewriter.toClient((Item)packetWrapper.read(Type.ITEM));
                            packetWrapper.write(Types1_7_6_10.COMPRESSED_NBT_ITEM, item);
                            item = ItemRewriter.toClient((Item)packetWrapper.read(Type.ITEM));
                            packetWrapper.write(Types1_7_6_10.COMPRESSED_NBT_ITEM, item);
                            boolean flag = ((Boolean)packetWrapper.passthrough(Type.BOOLEAN)).booleanValue();

                            if (flag)
                            {
                                item = ItemRewriter.toClient((Item)packetWrapper.read(Type.ITEM));
                                packetWrapper.write(Types1_7_6_10.COMPRESSED_NBT_ITEM, item);
                            }

                            packetWrapper.passthrough(Type.BOOLEAN);
                            packetWrapper.read(Type.INT);
                            packetWrapper.read(Type.INT);
                        }
                    }
                    else if (s.equalsIgnoreCase("MC|Brand"))
                    {
                        packetWrapper.write(Type.REMAINING_BYTES, ((String)packetWrapper.read(Type.STRING)).getBytes(StandardCharsets.UTF_8));
                    }

                    packetWrapper.cancel();
                    packetWrapper.setId(-1);
                    ByteBuf bytebuf = Unpooled.buffer();
                    packetWrapper.writeToBuffer(bytebuf);
                    PacketWrapper packetwrapper = PacketWrapper.create(63, bytebuf, packetWrapper.user());
                    packetwrapper.passthrough(Type.STRING);

                    if (bytebuf.readableBytes() <= 32767)
                    {
                        packetwrapper.write(Type.SHORT, Short.valueOf((short)bytebuf.readableBytes()));
                        packetwrapper.send(Protocol1_7_6_10TO1_8.class);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.CAMERA, (ClientboundPacketType)null, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    packetWrapper.cancel();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                    int j = entitytracker.getSpectating();

                    if (j != i)
                    {
                        entitytracker.setSpectating(i);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.TITLE, (ClientboundPacketType)null, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    packetWrapper.cancel();
                    TitleRenderProvider titlerenderprovider = (TitleRenderProvider)Via.getManager().getProviders().get(TitleRenderProvider.class);

                    if (titlerenderprovider != null)
                    {
                        int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                        UUID uuid = Utils.getUUID(packetWrapper.user());

                        switch (i)
                        {
                            case 0:
                                titlerenderprovider.setTitle(uuid, (String)packetWrapper.read(Type.STRING));
                                break;

                            case 1:
                                titlerenderprovider.setSubTitle(uuid, (String)packetWrapper.read(Type.STRING));
                                break;

                            case 2:
                                titlerenderprovider.setTimings(uuid, ((Integer)packetWrapper.read(Type.INT)).intValue(), ((Integer)packetWrapper.read(Type.INT)).intValue(), ((Integer)packetWrapper.read(Type.INT)).intValue());
                                break;

                            case 3:
                                titlerenderprovider.clear(uuid);
                                break;

                            case 4:
                                titlerenderprovider.reset(uuid);
                        }
                    }
                });
            }
        });
        protocol.cancelClientbound(ClientboundPackets1_8.TAB_LIST);
        protocol.registerClientbound(ClientboundPackets1_8.RESOURCE_PACK, ClientboundPackets1_7.PLUGIN_MESSAGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.create(Type.STRING, "MC|RPack");
                this.handler((packetWrapper) ->
                {
                    ByteBuf bytebuf = ByteBufAllocator.DEFAULT.buffer();

                    try {
                        Type.STRING.write(bytebuf, (String)packetWrapper.read(Type.STRING));
                        packetWrapper.write(Type.SHORT_BYTE_ARRAY, (byte[])Type.REMAINING_BYTES.read(bytebuf));
                    }
                    finally {
                        bytebuf.release();
                    }
                });
                this.map(Type.STRING, Type.NOTHING);
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.CHAT_MESSAGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);
                    int i = ((EntityTracker)packetWrapper.user().get(EntityTracker.class)).getGamemode();

                    if (i == 3 && s.toLowerCase().startsWith("/stp "))
                    {
                        String s1 = s.split(" ")[1];
                        GameProfileStorage gameprofilestorage = (GameProfileStorage)packetWrapper.user().get(GameProfileStorage.class);
                        GameProfileStorage.GameProfile gameprofilestorage$gameprofile = gameprofilestorage.get(s1, true);

                        if (gameprofilestorage$gameprofile != null && gameprofilestorage$gameprofile.uuid != null)
                        {
                            packetWrapper.cancel();
                            PacketWrapper packetwrapper = PacketWrapper.create(24, (ByteBuf)null, packetWrapper.user());
                            packetwrapper.write(Type.UUID, gameprofilestorage$gameprofile.uuid);
                            PacketUtil.sendToServer(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
                        }
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.INTERACT_ENTITY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT, Type.VAR_INT);
                this.map(Type.BYTE, Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 1)).intValue();

                    if (i == 0)
                    {
                        int j = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                        EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                        EntityReplacement entityreplacement = entitytracker.getEntityReplacement(j);

                        if (entityreplacement instanceof ArmorStandReplacement)
                        {
                            ArmorStandReplacement armorstandreplacement = (ArmorStandReplacement)entityreplacement;
                            AABB aabb = armorstandreplacement.getBoundingBox();
                            PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);
                            Vector3d vector3d = new Vector3d(playerposition.getPosX(), playerposition.getPosY() + 1.8D, playerposition.getPosZ());
                            double d0 = Math.toRadians((double)playerposition.getYaw());
                            double d1 = Math.toRadians((double)playerposition.getPitch());
                            Vector3d vector3d1 = new Vector3d(-Math.cos(d1) * Math.sin(d0), -Math.sin(d1), Math.cos(d1) * Math.cos(d0));
                            Ray3d ray3d = new Ray3d(vector3d, vector3d1);
                            Vector3d vector3d2 = RayTracing.trace(ray3d, aabb, 5.0D);

                            if (vector3d2 != null)
                            {
                                vector3d2.substract(aabb.getMin());
                                i = 2;
                                packetWrapper.set(Type.VAR_INT, 1, Integer.valueOf(i));
                                packetWrapper.write(Type.FLOAT, Float.valueOf((float)vector3d2.getX()));
                                packetWrapper.write(Type.FLOAT, Float.valueOf((float)vector3d2.getY()));
                                packetWrapper.write(Type.FLOAT, Float.valueOf((float)vector3d2.getZ()));
                            }
                        }
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.PLAYER_MOVEMENT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);
                    playerposition.setOnGround(((Boolean)packetWrapper.get(Type.BOOLEAN, 0)).booleanValue());
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.PLAYER_POSITION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE, Type.NOTHING);
                this.map(Type.DOUBLE);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    double d0 = ((Double)packetWrapper.get(Type.DOUBLE, 0)).doubleValue();
                    double d1 = ((Double)packetWrapper.get(Type.DOUBLE, 1)).doubleValue();
                    double d2 = ((Double)packetWrapper.get(Type.DOUBLE, 2)).doubleValue();
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);

                    if (playerposition.isPositionPacketReceived())
                    {
                        playerposition.setPositionPacketReceived(false);
                        d1 -= 0.01D;
                        packetWrapper.set(Type.DOUBLE, 1, Double.valueOf(d1));
                    }

                    playerposition.setOnGround(((Boolean)packetWrapper.get(Type.BOOLEAN, 0)).booleanValue());
                    playerposition.setPos(d0, d1, d2);
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.PLAYER_ROTATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);
                    playerposition.setYaw(((Float)packetWrapper.get(Type.FLOAT, 0)).floatValue());
                    playerposition.setPitch(((Float)packetWrapper.get(Type.FLOAT, 1)).floatValue());
                    playerposition.setOnGround(((Boolean)packetWrapper.get(Type.BOOLEAN, 0)).booleanValue());
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.PLAYER_POSITION_AND_ROTATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE);
                this.map(Type.DOUBLE, Type.NOTHING);
                this.map(Type.DOUBLE);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.map(Type.BOOLEAN);
                this.handler((packetWrapper) ->
                {
                    double d0 = ((Double)packetWrapper.get(Type.DOUBLE, 0)).doubleValue();
                    double d1 = ((Double)packetWrapper.get(Type.DOUBLE, 1)).doubleValue();
                    double d2 = ((Double)packetWrapper.get(Type.DOUBLE, 2)).doubleValue();
                    float f = ((Float)packetWrapper.get(Type.FLOAT, 0)).floatValue();
                    float f1 = ((Float)packetWrapper.get(Type.FLOAT, 1)).floatValue();
                    PlayerPosition playerposition = (PlayerPosition)packetWrapper.user().get(PlayerPosition.class);

                    if (playerposition.isPositionPacketReceived())
                    {
                        playerposition.setPositionPacketReceived(false);
                        d1 = playerposition.getReceivedPosY();
                        packetWrapper.set(Type.DOUBLE, 1, Double.valueOf(d1));
                    }

                    playerposition.setOnGround(((Boolean)packetWrapper.get(Type.BOOLEAN, 0)).booleanValue());
                    playerposition.setPos(d0, d1, d2);
                    playerposition.setYaw(f);
                    playerposition.setPitch(f1);
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.PLAYER_DIGGING, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    short short1 = ((Short)packetWrapper.read(Type.UNSIGNED_BYTE)).shortValue();
                    int j = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    packetWrapper.write(Type.POSITION, new Position(i, short1, j));
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.PLAYER_BLOCK_PLACEMENT, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    short short1 = ((Short)packetWrapper.read(Type.UNSIGNED_BYTE)).shortValue();
                    int j = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    packetWrapper.write(Type.POSITION, new Position(i, short1, j));
                    packetWrapper.passthrough(Type.BYTE);
                    Item item = (Item)packetWrapper.read(Types1_7_6_10.COMPRESSED_NBT_ITEM);
                    item = ItemRewriter.toServer(item);
                    packetWrapper.write(Type.ITEM, item);

                    for (int k = 0; k < 3; ++k)
                    {
                        packetWrapper.passthrough(Type.BYTE);
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.ANIMATION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    int j = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();

                    if (j != 1)
                    {
                        packetWrapper.cancel();

                        switch (j)
                        {
                            case 3:
                                j = 2;
                                break;

                            case 104:
                                j = 0;
                                break;

                            case 105:
                                j = 1;
                                break;

                            default:
                                return;
                        }

                        PacketWrapper packetwrapper = PacketWrapper.create(11, (ByteBuf)null, packetWrapper.user());
                        packetwrapper.write(Type.VAR_INT, Integer.valueOf(i));
                        packetwrapper.write(Type.VAR_INT, Integer.valueOf(j));
                        packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
                        PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.ENTITY_ACTION, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.INT, Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    packetWrapper.write(Type.VAR_INT, Integer.valueOf(((Byte)packetWrapper.read(Type.BYTE)).byteValue() - 1));
                });
                this.map(Type.INT, Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 1)).intValue();

                    if (i == 3 || i == 4)
                    {
                        PlayerAbilities playerabilities = (PlayerAbilities)packetWrapper.user().get(PlayerAbilities.class);
                        playerabilities.setSprinting(i == 3);
                        PacketWrapper packetwrapper = PacketWrapper.create(57, (ByteBuf)null, packetWrapper.user());
                        packetwrapper.write(Type.BYTE, Byte.valueOf(playerabilities.getFlags()));
                        packetwrapper.write(Type.FLOAT, Float.valueOf(playerabilities.isSprinting() ? playerabilities.getFlySpeed() * 2.0F : playerabilities.getFlySpeed()));
                        packetwrapper.write(Type.FLOAT, Float.valueOf(playerabilities.getWalkSpeed()));
                        PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.STEER_VEHICLE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.handler((packetWrapper) ->
                {
                    boolean flag = ((Boolean)packetWrapper.read(Type.BOOLEAN)).booleanValue();
                    boolean flag1 = ((Boolean)packetWrapper.read(Type.BOOLEAN)).booleanValue();
                    short short1 = 0;

                    if (flag)
                    {
                        ++short1;
                    }

                    if (flag1)
                    {
                        short1 = (short)(short1 + 2);
                    }

                    packetWrapper.write(Type.UNSIGNED_BYTE, Short.valueOf(short1));

                    if (flag1)
                    {
                        EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);

                        if (entitytracker.getSpectating() != entitytracker.getPlayerId())
                        {
                            PacketWrapper packetwrapper = PacketWrapper.create(11, (ByteBuf)null, packetWrapper.user());
                            packetwrapper.write(Type.VAR_INT, Integer.valueOf(entitytracker.getPlayerId()));
                            packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
                            packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
                            PacketWrapper packetwrapper1 = PacketWrapper.create(11, (ByteBuf)null, packetWrapper.user());
                            packetwrapper1.write(Type.VAR_INT, Integer.valueOf(entitytracker.getPlayerId()));
                            packetwrapper1.write(Type.VAR_INT, Integer.valueOf(1));
                            packetwrapper1.write(Type.VAR_INT, Integer.valueOf(0));
                            PacketUtil.sendToServer(packetwrapper, Protocol1_7_6_10TO1_8.class);
                        }
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.UPDATE_SIGN, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    short short1 = ((Short)packetWrapper.read(Type.SHORT)).shortValue();
                    int j = ((Integer)packetWrapper.read(Type.INT)).intValue();
                    packetWrapper.write(Type.POSITION, new Position(i, short1, j));

                    for (int k = 0; k < 4; ++k)
                    {
                        String s = (String)packetWrapper.read(Type.STRING);
                        s = ChatUtil.legacyToJson(s);
                        packetWrapper.write(Type.COMPONENT, JsonParser.parseString(s));
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.PLAYER_ABILITIES, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.BYTE);
                this.map(Type.FLOAT);
                this.map(Type.FLOAT);
                this.handler((packetWrapper) ->
                {
                    PlayerAbilities playerabilities = (PlayerAbilities)packetWrapper.user().get(PlayerAbilities.class);

                    if (playerabilities.isAllowFly())
                    {
                        byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                        playerabilities.setFlying((b0 & 2) == 2);
                    }

                    packetWrapper.set(Type.FLOAT, 0, Float.valueOf(playerabilities.getFlySpeed()));
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.TAB_COMPLETE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.create(Type.OPTIONAL_POSITION, (Object)null);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);

                    if (s.toLowerCase().startsWith("/stp "))
                    {
                        packetWrapper.cancel();
                        String[] astring = s.split(" ");

                        if (astring.length <= 2)
                        {
                            String s1 = astring.length == 1 ? "" : astring[1];
                            GameProfileStorage gameprofilestorage = (GameProfileStorage)packetWrapper.user().get(GameProfileStorage.class);
                            List<GameProfileStorage.GameProfile> list = gameprofilestorage.getAllWithPrefix(s1, true);
                            PacketWrapper packetwrapper = PacketWrapper.create(58, (ByteBuf)null, packetWrapper.user());
                            packetwrapper.write(Type.VAR_INT, Integer.valueOf(list.size()));

                            for (GameProfileStorage.GameProfile gameprofilestorage$gameprofile : list)
                            {
                                packetwrapper.write(Type.STRING, gameprofilestorage$gameprofile.name);
                            }

                            PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
                        }
                    }
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.CLIENT_SETTINGS, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BOOLEAN);
                this.map(Type.BYTE, Type.NOTHING);
                this.handler((packetWrapper) ->
                {
                    boolean flag = ((Boolean)packetWrapper.read(Type.BOOLEAN)).booleanValue();
                    packetWrapper.write(Type.UNSIGNED_BYTE, Short.valueOf((short)(flag ? 127 : 126)));
                });
            }
        });
        protocol.registerServerbound(ServerboundPackets1_7.PLUGIN_MESSAGE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.map(Type.SHORT, Type.NOTHING);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);
                    byte b0 = -1;

                    switch (s.hashCode())
                    {
                        case -751882236:
                            if (s.equals("MC|ItemName"))
                            {
                                b0 = 1;
                            }

                            break;

                        case -296231034:
                            if (s.equals("MC|BEdit"))
                            {
                                b0 = 2;
                            }

                            break;

                        case -295809223:
                            if (s.equals("MC|BSign"))
                            {
                                b0 = 3;
                            }

                            break;

                        case -294893183:
                            if (s.equals("MC|Brand"))
                            {
                                b0 = 4;
                            }

                            break;

                        case -278283530:
                            if (s.equals("MC|TrSel"))
                            {
                                b0 = 0;
                            }
                    }

                    switch (b0)
                    {
                        case 0:
                            packetWrapper.passthrough(Type.INT);
                            packetWrapper.read(Type.REMAINING_BYTES);
                            break;

                        case 1:
                            byte[] abyte = (byte[])packetWrapper.read(Type.REMAINING_BYTES);
                            String s2 = new String(abyte, StandardCharsets.UTF_8);
                            packetWrapper.write(Type.STRING, s2);
                            Windows windows = (Windows)packetWrapper.user().get(Windows.class);
                            PacketWrapper packetwrapper = PacketWrapper.create(49, (ByteBuf)null, packetWrapper.user());
                            packetwrapper.write(Type.UNSIGNED_BYTE, Short.valueOf(windows.anvilId));
                            packetwrapper.write(Type.SHORT, Short.valueOf((short)0));
                            packetwrapper.write(Type.SHORT, Short.valueOf(windows.levelCost));
                            PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
                            break;

                        case 2:
                        case 3:
                            Item item = (Item)packetWrapper.read(Types1_7_6_10.COMPRESSED_NBT_ITEM);
                            CompoundTag compoundtag = item.tag();

                            if (compoundtag != null && compoundtag.contains("pages"))
                            {
                                ListTag listtag = (ListTag)compoundtag.get("pages");

                                for (int i = 0; i < listtag.size(); ++i)
                                {
                                    StringTag stringtag = (StringTag)listtag.get(i);
                                    String s1 = stringtag.getValue();
                                    s1 = ChatUtil.legacyToJson(s1);
                                    stringtag.setValue(s1);
                                }
                            }

                            packetWrapper.write(Type.ITEM, item);
                            break;

                        case 4:
                            packetWrapper.write(Type.STRING, new String((byte[])packetWrapper.read(Type.REMAINING_BYTES), StandardCharsets.UTF_8));
                    }
                });
            }
        });
    }
}

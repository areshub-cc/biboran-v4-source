package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.packets;

import com.viaversion.viaversion.api.minecraft.Position;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.types.version.Types1_8;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.entityreplacements.ArmorStandReplacement;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.entityreplacements.EndermiteReplacement;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.entityreplacements.GuardianReplacement;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.items.ReplacementRegistry1_7_6_10to1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.metadata.MetadataRewriter;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.EntityTracker;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.GameProfileStorage;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.Types1_7_6_10;
import de.gerrygames.viarewind.replacement.Replacement;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.List;
import java.util.UUID;

public class SpawnPackets
{
    public static void register(Protocol1_7_6_10TO1_8 protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_8.SPAWN_PLAYER, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.handler((packetWrapper) ->
                {
                    UUID uuid = (UUID)packetWrapper.read(Type.UUID);
                    packetWrapper.write(Type.STRING, uuid.toString());
                    GameProfileStorage gameprofilestorage = (GameProfileStorage)packetWrapper.user().get(GameProfileStorage.class);
                    GameProfileStorage.GameProfile gameprofilestorage$gameprofile = gameprofilestorage.get(uuid);

                    if (gameprofilestorage$gameprofile == null)
                    {
                        packetWrapper.write(Type.STRING, "");
                        packetWrapper.write(Type.VAR_INT, Integer.valueOf(0));
                    }
                    else {
                        packetWrapper.write(Type.STRING, gameprofilestorage$gameprofile.name.length() > 16 ? gameprofilestorage$gameprofile.name.substring(0, 16) : gameprofilestorage$gameprofile.name);
                        packetWrapper.write(Type.VAR_INT, Integer.valueOf(gameprofilestorage$gameprofile.properties.size()));

                        for (GameProfileStorage.Property gameprofilestorage$property : gameprofilestorage$gameprofile.properties)
                        {
                            packetWrapper.write(Type.STRING, gameprofilestorage$property.name);
                            packetWrapper.write(Type.STRING, gameprofilestorage$property.value);
                            packetWrapper.write(Type.STRING, gameprofilestorage$property.signature == null ? "" : gameprofilestorage$property.signature);
                        }
                    }

                    if (gameprofilestorage$gameprofile != null && gameprofilestorage$gameprofile.gamemode == 3)
                    {
                        int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                        PacketWrapper packetwrapper = PacketWrapper.create(4, (ByteBuf)null, packetWrapper.user());
                        packetwrapper.write(Type.INT, Integer.valueOf(i));
                        packetwrapper.write(Type.SHORT, Short.valueOf((short)4));
                        packetwrapper.write(Types1_7_6_10.COMPRESSED_NBT_ITEM, gameprofilestorage$gameprofile.getSkull());
                        PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);

                        for (short short1 = 0; short1 < 4; ++short1)
                        {
                            packetwrapper = PacketWrapper.create(4, (ByteBuf)null, packetWrapper.user());
                            packetwrapper.write(Type.INT, Integer.valueOf(i));
                            packetwrapper.write(Type.SHORT, Short.valueOf(short1));
                            packetwrapper.write(Types1_7_6_10.COMPRESSED_NBT_ITEM, (Object)null);
                            PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
                        }
                    }

                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.addPlayer((Integer)packetWrapper.get(Type.VAR_INT, 0), uuid);
                });
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.SHORT);
                this.map(Types1_8.METADATA_LIST, Types1_7_6_10.METADATA_LIST);
                this.handler((packetWrapper) ->
                {
                    List<Metadata> list = (List)packetWrapper.get(Types1_7_6_10.METADATA_LIST, 0);
                    MetadataRewriter.transform(EntityType.PLAYER, list);
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), EntityType.PLAYER);
                    entitytracker.sendMetadataBuffer(i);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.SPAWN_ENTITY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.BYTE);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                    int j = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    int k = ((Integer)packetWrapper.get(Type.INT, 1)).intValue();
                    int l = ((Integer)packetWrapper.get(Type.INT, 2)).intValue();
                    byte b1 = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                    byte b2 = ((Byte)packetWrapper.get(Type.BYTE, 2)).byteValue();

                    if (b0 == 71)
                    {
                        switch (b2)
                        {
                            case -128:
                                l += 32;
                                b2 = 0;
                                break;

                            case -64:
                                j -= 32;
                                b2 = -64;
                                break;

                            case 0:
                                l -= 32;
                                b2 = -128;
                                break;

                            case 64:
                                j += 32;
                                b2 = 64;
                        }
                    }
                    else if (b0 == 78)
                    {
                        packetWrapper.cancel();
                        EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                        ArmorStandReplacement armorstandreplacement = new ArmorStandReplacement(i, packetWrapper.user());
                        armorstandreplacement.setLocation((double)j / 32.0D, (double)k / 32.0D, (double)l / 32.0D);
                        armorstandreplacement.setYawPitch((float)b2 * 360.0F / 256.0F, (float)b1 * 360.0F / 256.0F);
                        armorstandreplacement.setHeadYaw((float)b2 * 360.0F / 256.0F);
                        entitytracker.addEntityReplacement(armorstandreplacement);
                    }
                    else if (b0 == 10)
                    {
                        k += 12;
                    }

                    packetWrapper.set(Type.BYTE, 0, Byte.valueOf(b0));
                    packetWrapper.set(Type.INT, 0, Integer.valueOf(j));
                    packetWrapper.set(Type.INT, 1, Integer.valueOf(k));
                    packetWrapper.set(Type.INT, 2, Integer.valueOf(l));
                    packetWrapper.set(Type.BYTE, 1, Byte.valueOf(b1));
                    packetWrapper.set(Type.BYTE, 2, Byte.valueOf(b2));
                    EntityTracker entitytracker1 = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    EntityType entitytype = Entity1_10Types.getTypeFromId(b0, true);
                    entitytracker1.getClientEntityTypes().put(Integer.valueOf(i), entitytype);
                    entitytracker1.sendMetadataBuffer(i);
                    int i1 = ((Integer)packetWrapper.get(Type.INT, 3)).intValue();

                    if (entitytype != null && entitytype.isOrHasParent(EntityType.FALLING_BLOCK))
                    {
                        int j1 = i1 & 4095;
                        int k1 = i1 >> 12 & 15;
                        Replacement replacement = ReplacementRegistry1_7_6_10to1_8.getReplacement(j1, k1);

                        if (replacement != null)
                        {
                            j1 = replacement.getId();
                            k1 = replacement.replaceData(k1);
                        }

                        packetWrapper.set(Type.INT, 3, Integer.valueOf(i1 = j1 | k1 << 16));
                    }

                    if (i1 > 0)
                    {
                        packetWrapper.passthrough(Type.SHORT);
                        packetWrapper.passthrough(Type.SHORT);
                        packetWrapper.passthrough(Type.SHORT);
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.SPAWN_MOB, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.UNSIGNED_BYTE);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.BYTE);
                this.map(Type.SHORT);
                this.map(Type.SHORT);
                this.map(Type.SHORT);
                this.map(Types1_8.METADATA_LIST, Types1_7_6_10.METADATA_LIST);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    int j = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    int k = ((Integer)packetWrapper.get(Type.INT, 0)).intValue();
                    int l = ((Integer)packetWrapper.get(Type.INT, 1)).intValue();
                    int i1 = ((Integer)packetWrapper.get(Type.INT, 2)).intValue();
                    byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 1)).byteValue();
                    byte b1 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                    byte b2 = ((Byte)packetWrapper.get(Type.BYTE, 2)).byteValue();

                    if (j == 30)
                    {
                        packetWrapper.cancel();
                        EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                        ArmorStandReplacement armorstandreplacement = new ArmorStandReplacement(i, packetWrapper.user());
                        armorstandreplacement.setLocation((double)k / 32.0D, (double)l / 32.0D, (double)i1 / 32.0D);
                        armorstandreplacement.setYawPitch((float)b1 * 360.0F / 256.0F, (float)b0 * 360.0F / 256.0F);
                        armorstandreplacement.setHeadYaw((float)b2 * 360.0F / 256.0F);
                        entitytracker.addEntityReplacement(armorstandreplacement);
                    }
                    else if (j == 68)
                    {
                        packetWrapper.cancel();
                        EntityTracker entitytracker1 = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                        GuardianReplacement guardianreplacement = new GuardianReplacement(i, packetWrapper.user());
                        guardianreplacement.setLocation((double)k / 32.0D, (double)l / 32.0D, (double)i1 / 32.0D);
                        guardianreplacement.setYawPitch((float)b1 * 360.0F / 256.0F, (float)b0 * 360.0F / 256.0F);
                        guardianreplacement.setHeadYaw((float)b2 * 360.0F / 256.0F);
                        entitytracker1.addEntityReplacement(guardianreplacement);
                    }
                    else if (j == 67)
                    {
                        packetWrapper.cancel();
                        EntityTracker entitytracker2 = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                        EndermiteReplacement endermitereplacement = new EndermiteReplacement(i, packetWrapper.user());
                        endermitereplacement.setLocation((double)k / 32.0D, (double)l / 32.0D, (double)i1 / 32.0D);
                        endermitereplacement.setYawPitch((float)b1 * 360.0F / 256.0F, (float)b0 * 360.0F / 256.0F);
                        endermitereplacement.setHeadYaw((float)b2 * 360.0F / 256.0F);
                        entitytracker2.addEntityReplacement(endermitereplacement);
                    }
                    else if (j == 101 || j == 255 || j == -1)
                    {
                        packetWrapper.cancel();
                    }
                });
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    int j = ((Short)packetWrapper.get(Type.UNSIGNED_BYTE, 0)).shortValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), Entity1_10Types.getTypeFromId(j, false));
                    entitytracker.sendMetadataBuffer(i);
                });
                this.handler((wrapper) ->
                {
                    List<Metadata> list = (List)wrapper.get(Types1_7_6_10.METADATA_LIST, 0);
                    int i = ((Integer)wrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)wrapper.user().get(EntityTracker.class);

                    if (entitytracker.getEntityReplacement(i) != null)
                    {
                        entitytracker.getEntityReplacement(i).updateMetadata(list);
                    }
                    else if (entitytracker.getClientEntityTypes().containsKey(Integer.valueOf(i)))
                    {
                        MetadataRewriter.transform((EntityType)entitytracker.getClientEntityTypes().get(Integer.valueOf(i)), list);
                    }
                    else {
                        wrapper.cancel();
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.SPAWN_PAINTING, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    Position position = (Position)packetWrapper.read(Type.POSITION);
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getX()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getY()));
                    packetWrapper.write(Type.INT, Integer.valueOf(position.getZ()));
                });
                this.map(Type.UNSIGNED_BYTE, Type.INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), EntityType.PAINTING);
                    entitytracker.sendMetadataBuffer(i);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.SPAWN_EXPERIENCE_ORB, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.SHORT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), EntityType.EXPERIENCE_ORB);
                    entitytracker.sendMetadataBuffer(i);
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.SPAWN_GLOBAL_ENTITY, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.VAR_INT);
                this.map(Type.BYTE);
                this.map(Type.INT);
                this.map(Type.INT);
                this.map(Type.INT);
                this.handler((packetWrapper) ->
                {
                    int i = ((Integer)packetWrapper.get(Type.VAR_INT, 0)).intValue();
                    EntityTracker entitytracker = (EntityTracker)packetWrapper.user().get(EntityTracker.class);
                    entitytracker.getClientEntityTypes().put(Integer.valueOf(i), EntityType.LIGHTNING);
                    entitytracker.sendMetadataBuffer(i);
                });
            }
        });
    }
}

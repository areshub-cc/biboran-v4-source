package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.packets;

import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.protocol.remapper.PacketHandler;
import com.viaversion.viaversion.api.protocol.remapper.PacketRemapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.protocols.protocol1_8.ClientboundPackets1_8;
import com.viaversion.viaversion.util.ChatColorUtil;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.Scoreboard;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ScoreboardPackets
{
    public static void register(Protocol1_7_6_10TO1_8 protocol)
    {
        protocol.registerClientbound(ClientboundPackets1_8.SCOREBOARD_OBJECTIVE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.passthrough(Type.STRING);

                    if (s.length() > 16)
                    {
                        packetWrapper.set(Type.STRING, 0, s = s.substring(0, 16));
                    }

                    byte b0 = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();
                    Scoreboard scoreboard = (Scoreboard)packetWrapper.user().get(Scoreboard.class);

                    if (b0 == 0)
                    {
                        if (scoreboard.objectiveExists(s))
                        {
                            packetWrapper.cancel();
                            return;
                        }

                        scoreboard.addObjective(s);
                    }
                    else if (b0 == 1)
                    {
                        if (!scoreboard.objectiveExists(s))
                        {
                            packetWrapper.cancel();
                            return;
                        }

                        if (scoreboard.getColorIndependentSidebar() != null)
                        {
                            String s1 = packetWrapper.user().getProtocolInfo().getUsername();
                            Optional<Byte> optional = scoreboard.getPlayerTeamColor(s1);

                            if (optional.isPresent())
                            {
                                String s2 = (String)scoreboard.getColorDependentSidebar().get(optional.get());

                                if (s.equals(s2))
                                {
                                    PacketWrapper packetwrapper = PacketWrapper.create(61, (ByteBuf)null, packetWrapper.user());
                                    packetwrapper.write(Type.BYTE, Byte.valueOf((byte)1));
                                    packetwrapper.write(Type.STRING, scoreboard.getColorIndependentSidebar());
                                    PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
                                }
                            }
                        }

                        scoreboard.removeObjective(s);
                    }
                    else if (b0 == 2 && !scoreboard.objectiveExists(s))
                    {
                        packetWrapper.cancel();
                        return;
                    }

                    if (b0 != 0 && b0 != 2)
                    {
                        packetWrapper.write(Type.STRING, "");
                    }
                    else {
                        String s3 = (String)packetWrapper.passthrough(Type.STRING);

                        if (s3.length() > 32)
                        {
                            packetWrapper.set(Type.STRING, 1, s3.substring(0, 32));
                        }

                        packetWrapper.read(Type.STRING);
                    }

                    packetWrapper.write(Type.BYTE, Byte.valueOf(b0));
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.UPDATE_SCORE, new PacketRemapper()
        {
            public void registerMap()
            {
                this.handler((packetWrapper) ->
                {
                    Scoreboard scoreboard = (Scoreboard)packetWrapper.user().get(Scoreboard.class);
                    String s = (String)packetWrapper.passthrough(Type.STRING);
                    byte b0 = ((Byte)packetWrapper.passthrough(Type.BYTE)).byteValue();

                    if (b0 == 1)
                    {
                        s = scoreboard.removeTeamForScore(s);
                    }
                    else {
                        s = scoreboard.sendTeamForScore(s);
                    }

                    if (s.length() > 16)
                    {
                        s = ChatColorUtil.stripColor(s);

                        if (s.length() > 16)
                        {
                            s = s.substring(0, 16);
                        }
                    }

                    packetWrapper.set(Type.STRING, 0, s);
                    String s1 = (String)packetWrapper.read(Type.STRING);

                    if (s1.length() > 16)
                    {
                        s1 = s1.substring(0, 16);
                    }

                    if (b0 != 1)
                    {
                        int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
                        packetWrapper.write(Type.STRING, s1);
                        packetWrapper.write(Type.INT, Integer.valueOf(i));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.DISPLAY_SCOREBOARD, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.BYTE);
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    byte b0 = ((Byte)packetWrapper.get(Type.BYTE, 0)).byteValue();
                    String s = (String)packetWrapper.get(Type.STRING, 0);
                    Scoreboard scoreboard = (Scoreboard)packetWrapper.user().get(Scoreboard.class);

                    if (b0 > 2)
                    {
                        byte b1 = (byte)(b0 - 3);
                        scoreboard.getColorDependentSidebar().put(Byte.valueOf(b1), s);
                        String s1 = packetWrapper.user().getProtocolInfo().getUsername();
                        Optional<Byte> optional = scoreboard.getPlayerTeamColor(s1);

                        if (optional.isPresent() && ((Byte)optional.get()).byteValue() == b1)
                        {
                            b0 = 1;
                        }
                        else
                        {
                            b0 = -1;
                        }
                    }
                    else if (b0 == 1)
                    {
                        scoreboard.setColorIndependentSidebar(s);
                        String s2 = packetWrapper.user().getProtocolInfo().getUsername();
                        Optional<Byte> optional1 = scoreboard.getPlayerTeamColor(s2);

                        if (optional1.isPresent() && scoreboard.getColorDependentSidebar().containsKey(optional1.get()))
                        {
                            b0 = -1;
                        }
                    }

                    if (b0 == -1)
                    {
                        packetWrapper.cancel();
                    }
                    else {
                        packetWrapper.set(Type.BYTE, 0, Byte.valueOf(b0));
                    }
                });
            }
        });
        protocol.registerClientbound(ClientboundPackets1_8.TEAMS, new PacketRemapper()
        {
            public void registerMap()
            {
                this.map(Type.STRING);
                this.handler((packetWrapper) ->
                {
                    String s = (String)packetWrapper.get(Type.STRING, 0);

                    if (s == null)
                    {
                        packetWrapper.cancel();
                    }
                    else {
                        byte b0 = ((Byte)packetWrapper.passthrough(Type.BYTE)).byteValue();
                        Scoreboard scoreboard = (Scoreboard)packetWrapper.user().get(Scoreboard.class);

                        if (b0 != 0 && !scoreboard.teamExists(s))
                        {
                            packetWrapper.cancel();
                        }
                        else {
                            if (b0 == 0 && scoreboard.teamExists(s))
                            {
                                scoreboard.removeTeam(s);
                                PacketWrapper packetwrapper = PacketWrapper.create(62, (ByteBuf)null, packetWrapper.user());
                                packetwrapper.write(Type.STRING, s);
                                packetwrapper.write(Type.BYTE, Byte.valueOf((byte)1));
                                PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
                            }

                            if (b0 == 0)
                            {
                                scoreboard.addTeam(s);
                            }
                            else if (b0 == 1)
                            {
                                scoreboard.removeTeam(s);
                            }

                            if (b0 == 0 || b0 == 2)
                            {
                                packetWrapper.passthrough(Type.STRING);
                                packetWrapper.passthrough(Type.STRING);
                                packetWrapper.passthrough(Type.STRING);
                                packetWrapper.passthrough(Type.BYTE);
                                packetWrapper.read(Type.STRING);
                                byte b1 = ((Byte)packetWrapper.read(Type.BYTE)).byteValue();

                                if (b0 == 2 && ((Byte)scoreboard.getTeamColor(s).get()).byteValue() != b1)
                                {
                                    String s1 = packetWrapper.user().getProtocolInfo().getUsername();
                                    String s2 = (String)scoreboard.getColorDependentSidebar().get(Byte.valueOf(b1));
                                    PacketWrapper packetwrapper1 = packetWrapper.create(61);
                                    packetwrapper1.write(Type.BYTE, Byte.valueOf((byte)1));
                                    packetwrapper1.write(Type.STRING, s2 == null ? "" : s2);
                                    PacketUtil.sendPacket(packetwrapper1, Protocol1_7_6_10TO1_8.class);
                                }

                                scoreboard.setTeamColor(s, Byte.valueOf(b1));
                            }

                            if (b0 == 0 || b0 == 3 || b0 == 4)
                            {
                                byte b2 = ((Byte)scoreboard.getTeamColor(s).get()).byteValue();
                                String[] astring = (String[])packetWrapper.read(Type.STRING_ARRAY);
                                List<String> list = new ArrayList<String>();

                                for (int i = 0; i < astring.length; ++i)
                                {
                                    String s3 = astring[i];
                                    String s4 = packetWrapper.user().getProtocolInfo().getUsername();

                                    if (b0 == 4)
                                    {
                                        if (!scoreboard.isPlayerInTeam(s3, s))
                                        {
                                            continue;
                                        }

                                        scoreboard.removePlayerFromTeam(s3, s);

                                        if (s3.equals(s4))
                                        {
                                            PacketWrapper packetwrapper2 = packetWrapper.create(61);
                                            packetwrapper2.write(Type.BYTE, Byte.valueOf((byte)1));
                                            packetwrapper2.write(Type.STRING, scoreboard.getColorIndependentSidebar() == null ? "" : scoreboard.getColorIndependentSidebar());
                                            PacketUtil.sendPacket(packetwrapper2, Protocol1_7_6_10TO1_8.class);
                                        }
                                    }
                                    else
                                    {
                                        scoreboard.addPlayerToTeam(s3, s);

                                        if (s3.equals(s4) && scoreboard.getColorDependentSidebar().containsKey(Byte.valueOf(b2)))
                                        {
                                            PacketWrapper packetwrapper3 = packetWrapper.create(61);
                                            packetwrapper3.write(Type.BYTE, Byte.valueOf((byte)1));
                                            packetwrapper3.write(Type.STRING, (String)scoreboard.getColorDependentSidebar().get(Byte.valueOf(b2)));
                                            PacketUtil.sendPacket(packetwrapper3, Protocol1_7_6_10TO1_8.class);
                                        }
                                    }

                                    list.add(s3);
                                }

                                packetWrapper.write(Type.SHORT, Short.valueOf((short)list.size()));

                                for (String s5 : list)
                                {
                                    packetWrapper.write(Type.STRING, s5);
                                }
                            }
                        }
                    }
                });
            }
        });
    }
}

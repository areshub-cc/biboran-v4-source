package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.function.Function;

public class Scoreboard extends StoredObject
{
    private HashMap<String, List<String>> teams = new HashMap<String, List<String>>();
    private HashSet<String> objectives = new HashSet<String>();
    private HashMap<String, Scoreboard.ScoreTeam> scoreTeams = new HashMap<String, Scoreboard.ScoreTeam>();
    private HashMap<String, Byte> teamColors = new HashMap<String, Byte>();
    private HashSet<String> scoreTeamNames = new HashSet<String>();
    private String colorIndependentSidebar;
    private HashMap<Byte, String> colorDependentSidebar = new HashMap<Byte, String>();

    public Scoreboard(UserConnection user)
    {
        super(user);
    }

    public void addPlayerToTeam(String player, String team)
    {
        (this.teams.computeIfAbsent(team, (key) ->
        {
            return new ArrayList();
        })).add(player);
    }

    public void setTeamColor(String team, Byte color)
    {
        this.teamColors.put(team, color);
    }

    public Optional<Byte> getTeamColor(String team)
    {
        return Optional.<Byte>ofNullable(this.teamColors.get(team));
    }

    public void addTeam(String team)
    {
        this.teams.computeIfAbsent(team, (key) ->
        {
            return new ArrayList();
        });
    }

    public void removeTeam(String team)
    {
        this.teams.remove(team);
        this.scoreTeams.remove(team);
        this.teamColors.remove(team);
    }

    public boolean teamExists(String team)
    {
        return this.teams.containsKey(team);
    }

    public void removePlayerFromTeam(String player, String team)
    {
        List<String> list = (List)this.teams.get(team);

        if (list != null)
        {
            list.remove(player);
        }
    }

    public boolean isPlayerInTeam(String player, String team)
    {
        List<String> list = (List)this.teams.get(team);
        return list != null && list.contains(player);
    }

    public boolean isPlayerInTeam(String player)
    {
        for (List<String> list : this.teams.values())
        {
            if (list.contains(player))
            {
                return true;
            }
        }

        return false;
    }

    public Optional<Byte> getPlayerTeamColor(String player)
    {
        Optional<String> optional = this.getTeam(player);
        return optional.isPresent() ? this.getTeamColor(optional.get()) : Optional.empty();
    }

    public Optional<String> getTeam(String player)
    {
        for (Entry<String, List<String>> entry : this.teams.entrySet())
        {
            if (((List)entry.getValue()).contains(player))
            {
                return Optional.<String>of(entry.getKey());
            }
        }

        return Optional.<String>empty();
    }

    public void addObjective(String name)
    {
        this.objectives.add(name);
    }

    public void removeObjective(String name)
    {
        this.objectives.remove(name);
        this.colorDependentSidebar.values().remove(name);

        if (name.equals(this.colorIndependentSidebar))
        {
            this.colorIndependentSidebar = null;
        }
    }

    public boolean objectiveExists(String name)
    {
        return this.objectives.contains(name);
    }

    public String sendTeamForScore(String score)
    {
        if (score.length() <= 16)
        {
            return score;
        }
        else if (this.scoreTeams.containsKey(score))
        {
            return (this.scoreTeams.get(score)).name;
        }
        else
        {
            int i = 16;
            int j = Math.min(16, score.length() - 16);
            String s;

            for (s = score.substring(j, j + i); this.scoreTeamNames.contains(s) || this.teams.containsKey(s); s = score.substring(j, j + i))
            {
                --j;

                while (score.length() - i - j > 16)
                {
                    --i;

                    if (i < 1)
                    {
                        return score;
                    }

                    j = Math.min(16, score.length() - i);
                }
            }

            String s1 = score.substring(0, j);
            String s2 = j + i >= score.length() ? "" : score.substring(j + i, score.length());
            Scoreboard.ScoreTeam scoreboard$scoreteam = new Scoreboard.ScoreTeam(s, s1, s2);
            this.scoreTeams.put(score, scoreboard$scoreteam);
            this.scoreTeamNames.add(s);
            PacketWrapper packetwrapper = PacketWrapper.create(62, (ByteBuf)null, this.getUser());
            packetwrapper.write(Type.STRING, s);
            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper.write(Type.STRING, "ViaRewind");
            packetwrapper.write(Type.STRING, s1);
            packetwrapper.write(Type.STRING, s2);
            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper.write(Type.SHORT, Short.valueOf((short)1));
            packetwrapper.write(Type.STRING, s);
            PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
            return s;
        }
    }

    public String removeTeamForScore(String score)
    {
        Scoreboard.ScoreTeam scoreboard$scoreteam = this.scoreTeams.remove(score);

        if (scoreboard$scoreteam == null)
        {
            return score;
        }
        else
        {
            this.scoreTeamNames.remove(scoreboard$scoreteam.name);
            PacketWrapper packetwrapper = PacketWrapper.create(62, (ByteBuf)null, this.getUser());
            packetwrapper.write(Type.STRING, scoreboard$scoreteam.name);
            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)1));
            PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
            return scoreboard$scoreteam.name;
        }
    }

    public String getColorIndependentSidebar()
    {
        return this.colorIndependentSidebar;
    }

    public HashMap<Byte, String> getColorDependentSidebar()
    {
        return this.colorDependentSidebar;
    }

    public void setColorIndependentSidebar(String colorIndependentSidebar)
    {
        this.colorIndependentSidebar = colorIndependentSidebar;
    }

    private class ScoreTeam
    {
        private String prefix;
        private String suffix;
        private String name;

        public ScoreTeam(String name, String prefix, String suffix)
        {
            this.prefix = prefix;
            this.suffix = suffix;
            this.name = name;
        }
    }
}

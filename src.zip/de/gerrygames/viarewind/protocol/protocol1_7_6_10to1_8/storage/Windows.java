package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;
import java.util.HashMap;

public class Windows extends StoredObject
{
    public HashMap<Short, Short> types = new HashMap<Short, Short>();
    public HashMap<Short, Windows.Furnace> furnace = new HashMap<Short, Windows.Furnace>();
    public short levelCost = 0;
    public short anvilId = -1;

    public Windows(UserConnection user)
    {
        super(user);
    }

    public short get(short windowId)
    {
        return ((Short)this.types.getOrDefault(Short.valueOf(windowId), Short.valueOf((short) - 1))).shortValue();
    }

    public void remove(short windowId)
    {
        this.types.remove(Short.valueOf(windowId));
        this.furnace.remove(Short.valueOf(windowId));
    }

    public static int getInventoryType(String name)
    {
        byte b0 = -1;

        switch (name.hashCode())
        {
            case -1879003021:
                if (name.equals("minecraft:villager"))
                {
                    b0 = 7;
                }

                break;

            case -1719356277:
                if (name.equals("minecraft:furnace"))
                {
                    b0 = 3;
                }

                break;

            case -1366784614:
                if (name.equals("EntityHorse"))
                {
                    b0 = 12;
                }

                break;

            case -1293651279:
                if (name.equals("minecraft:beacon"))
                {
                    b0 = 8;
                }

                break;

            case -1150744385:
                if (name.equals("minecraft:anvil"))
                {
                    b0 = 9;
                }

                break;

            case -1149092108:
                if (name.equals("minecraft:chest"))
                {
                    b0 = 1;
                }

                break;

            case -1124126594:
                if (name.equals("minecraft:crafting_table"))
                {
                    b0 = 2;
                }

                break;

            case -1112182111:
                if (name.equals("minecraft:hopper"))
                {
                    b0 = 10;
                }

                break;

            case 319164197:
                if (name.equals("minecraft:enchanting_table"))
                {
                    b0 = 5;
                }

                break;

            case 712019713:
                if (name.equals("minecraft:dropper"))
                {
                    b0 = 11;
                }

                break;

            case 1438413556:
                if (name.equals("minecraft:container"))
                {
                    b0 = 0;
                }

                break;

            case 1649065834:
                if (name.equals("minecraft:brewing_stand"))
                {
                    b0 = 6;
                }

                break;

            case 2090881320:
                if (name.equals("minecraft:dispenser"))
                {
                    b0 = 4;
                }
        }

        switch (b0)
        {
            case 0:
                return 0;

            case 1:
                return 0;

            case 2:
                return 1;

            case 3:
                return 2;

            case 4:
                return 3;

            case 5:
                return 4;

            case 6:
                return 5;

            case 7:
                return 6;

            case 8:
                return 7;

            case 9:
                return 8;

            case 10:
                return 9;

            case 11:
                return 10;

            case 12:
                return 11;

            default:
                throw new IllegalArgumentException("Unknown type " + name);
        }
    }

    public static class Furnace
    {
        private short fuelLeft = 0;
        private short maxFuel = 0;
        private short progress = 0;
        private short maxProgress = 200;

        public short getFuelLeft()
        {
            return this.fuelLeft;
        }

        public short getMaxFuel()
        {
            return this.maxFuel;
        }

        public short getProgress()
        {
            return this.progress;
        }

        public short getMaxProgress()
        {
            return this.maxProgress;
        }

        public void setFuelLeft(short fuelLeft)
        {
            this.fuelLeft = fuelLeft;
        }

        public void setMaxFuel(short maxFuel)
        {
            this.maxFuel = maxFuel;
        }

        public void setProgress(short progress)
        {
            this.progress = progress;
        }

        public void setMaxProgress(short maxProgress)
        {
            this.maxProgress = maxProgress;
        }

        public boolean equals(Object o)
        {
            if (o == this)
            {
                return true;
            }
            else if (!(o instanceof Windows.Furnace))
            {
                return false;
            }
            else
            {
                Windows.Furnace windows$furnace = (Windows.Furnace)o;

                if (!windows$furnace.canEqual(this))
                {
                    return false;
                }
                else if (this.getFuelLeft() != windows$furnace.getFuelLeft())
                {
                    return false;
                }
                else if (this.getMaxFuel() != windows$furnace.getMaxFuel())
                {
                    return false;
                }
                else if (this.getProgress() != windows$furnace.getProgress())
                {
                    return false;
                }
                else
                {
                    return this.getMaxProgress() == windows$furnace.getMaxProgress();
                }
            }
        }

        protected boolean canEqual(Object other)
        {
            return other instanceof Windows.Furnace;
        }

        public int hashCode()
        {
            int i = 59;
            int j = 1;
            j = j * 59 + this.getFuelLeft();
            j = j * 59 + this.getMaxFuel();
            j = j * 59 + this.getProgress();
            j = j * 59 + this.getMaxProgress();
            return j;
        }

        public String toString()
        {
            return "Windows.Furnace(fuelLeft=" + this.getFuelLeft() + ", maxFuel=" + this.getMaxFuel() + ", progress=" + this.getProgress() + ", maxProgress=" + this.getMaxProgress() + ")";
        }
    }
}

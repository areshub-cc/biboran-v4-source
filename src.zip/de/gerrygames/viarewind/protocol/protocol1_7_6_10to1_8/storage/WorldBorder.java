package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.utils.PacketUtil;
import de.gerrygames.viarewind.utils.Tickable;
import io.netty.buffer.ByteBuf;

public class WorldBorder extends StoredObject implements Tickable
{
    private double x;
    private double z;
    private double oldDiameter;
    private double newDiameter;
    private long lerpTime;
    private long lerpStartTime;
    private int portalTeleportBoundary;
    private int warningTime;
    private int warningBlocks;
    private boolean init = false;
    private final int VIEW_DISTANCE = 16;

    public WorldBorder(UserConnection user)
    {
        super(user);
    }

    public void tick()
    {
        if (this.isInit())
        {
            this.sendPackets();
        }
    }

    private void sendPackets()
    {
        PlayerPosition playerposition = (PlayerPosition)this.getUser().get(PlayerPosition.class);
        double d0 = this.getSize() / 2.0D;

        for (WorldBorder.Side worldborder$side : WorldBorder.Side.values())
        {
            double d1;
            double d2;
            double d3;

            if (worldborder$side.modX != 0)
            {
                d2 = playerposition.getPosZ();
                d3 = this.z;
                d1 = Math.abs(this.x + d0 * (double)worldborder$side.modX - playerposition.getPosX());
            }
            else
            {
                d3 = this.x;
                d2 = playerposition.getPosX();
                d1 = Math.abs(this.z + d0 * (double)worldborder$side.modZ - playerposition.getPosZ());
            }

            if (d1 < 16.0D)
            {
                double d4 = Math.sqrt(256.0D - d1 * d1);
                double d5 = Math.ceil(d2 - d4);
                double d6 = Math.floor(d2 + d4);
                double d7 = Math.ceil(playerposition.getPosY() - d4);
                double d8 = Math.floor(playerposition.getPosY() + d4);

                if (d5 < d3 - d0)
                {
                    d5 = Math.ceil(d3 - d0);
                }

                if (d6 > d3 + d0)
                {
                    d6 = Math.floor(d3 + d0);
                }

                if (d7 < 0.0D)
                {
                    d7 = 0.0D;
                }

                double d9 = (d5 + d6) / 2.0D;
                double d10 = (d7 + d8) / 2.0D;
                int i = (int)Math.floor((d6 - d5) * (d8 - d7) * 0.5D);
                double d11 = 2.5D;
                PacketWrapper packetwrapper = PacketWrapper.create(42, (ByteBuf)null, this.getUser());
                packetwrapper.write(Type.STRING, "fireworksSpark");
                packetwrapper.write(Type.FLOAT, Float.valueOf((float)(worldborder$side.modX != 0 ? this.x + d0 * (double)worldborder$side.modX : d9)));
                packetwrapper.write(Type.FLOAT, Float.valueOf((float)d10));
                packetwrapper.write(Type.FLOAT, Float.valueOf((float)(worldborder$side.modX == 0 ? this.z + d0 * (double)worldborder$side.modZ : d9)));
                packetwrapper.write(Type.FLOAT, Float.valueOf((float)(worldborder$side.modX != 0 ? 0.0D : (d6 - d5) / d11)));
                packetwrapper.write(Type.FLOAT, Float.valueOf((float)((d8 - d7) / d11)));
                packetwrapper.write(Type.FLOAT, Float.valueOf((float)(worldborder$side.modX == 0 ? 0.0D : (d6 - d5) / d11)));
                packetwrapper.write(Type.FLOAT, Float.valueOf(0.0F));
                packetwrapper.write(Type.INT, Integer.valueOf(i));
                PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
            }
        }
    }

    private boolean isInit()
    {
        return this.init;
    }

    public void init(double x, double z, double oldDiameter, double newDiameter, long lerpTime, int portalTeleportBoundary, int warningTime, int warningBlocks)
    {
        this.x = x;
        this.z = z;
        this.oldDiameter = oldDiameter;
        this.newDiameter = newDiameter;
        this.lerpTime = lerpTime;
        this.portalTeleportBoundary = portalTeleportBoundary;
        this.warningTime = warningTime;
        this.warningBlocks = warningBlocks;
        this.init = true;
    }

    public double getX()
    {
        return this.x;
    }

    public double getZ()
    {
        return this.z;
    }

    public void setCenter(double x, double z)
    {
        this.x = x;
        this.z = z;
    }

    public double getOldDiameter()
    {
        return this.oldDiameter;
    }

    public double getNewDiameter()
    {
        return this.newDiameter;
    }

    public long getLerpTime()
    {
        return this.lerpTime;
    }

    public void lerpSize(double oldDiameter, double newDiameter, long lerpTime)
    {
        this.oldDiameter = oldDiameter;
        this.newDiameter = newDiameter;
        this.lerpTime = lerpTime;
        this.lerpStartTime = System.currentTimeMillis();
    }

    public void setSize(double size)
    {
        this.oldDiameter = size;
        this.newDiameter = size;
        this.lerpTime = 0L;
    }

    public double getSize()
    {
        if (this.lerpTime == 0L)
        {
            return this.newDiameter;
        }
        else
        {
            long i = System.currentTimeMillis() - this.lerpStartTime;
            double d0 = (double)i / (double)this.lerpTime;

            if (d0 > 1.0D)
            {
                d0 = 1.0D;
            }
            else if (d0 < 0.0D)
            {
                d0 = 0.0D;
            }

            return this.oldDiameter + (this.newDiameter - this.oldDiameter) * d0;
        }
    }

    public int getPortalTeleportBoundary()
    {
        return this.portalTeleportBoundary;
    }

    public void setPortalTeleportBoundary(int portalTeleportBoundary)
    {
        this.portalTeleportBoundary = portalTeleportBoundary;
    }

    public int getWarningTime()
    {
        return this.warningTime;
    }

    public void setWarningTime(int warningTime)
    {
        this.warningTime = warningTime;
    }

    public int getWarningBlocks()
    {
        return this.warningBlocks;
    }

    public void setWarningBlocks(int warningBlocks)
    {
        this.warningBlocks = warningBlocks;
    }

    private static enum Side
    {
        NORTH(0, -1),
        EAST(1, 0),
        SOUTH(0, 1),
        WEST(-1, 0);

        private int modX;
        private int modZ;

        private Side(int modX, int modZ)
        {
            this.modX = modX;
            this.modZ = modZ;
        }
    }
}

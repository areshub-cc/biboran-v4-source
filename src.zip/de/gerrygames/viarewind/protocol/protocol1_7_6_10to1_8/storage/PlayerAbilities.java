package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;

public class PlayerAbilities extends StoredObject
{
    private boolean sprinting;
    private boolean allowFly;
    private boolean flying;
    private boolean invincible;
    private boolean creative;
    private float flySpeed;
    private float walkSpeed;

    public PlayerAbilities(UserConnection user)
    {
        super(user);
    }

    public byte getFlags()
    {
        byte b0 = 0;

        if (this.invincible)
        {
            b0 = (byte)(b0 | 8);
        }

        if (this.allowFly)
        {
            b0 = (byte)(b0 | 4);
        }

        if (this.flying)
        {
            b0 = (byte)(b0 | 2);
        }

        if (this.creative)
        {
            b0 = (byte)(b0 | 1);
        }

        return b0;
    }

    public boolean isSprinting()
    {
        return this.sprinting;
    }

    public boolean isAllowFly()
    {
        return this.allowFly;
    }

    public boolean isFlying()
    {
        return this.flying;
    }

    public boolean isInvincible()
    {
        return this.invincible;
    }

    public boolean isCreative()
    {
        return this.creative;
    }

    public float getFlySpeed()
    {
        return this.flySpeed;
    }

    public float getWalkSpeed()
    {
        return this.walkSpeed;
    }

    public void setSprinting(boolean sprinting)
    {
        this.sprinting = sprinting;
    }

    public void setAllowFly(boolean allowFly)
    {
        this.allowFly = allowFly;
    }

    public void setFlying(boolean flying)
    {
        this.flying = flying;
    }

    public void setInvincible(boolean invincible)
    {
        this.invincible = invincible;
    }

    public void setCreative(boolean creative)
    {
        this.creative = creative;
    }

    public void setFlySpeed(float flySpeed)
    {
        this.flySpeed = flySpeed;
    }

    public void setWalkSpeed(float walkSpeed)
    {
        this.walkSpeed = walkSpeed;
    }

    public boolean equals(Object o)
    {
        if (o == this)
        {
            return true;
        }
        else if (!(o instanceof PlayerAbilities))
        {
            return false;
        }
        else
        {
            PlayerAbilities playerabilities = (PlayerAbilities)o;

            if (!playerabilities.canEqual(this))
            {
                return false;
            }
            else if (this.isSprinting() != playerabilities.isSprinting())
            {
                return false;
            }
            else if (this.isAllowFly() != playerabilities.isAllowFly())
            {
                return false;
            }
            else if (this.isFlying() != playerabilities.isFlying())
            {
                return false;
            }
            else if (this.isInvincible() != playerabilities.isInvincible())
            {
                return false;
            }
            else if (this.isCreative() != playerabilities.isCreative())
            {
                return false;
            }
            else if (Float.compare(this.getFlySpeed(), playerabilities.getFlySpeed()) != 0)
            {
                return false;
            }
            else
            {
                return Float.compare(this.getWalkSpeed(), playerabilities.getWalkSpeed()) == 0;
            }
        }
    }

    protected boolean canEqual(Object other)
    {
        return other instanceof PlayerAbilities;
    }

    public int hashCode()
    {
        int i = 59;
        int j = 1;
        j = j * 59 + (this.isSprinting() ? 79 : 97);
        j = j * 59 + (this.isAllowFly() ? 79 : 97);
        j = j * 59 + (this.isFlying() ? 79 : 97);
        j = j * 59 + (this.isInvincible() ? 79 : 97);
        j = j * 59 + (this.isCreative() ? 79 : 97);
        j = j * 59 + Float.floatToIntBits(this.getFlySpeed());
        j = j * 59 + Float.floatToIntBits(this.getWalkSpeed());
        return j;
    }

    public String toString()
    {
        return "PlayerAbilities(sprinting=" + this.isSprinting() + ", allowFly=" + this.isAllowFly() + ", flying=" + this.isFlying() + ", invincible=" + this.isInvincible() + ", creative=" + this.isCreative() + ", flySpeed=" + this.getFlySpeed() + ", walkSpeed=" + this.getWalkSpeed() + ")";
    }
}

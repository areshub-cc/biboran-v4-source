package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.data.entity.ClientEntityIdChangeListener;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.types.version.Types1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.metadata.MetadataRewriter;
import de.gerrygames.viarewind.replacement.EntityReplacement;
import de.gerrygames.viarewind.utils.PacketUtil;
import io.netty.buffer.ByteBuf;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public class EntityTracker extends StoredObject implements ClientEntityIdChangeListener
{
    private final Map<Integer, EntityType> clientEntityTypes = new ConcurrentHashMap<Integer, EntityType>();
    private final Map<Integer, List<Metadata>> metadataBuffer = new ConcurrentHashMap<Integer, List<Metadata>>();
    private final Map<Integer, Integer> vehicles = new ConcurrentHashMap<Integer, Integer>();
    private final Map<Integer, EntityReplacement> entityReplacements = new ConcurrentHashMap<Integer, EntityReplacement>();
    private final Map<Integer, UUID> playersByEntityId = new HashMap<Integer, UUID>();
    private final Map<UUID, Integer> playersByUniqueId = new HashMap<UUID, Integer>();
    private final Map<UUID, Item[]> playerEquipment = new HashMap<UUID, Item[]>();
    private int gamemode = 0;
    private int playerId = -1;
    private int spectating = -1;
    private int dimension = 0;

    public EntityTracker(UserConnection user)
    {
        super(user);
    }

    public void removeEntity(int entityId)
    {
        this.clientEntityTypes.remove(Integer.valueOf(entityId));

        if (this.entityReplacements.containsKey(Integer.valueOf(entityId)))
        {
            ((EntityReplacement)this.entityReplacements.remove(Integer.valueOf(entityId))).despawn();
        }

        if (this.playersByEntityId.containsKey(Integer.valueOf(entityId)))
        {
            this.playersByUniqueId.remove(this.playersByEntityId.remove(Integer.valueOf(entityId)));
        }
    }

    public void addPlayer(Integer entityId, UUID uuid)
    {
        this.playersByUniqueId.put(uuid, entityId);
        this.playersByEntityId.put(entityId, uuid);
    }

    public UUID getPlayerUUID(int entityId)
    {
        return this.playersByEntityId.get(Integer.valueOf(entityId));
    }

    public int getPlayerEntityId(UUID uuid)
    {
        return ((Integer)this.playersByUniqueId.getOrDefault(uuid, Integer.valueOf(-1))).intValue();
    }

    public Item[] getPlayerEquipment(UUID uuid)
    {
        return this.playerEquipment.get(uuid);
    }

    public void setPlayerEquipment(UUID uuid, Item[] equipment)
    {
        this.playerEquipment.put(uuid, equipment);
    }

    public Map<Integer, EntityType> getClientEntityTypes()
    {
        return this.clientEntityTypes;
    }

    public void addMetadataToBuffer(int entityID, List<Metadata> metadataList)
    {
        if (this.metadataBuffer.containsKey(Integer.valueOf(entityID)))
        {
            (this.metadataBuffer.get(Integer.valueOf(entityID))).addAll(metadataList);
        }
        else if (!metadataList.isEmpty())
        {
            this.metadataBuffer.put(Integer.valueOf(entityID), metadataList);
        }
    }

    public void addEntityReplacement(EntityReplacement entityReplacement)
    {
        this.entityReplacements.put(Integer.valueOf(entityReplacement.getEntityId()), entityReplacement);
    }

    public EntityReplacement getEntityReplacement(int entityId)
    {
        return this.entityReplacements.get(Integer.valueOf(entityId));
    }

    public List<Metadata> getBufferedMetadata(int entityId)
    {
        return (List)this.metadataBuffer.get(Integer.valueOf(entityId));
    }

    public void sendMetadataBuffer(int entityId)
    {
        if (this.metadataBuffer.containsKey(Integer.valueOf(entityId)))
        {
            if (this.entityReplacements.containsKey(Integer.valueOf(entityId)))
            {
                (this.entityReplacements.get(Integer.valueOf(entityId))).updateMetadata(this.metadataBuffer.remove(Integer.valueOf(entityId)));
            }
            else
            {
                EntityType entitytype = (EntityType)this.getClientEntityTypes().get(Integer.valueOf(entityId));
                PacketWrapper packetwrapper = PacketWrapper.create(28, (ByteBuf)null, this.getUser());
                packetwrapper.write(Type.VAR_INT, Integer.valueOf(entityId));
                packetwrapper.write(Types1_8.METADATA_LIST, this.metadataBuffer.get(Integer.valueOf(entityId)));
                MetadataRewriter.transform(entitytype, this.metadataBuffer.get(Integer.valueOf(entityId)));

                if (!((List)this.metadataBuffer.get(Integer.valueOf(entityId))).isEmpty())
                {
                    PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
                }

                this.metadataBuffer.remove(Integer.valueOf(entityId));
            }
        }
    }

    public int getVehicle(int passengerId)
    {
        for (Entry<Integer, Integer> entry : this.vehicles.entrySet())
        {
            if (((Integer)entry.getValue()).intValue() == passengerId)
            {
                return ((Integer)entry.getValue()).intValue();
            }
        }

        return -1;
    }

    public int getPassenger(int vehicleId)
    {
        return ((Integer)this.vehicles.getOrDefault(Integer.valueOf(vehicleId), Integer.valueOf(-1))).intValue();
    }

    public void setPassenger(int vehicleId, int passengerId)
    {
        if (vehicleId == this.spectating && this.spectating != this.playerId)
        {
            try
            {
                PacketWrapper packetwrapper = PacketWrapper.create(11, (ByteBuf)null, this.getUser());
                packetwrapper.write(Type.VAR_INT, Integer.valueOf(this.playerId));
                packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
                packetwrapper.write(Type.VAR_INT, Integer.valueOf(0));
                PacketWrapper packetwrapper1 = PacketWrapper.create(11, (ByteBuf)null, this.getUser());
                packetwrapper1.write(Type.VAR_INT, Integer.valueOf(this.playerId));
                packetwrapper1.write(Type.VAR_INT, Integer.valueOf(1));
                packetwrapper1.write(Type.VAR_INT, Integer.valueOf(0));
                PacketUtil.sendToServer(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
                this.setSpectating(this.playerId);
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
        }

        if (vehicleId == -1)
        {
            int i = this.getVehicle(passengerId);
            this.vehicles.remove(Integer.valueOf(i));
        }
        else if (passengerId == -1)
        {
            this.vehicles.remove(Integer.valueOf(vehicleId));
        }
        else
        {
            this.vehicles.put(Integer.valueOf(vehicleId), Integer.valueOf(passengerId));
        }
    }

    public int getSpectating()
    {
        return this.spectating;
    }

    public boolean setSpectating(int spectating)
    {
        if (spectating != this.playerId && this.getPassenger(spectating) != -1)
        {
            PacketWrapper packetwrapper3 = PacketWrapper.create(11, (ByteBuf)null, this.getUser());
            packetwrapper3.write(Type.VAR_INT, Integer.valueOf(this.playerId));
            packetwrapper3.write(Type.VAR_INT, Integer.valueOf(0));
            packetwrapper3.write(Type.VAR_INT, Integer.valueOf(0));
            PacketWrapper packetwrapper1 = PacketWrapper.create(11, (ByteBuf)null, this.getUser());
            packetwrapper1.write(Type.VAR_INT, Integer.valueOf(this.playerId));
            packetwrapper1.write(Type.VAR_INT, Integer.valueOf(1));
            packetwrapper1.write(Type.VAR_INT, Integer.valueOf(0));
            PacketUtil.sendToServer(packetwrapper3, Protocol1_7_6_10TO1_8.class, true, true);
            this.setSpectating(this.playerId);
            return false;
        }
        else
        {
            if (this.spectating != spectating && this.spectating != this.playerId)
            {
                PacketWrapper packetwrapper = PacketWrapper.create(27, (ByteBuf)null, this.getUser());
                packetwrapper.write(Type.INT, Integer.valueOf(this.playerId));
                packetwrapper.write(Type.INT, Integer.valueOf(-1));
                packetwrapper.write(Type.BOOLEAN, Boolean.valueOf(false));
                PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
            }

            this.spectating = spectating;

            if (spectating != this.playerId)
            {
                PacketWrapper packetwrapper2 = PacketWrapper.create(27, (ByteBuf)null, this.getUser());
                packetwrapper2.write(Type.INT, Integer.valueOf(this.playerId));
                packetwrapper2.write(Type.INT, Integer.valueOf(this.spectating));
                packetwrapper2.write(Type.BOOLEAN, Boolean.valueOf(false));
                PacketUtil.sendPacket(packetwrapper2, Protocol1_7_6_10TO1_8.class);
            }

            return true;
        }
    }

    public int getGamemode()
    {
        return this.gamemode;
    }

    public void setGamemode(int gamemode)
    {
        this.gamemode = gamemode;
    }

    public int getPlayerId()
    {
        return this.playerId;
    }

    public void setPlayerId(int playerId)
    {
        this.playerId = this.spectating = playerId;
    }

    public void clearEntities()
    {
        this.clientEntityTypes.clear();
        this.entityReplacements.clear();
        this.vehicles.clear();
        this.metadataBuffer.clear();
    }

    public int getDimension()
    {
        return this.dimension;
    }

    public void setDimension(int dimension)
    {
        this.dimension = dimension;
    }

    public void setClientEntityId(int playerEntityId)
    {
        if (this.spectating == this.playerId)
        {
            this.spectating = playerEntityId;
        }

        this.clientEntityTypes.remove(Integer.valueOf(this.playerId));
        this.playerId = playerEntityId;
        this.clientEntityTypes.put(Integer.valueOf(this.playerId), EntityType.ENTITY_HUMAN);
    }
}

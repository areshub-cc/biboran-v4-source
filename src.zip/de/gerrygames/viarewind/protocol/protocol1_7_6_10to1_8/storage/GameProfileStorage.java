package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage;

import com.viaversion.viaversion.api.connection.StoredObject;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.minecraft.item.DataItem;
import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.CompoundTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.ListTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.StringTag;
import com.viaversion.viaversion.util.ChatColorUtil;
import de.gerrygames.viarewind.utils.ChatUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;

public class GameProfileStorage extends StoredObject
{
    private Map<UUID, GameProfileStorage.GameProfile> properties = new HashMap<UUID, GameProfileStorage.GameProfile>();

    public GameProfileStorage(UserConnection user)
    {
        super(user);
    }

    public GameProfileStorage.GameProfile put(UUID uuid, String name)
    {
        GameProfileStorage.GameProfile gameprofilestorage$gameprofile = new GameProfileStorage.GameProfile(uuid, name);
        this.properties.put(uuid, gameprofilestorage$gameprofile);
        return gameprofilestorage$gameprofile;
    }

    public void putProperty(UUID uuid, GameProfileStorage.Property property)
    {
        (this.properties.computeIfAbsent(uuid, (profile) ->
        {
            return new GameProfileStorage.GameProfile(uuid, (String)null);
        })).properties.add(property);
    }

    public void putProperty(UUID uuid, String name, String value, String signature)
    {
        this.putProperty(uuid, new GameProfileStorage.Property(name, value, signature));
    }

    public GameProfileStorage.GameProfile get(UUID uuid)
    {
        return this.properties.get(uuid);
    }

    public GameProfileStorage.GameProfile get(String name, boolean ignoreCase)
    {
        if (ignoreCase)
        {
            name = name.toLowerCase();
        }

        for (GameProfileStorage.GameProfile gameprofilestorage$gameprofile : this.properties.values())
        {
            if (gameprofilestorage$gameprofile.name != null)
            {
                String s = ignoreCase ? gameprofilestorage$gameprofile.name.toLowerCase() : gameprofilestorage$gameprofile.name;

                if (s.equals(name))
                {
                    return gameprofilestorage$gameprofile;
                }
            }
        }

        return null;
    }

    public List<GameProfileStorage.GameProfile> getAllWithPrefix(String prefix, boolean ignoreCase)
    {
        if (ignoreCase)
        {
            prefix = prefix.toLowerCase();
        }

        ArrayList<GameProfileStorage.GameProfile> arraylist = new ArrayList<GameProfileStorage.GameProfile>();

        for (GameProfileStorage.GameProfile gameprofilestorage$gameprofile : this.properties.values())
        {
            if (gameprofilestorage$gameprofile.name != null)
            {
                String s = ignoreCase ? gameprofilestorage$gameprofile.name.toLowerCase() : gameprofilestorage$gameprofile.name;

                if (s.startsWith(prefix))
                {
                    arraylist.add(gameprofilestorage$gameprofile);
                }
            }
        }

        return arraylist;
    }

    public GameProfileStorage.GameProfile remove(UUID uuid)
    {
        return this.properties.remove(uuid);
    }

    public static class GameProfile
    {
        public String name;
        public String displayName;
        public int ping;
        public UUID uuid;
        public List<GameProfileStorage.Property> properties = new ArrayList<GameProfileStorage.Property>();
        public int gamemode = 0;

        public GameProfile(UUID uuid, String name)
        {
            this.name = name;
            this.uuid = uuid;
        }

        public Item getSkull()
        {
            CompoundTag compoundtag = new CompoundTag();
            CompoundTag compoundtag1 = new CompoundTag();
            compoundtag.put("SkullOwner", compoundtag1);
            compoundtag1.put("Id", new StringTag(this.uuid.toString()));
            CompoundTag compoundtag2 = new CompoundTag();
            compoundtag1.put("Properties", compoundtag2);
            ListTag listtag = new ListTag(CompoundTag.class);
            compoundtag2.put("textures", listtag);

            for (GameProfileStorage.Property gameprofilestorage$property : this.properties)
            {
                if (gameprofilestorage$property.name.equals("textures"))
                {
                    CompoundTag compoundtag3 = new CompoundTag();
                    compoundtag3.put("Value", new StringTag(gameprofilestorage$property.value));

                    if (gameprofilestorage$property.signature != null)
                    {
                        compoundtag3.put("Signature", new StringTag(gameprofilestorage$property.signature));
                    }

                    listtag.add(compoundtag3);
                }
            }

            return new DataItem(397, (byte)1, (short)3, compoundtag);
        }

        public String getDisplayName()
        {
            String s = this.displayName == null ? this.name : this.displayName;

            if (s.length() > 16)
            {
                s = ChatUtil.removeUnusedColor(s, 'f');
            }

            if (s.length() > 16)
            {
                s = ChatColorUtil.stripColor(s);
            }

            if (s.length() > 16)
            {
                s = s.substring(0, 16);
            }

            return s;
        }

        public void setDisplayName(String displayName)
        {
            this.displayName = displayName;
        }
    }

    public static class Property
    {
        public String name;
        public String value;
        public String signature;

        public Property(String name, String value, String signature)
        {
            this.name = name;
            this.value = value;
            this.signature = signature;
        }
    }
}

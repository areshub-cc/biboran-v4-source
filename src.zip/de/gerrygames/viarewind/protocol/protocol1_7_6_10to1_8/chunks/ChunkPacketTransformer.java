package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.chunks;

import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.types.CustomByteType;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.items.ReplacementRegistry1_7_6_10to1_8;
import de.gerrygames.viarewind.replacement.Replacement;
import de.gerrygames.viarewind.storage.BlockState;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import java.util.zip.Deflater;

public class ChunkPacketTransformer
{
    private static byte[] transformChunkData(byte[] data, int primaryBitMask, boolean skyLight, boolean groundUp)
    {
        int i = 0;
        ByteBuf bytebuf = Unpooled.buffer();
        ByteBuf bytebuf1 = Unpooled.buffer();

        for (int j = 0; j < 16; ++j)
        {
            if ((primaryBitMask & 1 << j) != 0)
            {
                byte b0 = 0;

                for (int k = 0; k < 4096; ++k)
                {
                    short short1 = (short)((data[i + 1] & 255) << 8 | data[i] & 255);
                    i += 2;
                    int l = BlockState.extractId(short1);
                    int i1 = BlockState.extractData(short1);
                    Replacement replacement = ReplacementRegistry1_7_6_10to1_8.getReplacement(l, i1);

                    if (replacement != null)
                    {
                        l = replacement.getId();
                        i1 = replacement.replaceData(i1);
                    }

                    bytebuf.writeByte(l);

                    if (k % 2 == 0)
                    {
                        b0 = (byte)(i1 & 15);
                    }
                    else
                    {
                        bytebuf1.writeByte(b0 | (i1 & 15) << 4);
                    }
                }
            }
        }

        bytebuf.writeBytes(bytebuf1);
        bytebuf1.release();
        int j1 = Integer.bitCount(primaryBitMask);
        bytebuf.writeBytes(data, i, 2048 * j1);
        i = i + 2048 * j1;

        if (skyLight)
        {
            bytebuf.writeBytes(data, i, 2048 * j1);
            i += 2048 * j1;
        }

        if (groundUp && i + 256 <= data.length)
        {
            bytebuf.writeBytes(data, i, 256);
            i = i + 256;
        }

        data = new byte[bytebuf.readableBytes()];
        bytebuf.readBytes(data);
        bytebuf.release();
        return data;
    }

    private static int calcSize(int i, boolean flag, boolean flag1)
    {
        int i = i * 2 * 16 * 16 * 16;
        int j = i * 16 * 16 * 16 / 2;
        int k = flag ? i * 16 * 16 * 16 / 2 : 0;
        int l = flag1 ? 256 : 0;
        return i + j + k + l;
    }

    public static void transformChunkBulk(PacketWrapper packetWrapper) throws Exception
    {
        boolean flag = ((Boolean)packetWrapper.read(Type.BOOLEAN)).booleanValue();
        int i = ((Integer)packetWrapper.read(Type.VAR_INT)).intValue();
        int[] aint = new int[i];
        int[] aint1 = new int[i];
        int[] aint2 = new int[i];
        byte[][] abyte = new byte[i][];

        for (int j = 0; j < i; ++j)
        {
            aint[j] = ((Integer)packetWrapper.read(Type.INT)).intValue();
            aint1[j] = ((Integer)packetWrapper.read(Type.INT)).intValue();
            aint2[j] = ((Integer)packetWrapper.read(Type.UNSIGNED_SHORT)).intValue();
        }

        int k1 = 0;

        for (int k = 0; k < i; ++k)
        {
            int l = calcSize(Integer.bitCount(aint2[k]), flag, true);
            CustomByteType custombytetype = new CustomByteType(l);
            abyte[k] = transformChunkData((byte[])packetWrapper.read(custombytetype), aint2[k], flag, true);
            k1 += abyte[k].length;
        }

        packetWrapper.write(Type.SHORT, Short.valueOf((short)i));
        byte[] abyte3 = new byte[k1];
        int l1 = 0;

        for (int i2 = 0; i2 < i; ++i2)
        {
            System.arraycopy(abyte[i2], 0, abyte3, l1, abyte[i2].length);
            l1 += abyte[i2].length;
        }

        Deflater deflater = new Deflater(4);
        deflater.reset();
        deflater.setInput(abyte3);
        deflater.finish();
        byte[] abyte1 = new byte[abyte3.length + 100];
        int i1 = deflater.deflate(abyte1);
        byte[] abyte2 = new byte[i1];
        System.arraycopy(abyte1, 0, abyte2, 0, i1);
        packetWrapper.write(Type.INT, Integer.valueOf(i1));
        packetWrapper.write(Type.BOOLEAN, Boolean.valueOf(flag));
        CustomByteType custombytetype1 = new CustomByteType(i1);
        packetWrapper.write(custombytetype1, abyte2);

        for (int j1 = 0; j1 < i; ++j1)
        {
            packetWrapper.write(Type.INT, Integer.valueOf(aint[j1]));
            packetWrapper.write(Type.INT, Integer.valueOf(aint1[j1]));
            packetWrapper.write(Type.SHORT, Short.valueOf((short)aint2[j1]));
            packetWrapper.write(Type.SHORT, Short.valueOf((short)0));
        }
    }
}

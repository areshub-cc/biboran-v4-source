package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.items;

import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.ByteTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.CompoundTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.ListTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.NumberTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.ShortTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.StringTag;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.Tag;
import de.gerrygames.viarewind.utils.ChatUtil;
import de.gerrygames.viarewind.utils.Enchantments;
import java.util.ArrayList;
import java.util.List;

public class ItemRewriter
{
    public static Item toClient(Item item)
    {
        if (item == null)
        {
            return null;
        }
        else
        {
            CompoundTag compoundtag = item.tag();

            if (compoundtag == null)
            {
                item.setTag(compoundtag = new CompoundTag());
            }

            CompoundTag compoundtag1 = new CompoundTag();
            compoundtag.put("ViaRewind1_7_6_10to1_8", compoundtag1);
            compoundtag1.put("id", new ShortTag((short)item.identifier()));
            compoundtag1.put("data", new ShortTag(item.data()));
            CompoundTag compoundtag2 = (CompoundTag)compoundtag.get("display");

            if (compoundtag2 != null && compoundtag2.contains("Name"))
            {
                compoundtag1.put("displayName", new StringTag((String)compoundtag2.get("Name").getValue()));
            }

            if (compoundtag2 != null && compoundtag2.contains("Lore"))
            {
                compoundtag1.put("lore", new ListTag(((ListTag)compoundtag2.get("Lore")).getValue()));
            }

            if (compoundtag.contains("ench") || compoundtag.contains("StoredEnchantments"))
            {
                ListTag listtag = compoundtag.contains("ench") ? (ListTag)compoundtag.get("ench") : (ListTag)compoundtag.get("StoredEnchantments");
                List<Tag> list = new ArrayList<Tag>();

                for (Tag tag : new ArrayList(listtag.getValue()))
                {
                    short short1 = ((NumberTag)((CompoundTag)tag).get("id")).asShort();
                    short short2 = ((NumberTag)((CompoundTag)tag).get("lvl")).asShort();

                    if (short1 == 8)
                    {
                        String s = "\u00a7r\u00a77Depth Strider ";
                        listtag.remove(tag);
                        s = s + (String)Enchantments.ENCHANTMENTS.getOrDefault(Short.valueOf(short2), "enchantment.level." + short2);
                        list.add(new StringTag(s));
                    }
                }

                if (!list.isEmpty())
                {
                    if (compoundtag2 == null)
                    {
                        compoundtag.put("display", compoundtag2 = new CompoundTag());
                        compoundtag1.put("noDisplay", new ByteTag());
                    }

                    ListTag listtag3 = (ListTag)compoundtag2.get("Lore");

                    if (listtag3 == null)
                    {
                        compoundtag2.put("Lore", listtag3 = new ListTag(StringTag.class));
                    }

                    list.addAll(listtag3.getValue());
                    listtag3.setValue(list);
                }
            }

            if (item.identifier() == 387 && compoundtag.contains("pages"))
            {
                ListTag listtag1 = (ListTag)compoundtag.get("pages");
                ListTag listtag2 = new ListTag(StringTag.class);
                compoundtag1.put("pages", listtag2);

                for (int i = 0; i < listtag1.size(); ++i)
                {
                    StringTag stringtag = (StringTag)listtag1.get(i);
                    String s1 = stringtag.getValue();
                    listtag2.add(new StringTag(s1));
                    s1 = ChatUtil.jsonToLegacy(s1);
                    stringtag.setValue(s1);
                }
            }

            ReplacementRegistry1_7_6_10to1_8.replace(item);

            if (compoundtag1.size() == 2 && ((Short)compoundtag1.get("id").getValue()).shortValue() == item.identifier() && ((Short)compoundtag1.get("data").getValue()).shortValue() == item.data())
            {
                item.tag().remove("ViaRewind1_7_6_10to1_8");

                if (item.tag().isEmpty())
                {
                    item.setTag((CompoundTag)null);
                }
            }

            return item;
        }
    }

    public static Item toServer(Item item)
    {
        if (item == null)
        {
            return null;
        }
        else
        {
            CompoundTag compoundtag = item.tag();

            if (compoundtag != null && item.tag().contains("ViaRewind1_7_6_10to1_8"))
            {
                CompoundTag compoundtag1 = (CompoundTag)compoundtag.remove("ViaRewind1_7_6_10to1_8");
                item.setIdentifier(((Short)compoundtag1.get("id").getValue()).shortValue());
                item.setData(((Short)compoundtag1.get("data").getValue()).shortValue());

                if (compoundtag1.contains("noDisplay"))
                {
                    compoundtag.remove("display");
                }

                if (compoundtag1.contains("displayName"))
                {
                    CompoundTag compoundtag2 = (CompoundTag)compoundtag.get("display");

                    if (compoundtag2 == null)
                    {
                        compoundtag.put("display", compoundtag2 = new CompoundTag());
                    }

                    StringTag stringtag = (StringTag)compoundtag2.get("Name");

                    if (stringtag == null)
                    {
                        compoundtag2.put("Name", new StringTag((String)compoundtag1.get("displayName").getValue()));
                    }
                    else
                    {
                        stringtag.setValue((String)compoundtag1.get("displayName").getValue());
                    }
                }
                else if (compoundtag.contains("display"))
                {
                    ((CompoundTag)compoundtag.get("display")).remove("Name");
                }

                if (item.identifier() == 387)
                {
                    ListTag listtag = (ListTag)compoundtag1.get("pages");
                    compoundtag.remove("pages");
                    compoundtag.put("pages", listtag);
                }

                return item;
            }
            else
            {
                return item;
            }
        }
    }
}

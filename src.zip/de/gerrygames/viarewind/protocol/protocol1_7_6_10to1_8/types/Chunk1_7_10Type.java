package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types;

import com.viaversion.viaversion.api.minecraft.Environment;
import com.viaversion.viaversion.api.minecraft.chunks.Chunk;
import com.viaversion.viaversion.api.minecraft.chunks.ChunkSection;
import com.viaversion.viaversion.api.type.PartialType;
import com.viaversion.viaversion.protocols.protocol1_9_3to1_9_1_2.storage.ClientWorld;
import io.netty.buffer.ByteBuf;
import java.util.zip.Deflater;

public class Chunk1_7_10Type extends PartialType<Chunk, ClientWorld>
{
    public Chunk1_7_10Type(ClientWorld param)
    {
        super(param, Chunk.class);
    }

    public Chunk read(ByteBuf byteBuf, ClientWorld clientWorld) throws Exception
    {
        throw new UnsupportedOperationException();
    }

    public void write(ByteBuf output, ClientWorld clientWorld, Chunk chunk) throws Exception
    {
        output.writeInt(chunk.getX());
        output.writeInt(chunk.getZ());
        output.writeBoolean(chunk.isFullChunk());
        output.writeShort(chunk.getBitmask());
        output.writeShort(0);
        ByteBuf bytebuf = output.alloc().buffer();
        ByteBuf bytebuf1 = output.alloc().buffer();

        for (int i = 0; i < chunk.getSections().length; ++i)
        {
            if ((chunk.getBitmask() & 1 << i) != 0)
            {
                ChunkSection chunksection = chunk.getSections()[i];

                for (int j = 0; j < 16; ++j)
                {
                    for (int k = 0; k < 16; ++k)
                    {
                        int l = 0;

                        for (int i1 = 0; i1 < 16; ++i1)
                        {
                            int j1 = chunksection.getFlatBlock(i1, j, k);
                            bytebuf.writeByte(j1 >> 4);
                            int k1 = j1 & 15;

                            if (i1 % 2 == 0)
                            {
                                l = k1;
                            }
                            else
                            {
                                bytebuf1.writeByte(k1 << 4 | l);
                            }
                        }
                    }
                }
            }
        }

        bytebuf.writeBytes(bytebuf1);
        bytebuf1.release();

        for (int l1 = 0; l1 < chunk.getSections().length; ++l1)
        {
            if ((chunk.getBitmask() & 1 << l1) != 0)
            {
                chunk.getSections()[l1].getLight().writeBlockLight(bytebuf);
            }
        }

        boolean flag = clientWorld != null && clientWorld.getEnvironment() == Environment.NORMAL;

        if (flag)
        {
            for (int i2 = 0; i2 < chunk.getSections().length; ++i2)
            {
                if ((chunk.getBitmask() & 1 << i2) != 0)
                {
                    chunk.getSections()[i2].getLight().writeSkyLight(bytebuf);
                }
            }
        }

        if (chunk.isFullChunk() && chunk.isBiomeData())
        {
            for (int j2 : chunk.getBiomeData())
            {
                bytebuf.writeByte((byte)j2);
            }
        }

        bytebuf.readerIndex(0);
        byte[] abyte = new byte[bytebuf.readableBytes()];
        bytebuf.readBytes(abyte);
        bytebuf.release();
        Deflater deflater = new Deflater(4);
        byte[] abyte1;
        int k2;

        try
        {
            deflater.setInput(abyte, 0, abyte.length);
            deflater.finish();
            abyte1 = new byte[abyte.length];
            k2 = deflater.deflate(abyte1);
        }
        finally
        {
            deflater.end();
        }

        output.writeInt(k2);
        output.writeBytes(abyte1, 0, k2);
    }
}

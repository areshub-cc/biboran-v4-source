package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types;

import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.type.Type;
import io.netty.buffer.ByteBuf;

public class ItemArrayType extends Type<Item[]>
{
    private final boolean compressed;

    public ItemArrayType(boolean compressed)
    {
        super(Item[].class);
        this.compressed = compressed;
    }

    public Item[] read(ByteBuf buffer) throws Exception
    {
        int i = Type.SHORT.read(buffer).shortValue();
        Item[] aitem = new Item[i];

        for (int j = 0; j < i; ++j)
        {
            aitem[j] = (Item)(this.compressed ? Types1_7_6_10.COMPRESSED_NBT_ITEM : Types1_7_6_10.ITEM).read(buffer);
        }

        return aitem;
    }

    public void write(ByteBuf buffer, Item[] items) throws Exception
    {
        Type.SHORT.write(buffer, Short.valueOf((short)items.length));

        for (Item item : items)
        {
            (this.compressed ? Types1_7_6_10.COMPRESSED_NBT_ITEM : Types1_7_6_10.ITEM).write(buffer, item);
        }
    }
}

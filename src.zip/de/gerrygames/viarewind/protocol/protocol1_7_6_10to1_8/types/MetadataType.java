package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types;

import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.type.types.minecraft.MetaTypeTemplate;
import io.netty.buffer.ByteBuf;

public class MetadataType extends MetaTypeTemplate
{
    public Metadata read(ByteBuf buffer) throws Exception
    {
        byte b0 = buffer.readByte();

        if (b0 == 127)
        {
            return null;
        }
        else
        {
            int i = (b0 & 224) >> 5;
            MetaType1_7_6_10 metatype1_7_6_10 = MetaType1_7_6_10.byId(i);
            int j = b0 & 31;
            return new Metadata(j, metatype1_7_6_10, metatype1_7_6_10.type().read(buffer));
        }
    }

    public void write(ByteBuf buffer, Metadata meta) throws Exception
    {
        int i = (meta.metaType().typeId() << 5 | meta.id() & 31) & 255;
        buffer.writeByte(i);
        meta.metaType().type().write(buffer, meta.getValue());
    }
}

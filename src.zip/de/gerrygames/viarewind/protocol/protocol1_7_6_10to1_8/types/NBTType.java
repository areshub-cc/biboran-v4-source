package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types;

import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.libs.opennbt.NBTIO;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.CompoundTag;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class NBTType extends Type<CompoundTag>
{
    public NBTType()
    {
        super(CompoundTag.class);
    }

    public CompoundTag read(ByteBuf buffer)
    {
        short short1 = buffer.readShort();

        if (short1 < 0)
        {
            return null;
        }
        else
        {
            ByteBufInputStream bytebufinputstream = new ByteBufInputStream(buffer);
            DataInputStream datainputstream = new DataInputStream(bytebufinputstream);

            try
            {
                CompoundTag e = NBTIO.readTag(datainputstream);
                return e;
            }
            catch (Throwable throwable)
            {
                throwable.printStackTrace();
            }
            finally
            {
                try
                {
                    datainputstream.close();
                }
                catch (IOException ioexception)
                {
                    ioexception.printStackTrace();
                }
            }

            return null;
        }
    }

    public void write(ByteBuf buffer, CompoundTag nbt) throws Exception
    {
        if (nbt == null)
        {
            buffer.writeShort(-1);
        }
        else
        {
            ByteBuf bytebuf = buffer.alloc().buffer();
            ByteBufOutputStream bytebufoutputstream = new ByteBufOutputStream(bytebuf);
            DataOutputStream dataoutputstream = new DataOutputStream(bytebufoutputstream);
            NBTIO.writeTag(dataoutputstream, nbt);
            dataoutputstream.close();
            buffer.writeShort(bytebuf.readableBytes());
            buffer.writeBytes(bytebuf);
            bytebuf.release();
        }
    }
}

package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types;

import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.libs.opennbt.NBTIO;
import com.viaversion.viaversion.libs.opennbt.tag.builtin.CompoundTag;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class CompressedNBTType extends Type<CompoundTag>
{
    public CompressedNBTType()
    {
        super(CompoundTag.class);
    }

    public CompoundTag read(ByteBuf buffer) throws IOException
    {
        short short1 = buffer.readShort();

        if (short1 <= 0)
        {
            return null;
        }
        else
        {
            ByteBuf bytebuf = buffer.readSlice(short1);
            GZIPInputStream gzipinputstream = new GZIPInputStream(new ByteBufInputStream(bytebuf));
            CompoundTag compoundtag;

            try
            {
                compoundtag = NBTIO.readTag(gzipinputstream);
            }
            catch (Throwable throwable1)
            {
                try
                {
                    gzipinputstream.close();
                }
                catch (Throwable throwable)
                {
                    throwable1.addSuppressed(throwable);
                }

                throw throwable1;
            }

            gzipinputstream.close();
            return compoundtag;
        }
    }

    public void write(ByteBuf buffer, CompoundTag nbt) throws Exception
    {
        if (nbt == null)
        {
            buffer.writeShort(-1);
        }
        else
        {
            ByteBuf bytebuf = buffer.alloc().buffer();

            try
            {
                GZIPOutputStream gzipoutputstream = new GZIPOutputStream(new ByteBufOutputStream(bytebuf));

                try
                {
                    NBTIO.writeTag(gzipoutputstream, nbt);
                }
                catch (Throwable throwable1)
                {
                    try
                    {
                        gzipoutputstream.close();
                    }
                    catch (Throwable throwable)
                    {
                        throwable1.addSuppressed(throwable);
                    }

                    throw throwable1;
                }

                gzipoutputstream.close();
                buffer.writeShort(bytebuf.readableBytes());
                buffer.writeBytes(bytebuf);
            }
            finally
            {
                bytebuf.release();
            }
        }
    }
}

package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types;

import com.viaversion.viaversion.api.type.Type;
import io.netty.buffer.ByteBuf;

public class IntArrayType extends Type<int[]>
{
    public IntArrayType()
    {
        super(int[].class);
    }

    public int[] read(ByteBuf byteBuf) throws Exception
    {
        byte b0 = byteBuf.readByte();
        int[] aint = new int[b0];

        for (byte b1 = 0; b1 < b0; ++b1)
        {
            aint[b1] = byteBuf.readInt();
        }

        return aint;
    }

    public void write(ByteBuf byteBuf, int[] array) throws Exception
    {
        byteBuf.writeByte(array.length);

        for (int i : array)
        {
            byteBuf.writeInt(i);
        }
    }
}

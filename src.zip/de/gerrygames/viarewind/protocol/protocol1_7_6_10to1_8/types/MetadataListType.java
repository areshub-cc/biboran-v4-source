package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types;

import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.type.types.minecraft.MetaListTypeTemplate;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;

public class MetadataListType extends MetaListTypeTemplate
{
    private MetadataType metadataType = new MetadataType();

    public List<Metadata> read(ByteBuf buffer) throws Exception
    {
        ArrayList<Metadata> arraylist = new ArrayList<Metadata>();

        while (true)
        {
            Metadata metadata = (Metadata)Types1_7_6_10.METADATA.read(buffer);

            if (metadata != null)
            {
                arraylist.add(metadata);
            }

            if (metadata == null)
            {
                break;
            }
        }

        return arraylist;
    }

    public void write(ByteBuf buffer, List<Metadata> metadata) throws Exception
    {
        for (Metadata metadata : metadata)
        {
            Types1_7_6_10.METADATA.write(buffer, metadata);
        }

        if (metadata.isEmpty())
        {
            Types1_7_6_10.METADATA.write(buffer, new Metadata(0, MetaType1_7_6_10.Byte, 0));
        }

        buffer.writeByte(127);
    }
}

package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.metadata;

import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.util.Pair;
import de.gerrygames.viarewind.protocol.protocol1_8to1_7_6_10.metadata.MetaIndex1_8to1_7_6_10;
import java.util.HashMap;
import java.util.Optional;

public class MetaIndex1_7_6_10to1_8
{
    private static final HashMap<Pair<EntityType, Integer>, MetaIndex1_8to1_7_6_10> metadataRewrites = new HashMap<Pair<EntityType, Integer>, MetaIndex1_8to1_7_6_10>();

    private static Optional<MetaIndex1_8to1_7_6_10> getIndex(EntityType type, int index)
    {
        Pair pair = new Pair(type, index);
        return metadataRewrites.containsKey(pair) ? Optional.of(metadataRewrites.get(pair)) : Optional.empty();
    }

    public static MetaIndex1_8to1_7_6_10 searchIndex(EntityType type, int index)
    {
        EntityType entitytype = type;

        while (true)
        {
            Optional<MetaIndex1_8to1_7_6_10> optional = getIndex(entitytype, index);

            if (optional.isPresent())
            {
                return optional.get();
            }

            entitytype = entitytype.getParent();

            if (entitytype == null)
            {
                break;
            }
        }

        return null;
    }

    static
    {
        for (MetaIndex1_8to1_7_6_10 metaindex1_8to1_7_6_10 : MetaIndex1_8to1_7_6_10.values())
        {
            metadataRewrites.put(new Pair(metaindex1_8to1_7_6_10.getClazz(), metaindex1_8to1_7_6_10.getNewIndex()), metaindex1_8to1_7_6_10);
        }
    }
}

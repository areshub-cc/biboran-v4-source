package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.metadata;

import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.item.Item;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.minecraft.metadata.types.MetaType1_8;
import de.gerrygames.viarewind.ViaRewind;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.items.ItemRewriter;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.MetaType1_7_6_10;
import de.gerrygames.viarewind.protocol.protocol1_8to1_7_6_10.metadata.MetaIndex1_8to1_7_6_10;
import java.util.ArrayList;
import java.util.List;

public class MetadataRewriter
{
    public static void transform(EntityType type, List<Metadata> list)
    {
        for (Metadata metadata : new ArrayList(list))
        {
            MetaIndex1_8to1_7_6_10 metaindex1_8to1_7_6_10 = MetaIndex1_7_6_10to1_8.searchIndex(type, metadata.id());

            try
            {
                if (metaindex1_8to1_7_6_10 == null)
                {
                    throw new Exception("Could not find valid metadata");
                }

                if (metaindex1_8to1_7_6_10.getOldType() == MetaType1_7_6_10.NonExistent)
                {
                    list.remove(metadata);
                }
                else
                {
                    Object object = metadata.getValue();

                    if (!metaindex1_8to1_7_6_10.getNewType().type().getOutputClass().isAssignableFrom(object.getClass()))
                    {
                        list.remove(metadata);
                    }
                    else
                    {
                        metadata.setMetaTypeUnsafe(metaindex1_8to1_7_6_10.getOldType());
                        metadata.setId(metaindex1_8to1_7_6_10.getIndex());

                        switch (metaindex1_8to1_7_6_10.getOldType())
                        {
                            case Int:
                                if (metaindex1_8to1_7_6_10.getNewType() == MetaType1_8.Byte)
                                {
                                    metadata.setValue(Integer.valueOf(((Byte)object).intValue()));

                                    if (metaindex1_8to1_7_6_10 == MetaIndex1_8to1_7_6_10.ENTITY_AGEABLE_AGE && ((Integer)metadata.getValue()).intValue() < 0)
                                    {
                                        metadata.setValue(Integer.valueOf(-25000));
                                    }
                                }

                                if (metaindex1_8to1_7_6_10.getNewType() == MetaType1_8.Short)
                                {
                                    metadata.setValue(Integer.valueOf(((Short)object).intValue()));
                                }

                                if (metaindex1_8to1_7_6_10.getNewType() == MetaType1_8.Int)
                                {
                                    metadata.setValue(object);
                                }

                                break;

                            case Byte:
                                if (metaindex1_8to1_7_6_10.getNewType() == MetaType1_8.Int)
                                {
                                    metadata.setValue(Byte.valueOf(((Integer)object).byteValue()));
                                }

                                if (metaindex1_8to1_7_6_10.getNewType() == MetaType1_8.Byte)
                                {
                                    if (metaindex1_8to1_7_6_10 == MetaIndex1_8to1_7_6_10.ITEM_FRAME_ROTATION)
                                    {
                                        object = ((Byte)object).byteValue() / 2.byteValue();
                                    }

                                    metadata.setValue(object);
                                }

                                if (metaindex1_8to1_7_6_10 == MetaIndex1_8to1_7_6_10.HUMAN_SKIN_FLAGS)
                                {
                                    byte b0 = ((Byte)object).byteValue();
                                    boolean flag = (b0 & 1) != 0;
                                    b0 = (byte)(flag ? 0 : 2);
                                    metadata.setValue(Byte.valueOf(b0));
                                }

                                break;

                            case Slot:
                                metadata.setValue(ItemRewriter.toClient((Item)object));
                                break;

                            case Float:
                                metadata.setValue(object);
                                break;

                            case Short:
                                metadata.setValue(object);
                                break;

                            case String:
                                metadata.setValue(object);
                                break;

                            case Position:
                                metadata.setValue(object);
                                break;

                            default:
                                ViaRewind.getPlatform().getLogger().warning("[Out] Unhandled MetaDataType: " + metaindex1_8to1_7_6_10.getNewType());
                                list.remove(metadata);
                        }
                    }
                }
            }
            catch (Exception var8)
            {
                list.remove(metadata);
            }
        }
    }
}

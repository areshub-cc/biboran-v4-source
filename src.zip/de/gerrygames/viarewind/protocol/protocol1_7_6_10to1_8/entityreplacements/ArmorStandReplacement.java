package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.entityreplacements;

import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.minecraft.entities.Entity1_10Types.EntityType;
import com.viaversion.viaversion.api.minecraft.metadata.Metadata;
import com.viaversion.viaversion.api.minecraft.metadata.types.MetaType1_8;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.Protocol1_7_6_10TO1_8;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.metadata.MetadataRewriter;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.MetaType1_7_6_10;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.types.Types1_7_6_10;
import de.gerrygames.viarewind.replacement.EntityReplacement;
import de.gerrygames.viarewind.utils.PacketUtil;
import de.gerrygames.viarewind.utils.math.AABB;
import de.gerrygames.viarewind.utils.math.Vector3d;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class ArmorStandReplacement implements EntityReplacement
{
    private int entityId;
    private List<Metadata> datawatcher = new ArrayList<Metadata>();
    private int[] entityIds = null;
    private double locX;
    private double locY;
    private double locZ;
    private ArmorStandReplacement.State currentState = null;
    private boolean invisible = false;
    private boolean nameTagVisible = false;
    private String name = null;
    private UserConnection user;
    private float yaw;
    private float pitch;
    private float headYaw;
    private boolean small = false;
    private boolean marker = false;
    private static int ENTITY_ID = 2147467647;

    public int getEntityId()
    {
        return this.entityId;
    }

    public ArmorStandReplacement(int entityId, UserConnection user)
    {
        this.entityId = entityId;
        this.user = user;
    }

    public void setLocation(double x, double y, double z)
    {
        if (x != this.locX || y != this.locY || z != this.locZ)
        {
            this.locX = x;
            this.locY = y;
            this.locZ = z;
            this.updateLocation();
        }
    }

    public void relMove(double x, double y, double z)
    {
        if (x != 0.0D || y != 0.0D || z != 0.0D)
        {
            this.locX += x;
            this.locY += y;
            this.locZ += z;
            this.updateLocation();
        }
    }

    public void setYawPitch(float yaw, float pitch)
    {
        if (this.yaw != yaw && this.pitch != pitch || this.headYaw != yaw)
        {
            this.yaw = yaw;
            this.headYaw = yaw;
            this.pitch = pitch;
            this.updateLocation();
        }
    }

    public void setHeadYaw(float yaw)
    {
        if (this.headYaw != yaw)
        {
            this.headYaw = yaw;
            this.updateLocation();
        }
    }

    public void updateMetadata(List<Metadata> metadataList)
    {
        for (Metadata metadata : metadataList)
        {
            this.datawatcher.removeIf((m) ->
            {
                return (void)(m.id() == metadata.id());
            });
            this.datawatcher.add(metadata);
        }

        this.updateState();
    }

    public void updateState()
    {
        byte b0 = 0;
        byte b1 = 0;

        for (Metadata metadata1 : this.datawatcher)
        {
            if (metadata1.id() == 0 && metadata1.metaType() == MetaType1_8.Byte)
            {
                b0 = ((Byte)metadata1.getValue()).byteValue();
            }
            else if (metadata1.id() == 2 && metadata1.metaType() == MetaType1_8.String)
            {
                this.name = (String)metadata1.getValue();

                if (this.name != null && this.name.equals(""))
                {
                    this.name = null;
                }
            }
            else if (metadata1.id() == 10 && metadata1.metaType() == MetaType1_8.Byte)
            {
                b1 = ((Byte)metadata1.getValue()).byteValue();
            }
            else if (metadata1.id() == 3 && metadata1.metaType() == MetaType1_8.Byte)
            {
                this.nameTagVisible = (byte)metadata1.id() != 0;
            }
        }

        this.invisible = (b0 & 32) != 0;
        this.small = (b1 & 1) != 0;
        this.marker = (b1 & 16) != 0;
        ArmorStandReplacement.State armorstandreplacement$state = this.currentState;

        if (this.invisible && this.name != null)
        {
            this.currentState = ArmorStandReplacement.State.HOLOGRAM;
        }
        else
        {
            this.currentState = ArmorStandReplacement.State.ZOMBIE;
        }

        if (this.currentState != armorstandreplacement$state)
        {
            this.despawn();
            this.spawn();
        }
        else
        {
            this.updateMetadata();
            this.updateLocation();
        }
    }

    public void updateLocation()
    {
        if (this.entityIds != null)
        {
            if (this.currentState == ArmorStandReplacement.State.ZOMBIE)
            {
                PacketWrapper packetwrapper = PacketWrapper.create(24, (ByteBuf)null, this.user);
                packetwrapper.write(Type.INT, Integer.valueOf(this.entityId));
                packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locX * 32.0D)));
                packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locY * 32.0D)));
                packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locZ * 32.0D)));
                packetwrapper.write(Type.BYTE, Byte.valueOf((byte)((int)(this.yaw / 360.0F * 256.0F))));
                packetwrapper.write(Type.BYTE, Byte.valueOf((byte)((int)(this.pitch / 360.0F * 256.0F))));
                PacketWrapper packetwrapper1 = PacketWrapper.create(25, (ByteBuf)null, this.user);
                packetwrapper1.write(Type.INT, Integer.valueOf(this.entityId));
                packetwrapper1.write(Type.BYTE, Byte.valueOf((byte)((int)(this.headYaw / 360.0F * 256.0F))));
                PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
                PacketUtil.sendPacket(packetwrapper1, Protocol1_7_6_10TO1_8.class, true, true);
            }
            else if (this.currentState == ArmorStandReplacement.State.HOLOGRAM)
            {
                PacketWrapper packetwrapper4 = PacketWrapper.create(27, (ByteBuf)null, this.user);
                packetwrapper4.write(Type.INT, Integer.valueOf(this.entityIds[1]));
                packetwrapper4.write(Type.INT, Integer.valueOf(-1));
                packetwrapper4.write(Type.BOOLEAN, Boolean.valueOf(false));
                PacketWrapper packetwrapper5 = PacketWrapper.create(24, (ByteBuf)null, this.user);
                packetwrapper5.write(Type.INT, Integer.valueOf(this.entityIds[0]));
                packetwrapper5.write(Type.INT, Integer.valueOf((int)(this.locX * 32.0D)));
                packetwrapper5.write(Type.INT, Integer.valueOf((int)((this.locY + (this.marker ? 54.85D : (this.small ? 56.0D : 57.0D))) * 32.0D)));
                packetwrapper5.write(Type.INT, Integer.valueOf((int)(this.locZ * 32.0D)));
                packetwrapper5.write(Type.BYTE, Byte.valueOf((byte)0));
                packetwrapper5.write(Type.BYTE, Byte.valueOf((byte)0));
                PacketWrapper packetwrapper2 = PacketWrapper.create(24, (ByteBuf)null, this.user);
                packetwrapper2.write(Type.INT, Integer.valueOf(this.entityIds[1]));
                packetwrapper2.write(Type.INT, Integer.valueOf((int)(this.locX * 32.0D)));
                packetwrapper2.write(Type.INT, Integer.valueOf((int)((this.locY + 56.75D) * 32.0D)));
                packetwrapper2.write(Type.INT, Integer.valueOf((int)(this.locZ * 32.0D)));
                packetwrapper2.write(Type.BYTE, Byte.valueOf((byte)0));
                packetwrapper2.write(Type.BYTE, Byte.valueOf((byte)0));
                PacketWrapper packetwrapper3 = PacketWrapper.create(27, (ByteBuf)null, this.user);
                packetwrapper3.write(Type.INT, Integer.valueOf(this.entityIds[1]));
                packetwrapper3.write(Type.INT, Integer.valueOf(this.entityIds[0]));
                packetwrapper3.write(Type.BOOLEAN, Boolean.valueOf(false));
                PacketUtil.sendPacket(packetwrapper4, Protocol1_7_6_10TO1_8.class, true, true);
                PacketUtil.sendPacket(packetwrapper5, Protocol1_7_6_10TO1_8.class, true, true);
                PacketUtil.sendPacket(packetwrapper2, Protocol1_7_6_10TO1_8.class, true, true);
                PacketUtil.sendPacket(packetwrapper3, Protocol1_7_6_10TO1_8.class, true, true);
            }
        }
    }

    public void updateMetadata()
    {
        if (this.entityIds != null)
        {
            PacketWrapper packetwrapper = PacketWrapper.create(28, (ByteBuf)null, this.user);

            if (this.currentState == ArmorStandReplacement.State.ZOMBIE)
            {
                packetwrapper.write(Type.INT, Integer.valueOf(this.entityIds[0]));
                List<Metadata> list = new ArrayList<Metadata>();

                for (Metadata metadata1 : this.datawatcher)
                {
                    if (metadata1.id() >= 0 && metadata1.id() <= 9)
                    {
                        list.add(new Metadata(metadata1.id(), metadata1.metaType(), metadata1.getValue()));
                    }
                }

                if (this.small)
                {
                    list.add(new Metadata(12, MetaType1_8.Byte, 1));
                }

                MetadataRewriter.transform(EntityType.ZOMBIE, list);
                packetwrapper.write(Types1_7_6_10.METADATA_LIST, list);
            }
            else
            {
                if (this.currentState != ArmorStandReplacement.State.HOLOGRAM)
                {
                    return;
                }

                packetwrapper.write(Type.INT, Integer.valueOf(this.entityIds[1]));
                List<Metadata> list1 = new ArrayList<Metadata>();
                list1.add(new Metadata(12, MetaType1_7_6_10.Int, -1700000));
                list1.add(new Metadata(10, MetaType1_7_6_10.String, this.name));
                list1.add(new Metadata(11, MetaType1_7_6_10.Byte, 1));
                packetwrapper.write(Types1_7_6_10.METADATA_LIST, list1);
            }

            PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class);
        }
    }

    public void spawn()
    {
        if (this.entityIds != null)
        {
            this.despawn();
        }

        if (this.currentState == ArmorStandReplacement.State.ZOMBIE)
        {
            PacketWrapper packetwrapper = PacketWrapper.create(15, (ByteBuf)null, this.user);
            packetwrapper.write(Type.VAR_INT, Integer.valueOf(this.entityId));
            packetwrapper.write(Type.UNSIGNED_BYTE, Short.valueOf((short)54));
            packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locX * 32.0D)));
            packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locY * 32.0D)));
            packetwrapper.write(Type.INT, Integer.valueOf((int)(this.locZ * 32.0D)));
            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper.write(Type.SHORT, Short.valueOf((short)0));
            packetwrapper.write(Type.SHORT, Short.valueOf((short)0));
            packetwrapper.write(Type.SHORT, Short.valueOf((short)0));
            packetwrapper.write(Types1_7_6_10.METADATA_LIST, new ArrayList());
            PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
            this.entityIds = new int[] {this.entityId};
        }
        else if (this.currentState == ArmorStandReplacement.State.HOLOGRAM)
        {
            int[] aint = new int[] {this.entityId, ENTITY_ID--};
            PacketWrapper packetwrapper1 = PacketWrapper.create(14, (ByteBuf)null, this.user);
            packetwrapper1.write(Type.VAR_INT, Integer.valueOf(aint[0]));
            packetwrapper1.write(Type.BYTE, Byte.valueOf((byte)66));
            packetwrapper1.write(Type.INT, Integer.valueOf((int)(this.locX * 32.0D)));
            packetwrapper1.write(Type.INT, Integer.valueOf((int)(this.locY * 32.0D)));
            packetwrapper1.write(Type.INT, Integer.valueOf((int)(this.locZ * 32.0D)));
            packetwrapper1.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper1.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper1.write(Type.INT, Integer.valueOf(0));
            PacketWrapper packetwrapper2 = PacketWrapper.create(15, (ByteBuf)null, this.user);
            packetwrapper2.write(Type.VAR_INT, Integer.valueOf(aint[1]));
            packetwrapper2.write(Type.UNSIGNED_BYTE, Short.valueOf((short)100));
            packetwrapper2.write(Type.INT, Integer.valueOf((int)(this.locX * 32.0D)));
            packetwrapper2.write(Type.INT, Integer.valueOf((int)(this.locY * 32.0D)));
            packetwrapper2.write(Type.INT, Integer.valueOf((int)(this.locZ * 32.0D)));
            packetwrapper2.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper2.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper2.write(Type.BYTE, Byte.valueOf((byte)0));
            packetwrapper2.write(Type.SHORT, Short.valueOf((short)0));
            packetwrapper2.write(Type.SHORT, Short.valueOf((short)0));
            packetwrapper2.write(Type.SHORT, Short.valueOf((short)0));
            packetwrapper2.write(Types1_7_6_10.METADATA_LIST, new ArrayList());
            PacketUtil.sendPacket(packetwrapper1, Protocol1_7_6_10TO1_8.class, true, true);
            PacketUtil.sendPacket(packetwrapper2, Protocol1_7_6_10TO1_8.class, true, true);
            this.entityIds = aint;
        }

        this.updateMetadata();
        this.updateLocation();
    }

    public AABB getBoundingBox()
    {
        double d0 = this.small ? 0.25D : 0.5D;
        double d1 = this.small ? 0.9875D : 1.975D;
        Vector3d vector3d = new Vector3d(this.locX - d0 / 2.0D, this.locY, this.locZ - d0 / 2.0D);
        Vector3d vector3d1 = new Vector3d(this.locX + d0 / 2.0D, this.locY + d1, this.locZ + d0 / 2.0D);
        return new AABB(vector3d, vector3d1);
    }

    public void despawn()
    {
        if (this.entityIds != null)
        {
            PacketWrapper packetwrapper = PacketWrapper.create(19, (ByteBuf)null, this.user);
            packetwrapper.write(Type.BYTE, Byte.valueOf((byte)this.entityIds.length));

            for (int i : this.entityIds)
            {
                packetwrapper.write(Type.INT, Integer.valueOf(i));
            }

            this.entityIds = null;
            PacketUtil.sendPacket(packetwrapper, Protocol1_7_6_10TO1_8.class, true, true);
        }
    }

    private static enum State
    {
        HOLOGRAM,
        ZOMBIE;
    }
}

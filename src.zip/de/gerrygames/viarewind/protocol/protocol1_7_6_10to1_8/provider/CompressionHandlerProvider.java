package de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.provider;

import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.platform.providers.Provider;
import com.viaversion.viaversion.api.type.Type;
import de.gerrygames.viarewind.netty.EmptyChannelHandler;
import de.gerrygames.viarewind.netty.ForwardMessageToByteEncoder;
import de.gerrygames.viarewind.protocol.protocol1_7_6_10to1_8.storage.CompressionSendStorage;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPipeline;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.MessageToByteEncoder;
import io.netty.handler.codec.MessageToMessageDecoder;
import java.util.List;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

public class CompressionHandlerProvider implements Provider
{
    public void handleSetCompression(UserConnection user, int threshold)
    {
        ChannelPipeline channelpipeline = user.getChannel().pipeline();

        if (user.isClientSide())
        {
            channelpipeline.addBefore(Via.getManager().getInjector().getEncoderName(), "compress", this.getEncoder(threshold));
            channelpipeline.addBefore(Via.getManager().getInjector().getDecoderName(), "decompress", this.getDecoder(threshold));
        }
        else
        {
            CompressionSendStorage compressionsendstorage = (CompressionSendStorage)user.get(CompressionSendStorage.class);
            compressionsendstorage.setRemoveCompression(true);
        }
    }

    public void handleTransform(UserConnection user)
    {
        CompressionSendStorage compressionsendstorage = (CompressionSendStorage)user.get(CompressionSendStorage.class);

        if (compressionsendstorage.isRemoveCompression())
        {
            ChannelPipeline channelpipeline = user.getChannel().pipeline();
            String s = null;
            String s1 = null;

            if (channelpipeline.get("compress") != null)
            {
                s = "compress";
                s1 = "decompress";
            }
            else if (channelpipeline.get("compression-encoder") != null)
            {
                s = "compression-encoder";
                s1 = "compression-decoder";
            }

            if (s == null)
            {
                throw new IllegalStateException("Couldn't remove compression for 1.7!");
            }

            channelpipeline.replace(s1, s1, new EmptyChannelHandler());
            channelpipeline.replace(s, s, new ForwardMessageToByteEncoder());
            compressionsendstorage.setRemoveCompression(false);
        }
    }

    protected ChannelHandler getEncoder(int threshold)
    {
        return new CompressionHandlerProvider.Compressor(threshold);
    }

    protected ChannelHandler getDecoder(int threshold)
    {
        return new CompressionHandlerProvider.Decompressor(threshold);
    }

    private static class Compressor extends MessageToByteEncoder<ByteBuf>
    {
        private final Deflater deflater;
        private final int threshold;

        public Compressor(int var1)
        {
            this.threshold = var1;
            this.deflater = new Deflater();
        }

        protected void encode(ChannelHandlerContext ctx, ByteBuf in, ByteBuf out) throws Exception
        {
            int i = in.readableBytes();

            if (i < this.threshold)
            {
                out.writeByte(0);
                out.writeBytes(in);
            }
            else
            {
                Type.VAR_INT.writePrimitive(out, i);
                ByteBuf bytebuf = in;

                if (!in.hasArray())
                {
                    bytebuf = ByteBufAllocator.DEFAULT.heapBuffer().writeBytes(in);
                }
                else
                {
                    in.retain();
                }

                ByteBuf bytebuf1 = ByteBufAllocator.DEFAULT.heapBuffer();

                try
                {
                    this.deflater.setInput(bytebuf.array(), bytebuf.arrayOffset() + bytebuf.readerIndex(), bytebuf.readableBytes());
                    this.deflater.finish();

                    while (!this.deflater.finished())
                    {
                        bytebuf1.ensureWritable(4096);
                        bytebuf1.writerIndex(bytebuf1.writerIndex() + this.deflater.deflate(bytebuf1.array(), bytebuf1.arrayOffset() + bytebuf1.writerIndex(), bytebuf1.writableBytes()));
                    }

                    out.writeBytes(bytebuf1);
                }
                finally
                {
                    bytebuf1.release();
                    bytebuf.release();
                    this.deflater.reset();
                }
            }
        }
    }

    private static class Decompressor extends MessageToMessageDecoder<ByteBuf>
    {
        private final Inflater inflater;
        private final int threshold;

        public Decompressor(int var1)
        {
            this.threshold = var1;
            this.inflater = new Inflater();
        }

        protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception
        {
            if (in.isReadable())
            {
                int i = Type.VAR_INT.readPrimitive(in);

                if (i == 0)
                {
                    out.add(in.readBytes(in.readableBytes()));
                }
                else if (i < this.threshold)
                {
                    throw new DecoderException("Badly compressed packet - size of " + i + " is below server threshold of " + this.threshold);
                }
                else if (i > 2097152)
                {
                    throw new DecoderException("Badly compressed packet - size of " + i + " is larger than protocol maximum of " + 2097152);
                }
                else
                {
                    ByteBuf bytebuf = in;

                    if (!in.hasArray())
                    {
                        bytebuf = ByteBufAllocator.DEFAULT.heapBuffer().writeBytes(in);
                    }
                    else
                    {
                        in.retain();
                    }

                    ByteBuf bytebuf1 = ByteBufAllocator.DEFAULT.heapBuffer(i, i);

                    try
                    {
                        this.inflater.setInput(bytebuf.array(), bytebuf.arrayOffset() + bytebuf.readerIndex(), bytebuf.readableBytes());
                        bytebuf1.writerIndex(bytebuf1.writerIndex() + this.inflater.inflate(bytebuf1.array(), bytebuf1.arrayOffset(), i));
                        out.add(bytebuf1.retain());
                    }
                    finally
                    {
                        bytebuf1.release();
                        bytebuf.release();
                        this.inflater.reset();
                    }
                }
            }
        }
    }
}

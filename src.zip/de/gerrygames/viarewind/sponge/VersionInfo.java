package de.gerrygames.viarewind.sponge;

public class VersionInfo
{
    public static final String VERSION = "2.0.3-SNAPSHOT";
}

package de.gerrygames.viarewind.types;

import com.viaversion.viaversion.api.type.Type;
import io.netty.buffer.ByteBuf;

public class VarLongType extends Type<Long>
{
    public static final VarLongType VAR_LONG = new VarLongType();

    public VarLongType()
    {
        super("VarLong", Long.class);
    }

    public Long read(ByteBuf byteBuf) throws Exception
    {
        long i = 0L;
        int j = 0;

        while (true)
        {
            byte b0 = byteBuf.readByte();
            i |= (long)((b0 & 127) << j++ * 7);

            if (j > 10)
            {
                throw new RuntimeException("VarLong too big");
            }

            if ((b0 & 128) != 128)
            {
                break;
            }
        }

        return i;
    }

    public void write(ByteBuf byteBuf, Long i) throws Exception
    {
        while ((i.longValue() & -128L) != 0L)
        {
            byteBuf.writeByte((int)(i.longValue() & 127L) | 128);
            i = i.longValue() >>> 7;
        }

        byteBuf.writeByte(i.intValue());
    }
}

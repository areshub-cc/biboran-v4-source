package de.gerrygames.viarewind.netty;

import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelHandler.Sharable;

@Sharable
public class EmptyChannelHandler extends ChannelHandlerAdapter
{
}

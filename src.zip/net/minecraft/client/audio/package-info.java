@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.audio;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;
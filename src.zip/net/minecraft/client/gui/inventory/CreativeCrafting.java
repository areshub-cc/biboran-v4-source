package net.minecraft.client.gui.inventory;

import net.minecraft.client.Minecraft;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class CreativeCrafting implements IContainerListener
{
    private final Minecraft mc;

    public CreativeCrafting(Minecraft mc)
    {
        this.mc = mc;
    }

    public void updateCraftingInventory(Container p_updateCraftingInventory_1_, NonNullList<ItemStack> p_updateCraftingInventory_2_)
    {
    }

    /**
     * Sends the contents of an inventory slot to the client-side Container. This doesn't have to match the actual
     * contents of that slot.
     */
    public void sendSlotContents(Container containerToSend, int slotInd, ItemStack stack)
    {
        this.mc.playerController.sendSlotPacket(stack, slotInd);
    }

    public void sendProgressBarUpdate(Container p_sendProgressBarUpdate_1_, int p_sendProgressBarUpdate_2_, int p_sendProgressBarUpdate_3_)
    {
    }

    public void sendAllWindowProperties(Container containerIn, IInventory inventory)
    {
    }
}
